bjective

Replace **only** the old native Bergamot implementation:

```text
browsermt/bergamot-translator
9271618ebbdc5d21ac4dc4df9e72beb7ce644774
```

with the exact Bergamot implementation currently pinned by Firefox:

```text
repository:
mozilla/translations

revision:
eea6e5a80aa4ddd86d9cc35ce9a65b79aa3ab96d

Bergamot version:
v0.6.0

native source:
inference/
```

Then rerun **only the six native rounds** against the exact existing six corpus files.

Do not rerun:

* Chrome Translator API
* Firefox/Bergamot WASM

Those are now frozen baselines.

Do not implement:

* Kotlin
* JNI
* C ABI
* KMP
* ECS integration
* subtitle extraction
* translation service

This task ends after producing the corrected six-round current-Mozilla native benchmark and comparison report.

---

# 1. Freeze the existing validated benchmark

Before modifying anything, preserve the current results.

Create:

```text
results/archive/browsermt-9271618/
```

Copy into it:

```text
results/runs/round-01-native.json
results/runs/round-02-native.json
results/runs/round-03-native.json
results/runs/round-04-native.json
results/runs/round-05-native.json
results/runs/round-06-native.json

results/aggregate/translation-comparison.json
results/FINAL_BENCHMARK_REPORT.md
```

Also preserve the old native binary/build metadata if available.

	Example:

	```text
	results/archive/browsermt-9271618/native-build-manifest.json
	```

	Do not delete the existing result.

	We want both:

	```text
	OLD:
	BrowserMT native

	NEW:
	Firefox-current Mozilla native
	```

	available for later comparison.

		---

		# 2. Freeze Chrome and WASM results cryptographically

		Do not rerun either engine.

		Generate SHA-256 hashes for:

			```text
			round-01-chrome.json
			round-02-chrome.json
			...
			round-06-chrome.json

			round-01-wasm.json
			round-02-wasm.json
			...
			round-06-wasm.json
			```

			Save:

			```text
			results/frozen-baseline-sha256.json
			```

			Example structure:

			```json
			{
				  "chrome": {
					      "round-01": "...",
					          "round-02": "..."
						    },
						      "wasm": {
							          "round-01": "...",
								      "round-02": "..."
								        }
								}
								```

								At the end of this task recalculate those hashes.

								They must be identical.

								If Chrome/WASM result files changed:

								```text
								FAIL
								```

								Do not accept the benchmark.

								---

								# 3. Freeze the six existing corpora

								Do not regenerate these:

								```text
								results/corpora/round-01.json
								results/corpora/round-02.json
								results/corpora/round-03.json
								results/corpora/round-04.json
								results/corpora/round-05.json
								results/corpora/round-06.json
								```

								Record their SHA-256 hashes before proceeding.

								The new native implementation must consume these exact files.

								Do not:

								```text
								reshuffle
								change seeds
								regenerate sentences
								change warmups
								change first probe
								```

								The comparison is paired against the already-frozen Chrome/WASM results.

								---

								# 4. Obtain the exact Firefox-pinned source

								Create a completely new source checkout.

								Do not modify or reuse the old:

								```text
								native/bergamot-translator/
								```

								Use:

								```text
								native/mozilla-translations-firefox/
								```

								PowerShell:

								```powershell
								git clone https://github.com/mozilla/translations.git `
								    native/mozilla-translations-firefox

								    git -C native/mozilla-translations-firefox `
								        checkout --detach `
									    eea6e5a80aa4ddd86d9cc35ce9a65b79aa3ab96d

									    git -C native/mozilla-translations-firefox `
									        submodule update --init --recursive
										```

										The commit is mandatory.

										Do not use:

										```text
										main
										latest
										master
										another release
										```

										---

										# 5. Verify source identity before building

										Run:

										```powershell
										git -C native/mozilla-translations-firefox rev-parse HEAD
										```

										It must return exactly:

										```text
										eea6e5a80aa4ddd86d9cc35ce9a65b79aa3ab96d
										```

										Then:

										```powershell
										Get-Content `
										  native/mozilla-translations-firefox/inference/BERGAMOT_VERSION
										  ```

										  It must return:

										  ```text
										  v0.6.0
										  ```

										  Then:

										  ```powershell
										  git -C native/mozilla-translations-firefox `
										      submodule status --recursive
										      ```

										      Save all of this into:

										      ```text
										      results/current-mozilla-source-manifest.txt
										      ```

										      If the main revision does not match:

										      ```text
										      ABORT
										      ```

										      ---

										      # 6. Do not use the archived `mozilla/bergamot-translator`

										      Do **not** use:

										      ```text
										      mozilla/bergamot-translator
										      ```

										      Do **not** use:

										      ```text
										      browsermt/bergamot-translator
										      ```

										      The source of truth for this rerun is:

											      ```text
											      mozilla/translations/inference/
											      ```

											      at:

											      ```text
											      eea6e5a80aa4ddd86d9cc35ce9a65b79aa3ab96d
											      ```

											      ---

											      # 7. Keep the exact same Mozilla model

											      Do not change translation models.

											      Reuse the exact already-validated es→en model files:

											      ```text
											      model.esen.intgemm.alphas.bin
											      vocab.esen.spm
											      lex.50.50.esen.s2t.bin
											      ```

											      and the same model configuration/YAML already used by the current native benchmark.

											      Before building/running, verify their existing SHA-256 values.

											      Especially verify:

											      ```text
											      model:
											      4aed7734152ae0045d1a69ae49c86cfda18f53c61f90e95e1d1de1c7c7c3b033
											      ```

											      Do not download another model version.

											      This experiment changes:

											      ```text
											      native inference implementation
											      ```

											      and **nothing else**.

												      ---

												      # 8. Add the benchmark executable to the Mozilla checkout

												      Do not modify Bergamot/Marian inference source.

												      Only add a benchmark application target.

												      Create:

												      ```text
												      native/mozilla-translations-firefox/
												          inference/
													          src/
														              app/
															                      harness_native_bench.cpp
																	      ```

																	      Start from the existing corrected:

																	      ```text
																	      native/native-bench.cpp
																	      ```

																	      Do not rewrite the benchmark logic.

																	      Preserve:

																	      * JSON protocol
																	      * corpus loading
																	      * first probe
																	      * 20 warmups
																	      * sequential measurement
																	      * burst measurement
																	      * microbatch measurement
																	      * wall-clock throughput
																	      * round number
																	      * corpus SHA
																	      * result format
																	      * timing logic

																	      Only adapt the Bergamot API/includes to the current Mozilla source.

																	      ---

																	      # 9. Use the current Mozilla API

																	      The new native benchmark should include:

																	      ```cpp
																	      #include "translator/parser.h"
																	      #include "translator/response.h"
																	      #include "translator/response_options.h"
																	      #include "translator/service.h"
																	      ```

																	      Use:

																	      ```cpp
																	      using namespace marian::bergamot;
																	      ```

																	      Configure the service exactly:

																	      ```cpp
																	      AsyncService::Config serviceConfig;

																	      serviceConfig.numWorkers = 1;
																	      serviceConfig.cacheSize = 0;

																	      AsyncService service(serviceConfig);
																	      ```

																	      The current Mozilla API explicitly defines:

																	      ```text
																	      AsyncService::Config
																	      numWorkers
																	      cacheSize
																	      ```

																	      and recommends `AsyncService` when async/multithread capability is available.

																	      Do not switch to `BlockingService`.

																	      ---

																	      # 10. Load the model using current Mozilla APIs

																	      Continue using:

																	      ```cpp
																	      auto options =
																		          parseOptionsFromFilePath(configPath);

																	      auto model =
																		          service.createCompatibleModel(options);
																	      ```

																	      Do not manually construct Marian internals.

																	      Do not manually parse model binaries.

																	      ---

																	      # 11. Translation implementation

																	      Each measured translation should retain the same architecture currently used by Mozilla's CLI:

																	      ```cpp
																	      std::promise<Response> promise;
																	      std::future<Response> future =
																		          promise.get_future();

																	      auto callback =
																		          [&promise](Response&& response) {
																				          promise.set_value(
																						              std::move(response)
																							              );
																	          };

																		  service.translate(
																			      model,
																			          std::move(input),
																				      callback,
																				          ResponseOptions{}
																				  );

																				  Response response =
																					      future.get();

																				  std::string translated =
																					      response.target.text;
																				  ```

																				  The measured timer must surround the same logical operation as before:

																				  ```text
																				  submit translation
																				  → worker execution
																				  → callback
																				  → future completion
																				  → translated result available
																				  ```

																				  Do not time only internal matrix operations.

																				  ---

																				  # 12. Do not expect 100% exact WASM/native output identity

																				  The current Mozilla source explicitly warns that `BlockingService` and `AsyncService` may produce slightly different results because batching differences can cause floating-point rounding differences.

																				  Therefore:

																				  ```text
																				  native output != WASM output
																					  ```

																					  on occasional sentences is not automatically a failure.

																					  We will measure output agreement diagnostically later.

																					  Do not switch the native implementation to `BlockingService` just to make text outputs identical.

																					  ---

																					  # 13. Add the benchmark CMake target

																					  Edit only:

																					  ```text
																					  inference/src/app/CMakeLists.txt
																					  ```

																					  Current upstream content contains:

																					  ```cmake
																					  add_executable(
																						      translator-cli
																						          translator_cli.cpp
																						  )

																						  target_link_libraries(
																							      translator-cli
																							          PRIVATE
																								      bergamot-translator-source
																							      )
																							      ```

																							      Add:

																							      ```cmake
																							      add_executable(
																								          harness-native-bench
																									      harness_native_bench.cpp
																								      )

																								      target_link_libraries(
																									          harness-native-bench
																										      PRIVATE
																										          bergamot-translator-source
																										  )
																										  ```

																										  Do not modify:

																										  ```text
																										  translator/
																										  marian-fork/
																										  3rd_party/
																										  ```

																										  Only:

																										  ```text
																										  new benchmark source
																										  +
																										  benchmark target
																										  ```

																										  may differ from upstream.

																										  ---

																										  # 14. Build using the current Mozilla native configuration

																										  Mozilla's current native build explicitly selects:

																										  ```text
																										  USE_FBGEMM=ON
																											  COMPILE_CPU=ON
																												  COMPILE_CUDA=OFF
																													  ```

																													  Use that configuration.

																													  On Windows, FBGEMM must be statically linked, so explicitly set:

																													  ```text
																													  USE_STATIC_LIBS=ON
																														  ```

																														  Use Visual Studio 2022 x64.

																														  Run:

																														  ```powershell
																														  $source = `
																															    "native/mozilla-translations-firefox/inference"

																															    $build = `
																																      "native/mozilla-translations-firefox/inference/build-harness"
																																      ```

																																      Configure:

																																      ```powershell
																																      cmake `
																																        -S $source `
																																	  -B $build `
																																	    -G "Visual Studio 17 2022" `
																																	      -A x64 `
																																	        -DCOMPILE_WASM=OFF `
																																			  -DCOMPILE_CPU=ON `
																																				    -DCOMPILE_CUDA=OFF `
																																					      -DUSE_FBGEMM=ON `
																																						        -DUSE_STATIC_LIBS=ON `
																																								  -DBUILD_ARCH=native `
																																									    -DCOMPILE_TESTS=OFF `
																																										      -DCOMPILE_UNIT_TESTS=OFF
																																											      ```

																																											      Then:

																																											      ```powershell
																																											      cmake `
																																											        --build $build `
																																												  --config Release `
																																												    --target harness-native-bench `
																																												      --parallel
																																												      ```

																																												      Do not build Debug.

																																												      Do not benchmark `RelWithDebInfo`.

																																												      Benchmark:

																																												      ```text
																																												      Release
																																												      ```

																																												      only.

																																												      ---

																																												      # 15. Verify AVX2

																																												      Current Mozilla CMake maps:

																																												      ```text
																																												      BUILD_ARCH=native
																																													      ```

																																													      to:

																																													      ```text
																																													      /arch:AVX2
																																													      ```

																																													      for MSVC x64.

																																														      After configure/build, inspect:

																																														      ```text
																																														      CMakeCache.txt
																																														      build log
																																														      ```

																																														      Verify:

																																														      ```text
																																														      BUILD_ARCH = native
																																															      MSVC
																																															      x64
																																															      Release
																																															      AVX2
																																															      ```

																																															      If the build silently falls back to SSE2:

																																															      ```text
																																															      ABORT BENCHMARK
																																															      ```

																																															      Do not compare it with the previous result.

																																															      ---

																																															      # 16. Verify FBGEMM actually enabled

																																															      Inspect:

																																															      ```text
																																															      CMakeCache.txt
																																															      ```

																																															      and assert:

																																															      ```text
																																															      USE_FBGEMM:BOOL=ON
																																																      USE_STATIC_LIBS:BOOL=ON
																																																	      COMPILE_CPU:BOOL=ON
																																																		      COMPILE_CUDA:BOOL=OFF
																																																			      COMPILE_WASM:BOOL=OFF
																																																				      ```

																																																				      Record also:

																																																				      ```text
																																																				      USE_MKL
																																																				      USE_INTGEMM
																																																				      USE_ONNX_SGEMM
																																																				      BUILD_ARCH
																																																				      ```

																																																				      whatever values the pinned Mozilla build resolves them to.

																																																				      Do not silently change additional math backends to make the benchmark faster.

																																																				      The main requirement is:

																																																				      ```text
																																																				      USE_FBGEMM=ON
																																																					      ```

																																																					      because that is Mozilla's intended current native CPU build configuration.

																																																					      ---

																																																					      # 17. Generate a native build manifest

																																																					      Create:

																																																					      ```text
																																																					      results/current-mozilla-native-build.json
																																																					      ```

																																																					      Containing at least:

																																																					      ```json
																																																					      {
																																																						        "repository": "mozilla/translations",
																																																							  "revision": "eea6e5a80aa4ddd86d9cc35ce9a65b79aa3ab96d",
																																																							    "bergamotVersion": "v0.6.0",
																																																							      "buildType": "Release",
																																																							        "compiler": "MSVC",
																																																								  "architecture": "x64",
																																																								    "buildArch": "native",
																																																								      "expectedIsa": "AVX2",
																																																								        "service": "AsyncService",
																																																									  "workers": 1,
																																																									    "cacheSize": 0,
																																																									      "useFbgemm": true,
																																																									        "useStaticLibs": true,
																																																										  "compileCpu": true,
																																																										    "compileCuda": false,
																																																										      "compileWasm": false,
																																																										        "modelSha256": "4aed7734152ae0045d1a69ae49c86cfda18f53c61f90e95e1d1de1c7c7c3b033"
																																																										}
																																																										```

																																																										Add resolved CMake cache values where possible.

																																																										---

																																																										# 18. Sanity-test the new executable before benchmarking

																																																										Before running 3,000 measured translations:

																																																										Run exactly one known sentence:

																																																										```text
																																																										¿Qué estás haciendo?
																																																										```

																																																										Confirm:

																																																										```text
																																																										process starts
																																																										model loads
																																																										translation completes
																																																										non-empty English result returned
																																																										process exits cleanly
																																																										```

																																																										Then test:

																																																										```text
																																																										10 sequential requests
																																																										```

																																																										Confirm:

																																																										```text
																																																										no crash
																																																										no deadlock
																																																										no exception
																																																										no memory fault
																																																										```

																																																										Only then run the benchmark.

																																																										---

																																																										# 19. Change engine metadata

																																																										The result JSON must identify this engine distinctly.

																																																										Use:

																																																										```json
																																																										{
																																																											  "engine": "mozilla-bergamot-native",
																																																											    "implementation": "firefox-current-native",
																																																											      "sourceRepository": "mozilla/translations",
																																																											        "sourceRevision": "eea6e5a80aa4ddd86d9cc35ce9a65b79aa3ab96d",
																																																												  "bergamotVersion": "v0.6.0",
																																																												    "service": "AsyncService",
																																																												      "workers": 1,
																																																												        "cacheSize": 0,
																																																													  "mathBackend": "FBGEMM",
																																																													    "build": "Release"
																																																												    }
																																																												    ```

																																																												    Do not label it:

																																																												    ```text
																																																												    BrowserMT
																																																												    BlockingService
																																																												    old native
																																																												    ```

																																																												    ---

																																																												    # 20. Do not rerun the entire balanced three-engine suite

																																																												    We already have six valid Chrome rounds and six valid WASM rounds.

																																																												    Do **not** spend time rerunning them.

																																																												    Run:

																																																												    ```text
																																																												    Native Firefox-current only.
																																																												    ```

																																																												    against:

																																																												    ```text
																																																												    round-01.json
																																																												    round-02.json
																																																												    round-03.json
																																																												    round-04.json
																																																												    round-05.json
																																																												    round-06.json
																																																												    ```

																																																												    ---

																																																												    # 21. Preserve the same per-round corpus pairing

																																																												    For native round 1:

																																																												    ```text
																																																												    results/corpora/round-01.json
																																																												    ```

																																																												    For native round 2:

																																																												    ```text
																																																												    results/corpora/round-02.json
																																																												    ```

																																																												    etc.

																																																												    Before starting each native run:

																																																												    Verify its corpus SHA matches the frozen Chrome/WASM corpus SHA for that same round.

																																																													    If it does not:

																																																													    ```text
																																																													    ABORT
																																																													    ```

																																																													    ---

																																																													    # 22. Replace only the six active native result files

																																																													    Since the old native results were archived in step 1, the new engine can write:

																																																														    ```text
																																																														    results/runs/round-01-native.json
																																																														    ...
																																																														    results/runs/round-06-native.json
																																																														    ```

																																																														    Do not modify:

																																																														    ```text
																																																														    *-chrome.json
																																																														    *-wasm.json
																																																														    ```

																																																														    ---

																																																														    # 23. Run each native round as a fresh process

																																																														    Each round should create a new native benchmark process.

																																																														    Do not keep one process alive across all six rounds.

																																																														    This keeps lifecycle semantics consistent with the existing benchmark.

																																																														    Run:

																																																														    ```text
																																																														    round 1
																																																														    process exits
																																																														    10 second pause

																																																														    round 2
																																																														    process exits
																																																														    10 second pause

																																																														    ...
																																																														    ```

																																																														    Use the same machine conditions as the previous benchmark.

																																																														    ---

																																																														    # 24. Required native rounds

																																																														    Run exactly:

																																																														    ```text
																																																														    Round 1 → corpus seed 42001
																																																														    Round 2 → corpus seed 42002
																																																														    Round 3 → corpus seed 42003
																																																														    Round 4 → corpus seed 42004
																																																														    Round 5 → corpus seed 42005
																																																														    Round 6 → corpus seed 42006
																																																														    ```

																																																														    There must be:

																																																														    ```text
																																																														    500 measured translations per round
																																																														    ```

																																																														    Therefore:

																																																														    ```text
																																																														    3,000 measured native translations
																																																														    ```

																																																														    total.

																																																														    ---

																																																														    # 25. Do not modify timing methodology

																																																														    Keep the already-corrected methodology:

																																																														    ```text
																																																														    one first-translation probe
																																																														    20 unique warmups
																																																														    500 measured translations
																																																														    ```

																																																														    Measure:

																																																														    ```text
																																																														    engineSetupMs
																																																													    firstTranslationMs

																																																													    sequential:
																																																													    p50
																																																													    p90
																																																													    p95
																																																													    p99
																																																													    mean
																																																													    min
																																																													    max

																																																													    wall-clock throughput:
																																																													    translations/sec
																																																													    words/sec
																																																													    characters/sec

																																																													    buckets:
																																																													    tiny
																																																													    short
																																																													    medium
																																																													    long
																																																													    ```

																																																													    Do not redesign the benchmark again.

																																																													    ---

																																																													    # 26. Primary performance gates

																																																													    Current Mozilla native must satisfy, in **every round**:

																																																													    ```text
																																																													    p95 <= 150 ms

																																																														    p99 <= 250 ms

																																																															    >= 10 translations/sec
																																																																    ```

																																																																    These are hard real-time subtitle viability gates.

																																																																    ---

																																																																    # 27. Chrome comparison gate

																																																																    Frozen Chrome baseline currently has approximately:

																																																																    ```text
																																																																    median p50 = 15.80 ms
																																																																	    median p95 = 44.31 ms
																																																																		    median p99 = 48.05 ms
																																																																			    median throughput = 49.35 lines/sec
																																																																				    ```

																																																																				    Do not hard-code these into benchmark logic; read the frozen Chrome JSON.

																																																																				    Classify current Mozilla native as:

																																																																				    ### FASTER THAN CHROME

																																																																				    if:

																																																																					    ```text
																																																																					    median native p50 <= median Chrome p50

																																																																						    AND

																																																																						    median native p95 <= median Chrome p95

																																																																							    AND

																																																																							    native p95 beats Chrome in >= 5 of 6 rounds
																																																																								    ```

																																																																								    ### EQUIVALENT / VIABLE

																																																																								    if:

																																																																									    ```text
																																																																									    native median p95 <= Chrome median p95 × 1.10

																																																																										    AND

																																																																										    absolute latency gates pass
																																																																										    ```

																																																																										    ### SLOWER BUT VIABLE

																																																																										    if:

																																																																											    ```text
																																																																											    native > Chrome by >10%

																																																																											    BUT

																																																																											    native p95 <= 150 ms
																																																																												    native p99 <= 250 ms
																																																																													    ```

																																																																													    ### NOT VIABLE

																																																																													    if the absolute subtitle gates fail.

																																																																														    ---

																																																																														    # 28. Compare new native to the old native too

																																																																														    The final report should include:

																																																																														    | Metric     | Old BrowserMT Native | Firefox-Current Native |
																																																																														    | ---------- | -------------------: | ---------------------: |
																																																																														    | median p50 |            ~10.13 ms |                        |
																																																																														    | median p95 |            ~28.07 ms |                        |
																																																																														    | median p99 |            ~30.35 ms |                        |
																																																																														    | lines/sec  |               ~79.91 |                        |

																																																																														    Calculate:

																																																																														    ```text
																																																																														    new / old ratio
																																																																														    ```

																																																																														    for:

																																																																															    ```text
																																																																															    p50
																																																																															    p95
																																																																															    p99
																																																																															    throughput
																																																																															    ```

																																																																															    This tells us whether moving to the current Firefox source costs or improves performance.

																																																																															    ---

																																																																															    # 29. Add output-equivalence diagnostics

																																																																															    Compare the translation text from:

																																																																															    ```text
																																																																															    Firefox WASM
																																																																															    vs
																																																																															    Firefox-current native
																																																																															    ```

																																																																															    for the same 500 unique inputs.

																																																																																    Because the six rounds contain the same strings in different order, compare by source text rather than array position.

																																																																																    Report:

																																																																																    ```text
																																																																																    exact matches: X / 500
																																																																																    different: Y / 500
																																																																																    exact-match percentage
																																																																																    ```

																																																																																    For every differing output save:

																																																																																	    ```json
																																																																																	    {
																																																																																		      "source": "...",
																																																																																		        "wasm": "...",
																																																																																			  "native": "..."
																																																																																		  }
																																																																																		  ```

																																																																																		  to:

																																																																																		  ```text
																																																																																		  results/current-native-vs-wasm-differences.json
																																																																																		  ```

																																																																																		  Do not treat non-100% equality as an automatic failure.

																																																																																		  `AsyncService` and `BlockingService` are not guaranteed to produce bit-identical output.

																																																																																		  This is diagnostic.

																																																																																		  ---

																																																																																		  # 30. Flag obvious semantic regressions manually

																																																																																		  If there are differences, generate a small Markdown file:

																																																																																		  ```text
																																																																																		  results/current-native-vs-wasm-review.md
																																																																																		  ```

																																																																																		  with the first 50 differences.

																																																																																		  Do not use an LLM to automatically rewrite or judge them during the performance run.

																																																																																		  Just expose:

																																																																																		  ```text
																																																																																		  source
																																																																																		  WASM
																																																																																		  native
																																																																																		  ```

																																																																																		  for human review afterward.

																																																																																			  ---

																																																																																			  # 31. Reaggregate using frozen Chrome/WASM + new native

																																																																																			  After all six new native rounds finish, rerun:

																																																																																			  ```text
																																																																																			  aggregate-results
																																																																																			  generate-benchmark-report
																																																																																			  ```

																																																																																			  using:

																																																																																			  ```text
																																																																																			  Frozen Chrome
																																																																																			  Frozen WASM
																																																																																			  New Firefox-current native
																																																																																			  ```

																																																																																			  Do not use the archived old native results as the active `native` engine.

																																																																																			  ---

																																																																																			  # 32. Verify frozen inputs remained frozen

																																																																																			  After aggregation:

																																																																																			  Recalculate SHA-256 for:

																																																																																				  ```text
																																																																																				  6 Chrome files
																																																																																				  6 WASM files
																																																																																				  6 corpus files
																																																																																				  ```

																																																																																				  Compare to their pre-run hashes.

																																																																																				  Every hash must match.

																																																																																				  If any changed:

																																																																																				  ```text
																																																																																				  BENCHMARK INVALID
																																																																																				  ```

																																																																																				  ---

																																																																																				  # 33. Run harness tests

																																																																																				  Before native run:

																																																																																				  ```powershell
																																																																																				  npm test
																																																																																				  ```

																																																																																				  All existing tests must pass.

																																																																																				  After native run and aggregation:

																																																																																				  ```powershell
																																																																																				  npm test
																																																																																				  ```

																																																																																				  again.

																																																																																				  Do not accept regressions.

																																																																																				  If new tests are added for:

																																																																																					  ```text
																																																																																					  source revision
																																																																																					  build manifest
																																																																																					  frozen baseline integrity
																																																																																					  ```

																																																																																					  they should also pass.

																																																																																					  ---

																																																																																					  # 34. Final report format

																																																																																					  Update:

																																																																																					  ```text
																																																																																					  results/FINAL_BENCHMARK_REPORT.md
																																																																																					  ```

																																																																																					  to clearly state:

																																																																																					  ```text
																																																																																					  NATIVE ENGINE SOURCE

																																																																																					  Repository:
																																																																																					  mozilla/translations

																																																																																					  Firefox-pinned revision:
																																																																																					  eea6e5a80aa4ddd86d9cc35ce9a65b79aa3ab96d

																																																																																					  Bergamot:
																																																																																					  v0.6.0

																																																																																					  Service:
																																																																																					  AsyncService

																																																																																					  Workers:
																																																																																					  1

																																																																																					  Cache:
																																																																																					  0

																																																																																					  CPU backend:
																																																																																					  FBGEMM

																																																																																					  Build:
																																																																																					  Release x64

																																																																																					  Architecture:
																																																																																					  AVX2
																																																																																					  ```

																																																																																					  ---

																																																																																					  # 35. Required performance summary

																																																																																					  The report must contain:

																																																																																					  ```text
																																																																																					  CURRENT FIREFOX NATIVE

																																																																																					  Round 1
																																																																																					  p50:
																																																																																					  p95:
																																																																																					  p99:
																																																																																					  TPS:

																																																																																					  Round 2
																																																																																					  ...

																																																																																					  Round 6
																																																																																					  ...
																																																																																					  ```

																																																																																					  Then:

																																																																																					  ```text
																																																																																					  CURRENT FIREFOX NATIVE AGGREGATE

																																																																																					  Median p50:
																																																																																					  Median p95:
																																																																																					  Median p99:
																																																																																					  Median TPS:

																																																																																					  Mean p50:
																																																																																					  Mean p95:
																																																																																					  Mean p99:

																																																																																					  p95 stddev:
																																																																																					  ```

																																																																																					  ---

																																																																																					  # 36. Required comparison table

																																																																																					  Include:

																																																																																					  | Metric              | Chrome | Firefox WASM | Old Native | Current Firefox Native |
																																																																																					  | ------------------- | -----: | -----------: | ---------: | ---------------------: |
																																																																																					  | Median p50          |        |              |            |                        |
																																																																																					  | Median p95          |        |              |            |                        |
																																																																																					  | Median p99          |        |              |            |                        |
																																																																																					  | TPS                 |        |              |            |                        |
																																																																																					  | Short subtitle p95  |        |              |            |                        |
																																																																																					  | Medium subtitle p95 |        |              |            |                        |
																																																																																					  | Long subtitle p95   |        |              |            |                        |

																																																																																					  ---

																																																																																					  # 37. Required winner analysis

																																																																																					  Report:

																																																																																					  ```text
																																																																																					  CURRENT FIREFOX NATIVE VS CHROME

																																																																																					  p50 wins:
																																																																																					  X / 6

																																																																																					  p95 wins:
																																																																																					  X / 6

																																																																																					  p99 wins:
																																																																																					  X / 6

																																																																																					  median p50 ratio:
																																																																																					  native / chrome

																																																																																					  median p95 ratio:
																																																																																					  native / chrome

																																																																																					  median p99 ratio:
																																																																																					  native / chrome
																																																																																					  ```

																																																																																					  Also:

																																																																																					  ```text
																																																																																					  CURRENT FIREFOX NATIVE VS OLD NATIVE

																																																																																					  p50 delta:
																																																																																					  p95 delta:
																																																																																					  p99 delta:
																																																																																					  throughput delta:
																																																																																					  ```

																																																																																					  ---

																																																																																					  # 38. Final classification

																																																																																					  End with exactly:

																																																																																					  ```text
																																																																																					  CURRENT FIREFOX NATIVE BERGAMOT

																																																																																					  Source verification:
																																																																																					  PASS / FAIL

																																																																																					  Firefox-pinned revision:
																																																																																					  PASS / FAIL

																																																																																					  Six rounds completed:
																																																																																					  PASS / FAIL

																																																																																					  Same frozen corpora:
																																																																																					  PASS / FAIL

																																																																																					  Chrome/WASM baselines unchanged:
																																																																																					  PASS / FAIL

																																																																																					  Absolute subtitle p95:
																																																																																					  PASS / FAIL

																																																																																					  Absolute subtitle p99:
																																																																																					  PASS / FAIL

																																																																																					  Throughput:
																																																																																					  PASS / FAIL

																																																																																					  Native vs Chrome:
																																																																																					  FASTER /
																																																																																					  EQUIVALENT /
																																																																																					  SLOWER BUT VIABLE /
																																																																																					  NOT VIABLE

																																																																																					  Output agreement with Firefox WASM:
																																																																																					  X / 500
																																																																																					  X%


																																																																																					  FINAL DECISION:

																																																																																					  CURRENT MOZILLA NATIVE TRANSLATION
																																																																																					  IS VALIDATED / IS NOT VALIDATED.
																																																																																					  ```

																																																																																					  ---

																																																																																					  # 39. Hard stop

																																																																																					  Once the new report is generated:

																																																																																					  **STOP.**

																																																																																					  Do not start:

																																																																																					  ```text
																																																																																					  Kotlin
																																																																																					  JNI
																																																																																					  C ABI
																																																																																					  KMP
																																																																																					  model manager
																																																																																					  ECS IPC
																																																																																					  ```

																																																																																					  Return:

																																																																																					  ```text
																																																																																					  results/FINAL_BENCHMARK_REPORT.md

																																																																																					  results/current-mozilla-native-build.json

																																																																																					  results/current-native-vs-wasm-differences.json

																																																																																					  results/current-native-vs-wasm-review.md

																																																																																					  results/runs/round-01-native.json
																																																																																					  ...
																																																																																					  results/runs/round-06-native.json

																																																																																					  results/frozen-baseline-sha256.json

																																																																																					  results/current-mozilla-source-manifest.txt
																																																																																					  ```

																																																																																					  for review first.

																																																																																						  ---

																																																																																						  # Expected outcome

																																																																																						  The old native implementation achieved approximately:

																																																																																						  ```text
																																																																																						  p50 ~10.1 ms
																																																																																						  p95 ~28.1 ms
																																																																																						  p99 ~30.4 ms
																																																																																						  ~80 lines/sec
																																																																																						  ```

																																																																																						  The exact number is not the goal.

																																																																																						  If current Firefox-native Bergamot produces something like:

																																																																																						  ```text
																																																																																						  p95 25–40 ms
																																																																																						  ```

																																																																																						  and continues beating or closely matching Chrome, that is an excellent result.

																																																																																						  Even something like:

																																																																																						  ```text
																																																																																						  p95 50–70 ms
																																																																																						  ```

																																																																																						  would still be completely viable for live subtitles.

																																																																																							  The reason for this rerun is not to chase another benchmark victory.

																																																																																								  The reason is to establish:

																																																																																								  > We are building the product on the same maintained Mozilla Bergamot source lineage Firefox currently uses, rather than an older BrowserMT implementation.

																																																																																								  Only after that is established should the Kotlin/native integration begin.


