import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import {
  ROUND_COUNT,
  ROUND_ORDERS,
  ROUND_SEEDS,
  buildRoundCorpus,
  hashItems
} from "../src/translation/common/rounds.js";

const corpus = JSON.parse(
  readFileSync(new URL("../src/translation/common/corpus.json", import.meta.url), "utf8")
);

test("six deterministic round corpora keep the same unique set and change order", () => {
  assert.equal(ROUND_COUNT, 6);
  assert.deepEqual(ROUND_SEEDS, [42001, 42002, 42003, 42004, 42005, 42006]);
  const sourceHash = hashItems(corpus.items);
  const built = ROUND_SEEDS.map((seed, index) =>
    buildRoundCorpus(corpus.items, index + 1, seed)
  );
  assert.equal(built.length, 6);
  for (const round of built) {
    assert.equal(round.items.length, 500);
    assert.equal(new Set(round.items).size, 500);
    assert.equal(round.sourceCorpusSha256, sourceHash);
    assert.equal(round.roundCorpusSha256, hashItems(round.items));
    assert.deepEqual([...round.items].sort(), [...corpus.items].sort());
  }
  const orders = new Set(built.map((round) => round.items.join("\n")));
  assert.equal(orders.size, 6);
  const again = buildRoundCorpus(corpus.items, 1, 42001);
  assert.deepEqual(again.items, built[0].items);
  assert.notDeepEqual(built[0].items, corpus.items);
});

test("round engine orders are the six permutations, balanced by slot", () => {
  const first = [];
  const second = [];
  const third = [];
  for (let round = 1; round <= 6; round += 1) {
    const order = ROUND_ORDERS[round];
    assert.equal(order.length, 3);
    assert.deepEqual([...order].sort(), ["chrome", "native", "wasm"]);
    first.push(order[0]);
    second.push(order[1]);
    third.push(order[2]);
  }
  for (const engine of ["chrome", "native", "wasm"]) {
    assert.equal(first.filter((value) => value === engine).length, 2);
    assert.equal(second.filter((value) => value === engine).length, 2);
    assert.equal(third.filter((value) => value === engine).length, 2);
  }
});
