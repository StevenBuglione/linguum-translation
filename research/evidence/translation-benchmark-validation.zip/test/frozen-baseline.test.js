import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, existsSync } from "node:fs";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";
import path from "node:path";

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");

function sha256File(rel) {
  const buf = readFileSync(path.join(ROOT, rel));
  return createHash("sha256").update(buf).digest("hex");
}

test("Firefox-pinned source revision and Bergamot version", () => {
  const repo = path.join(ROOT, "native", "mozilla-translations-firefox");
  if (!existsSync(path.join(repo, "inference", "BERGAMOT_VERSION"))) {
    return;
  }
  const version = readFileSync(path.join(repo, "inference", "BERGAMOT_VERSION"), "utf8").trim();
  assert.equal(version, "v0.6.0");
});

test("frozen Chrome/WASM/corpus hashes remain identical when freeze file exists", () => {
  const freezePath = path.join(ROOT, "results", "frozen-baseline-sha256.json");
  if (!existsSync(freezePath)) {
    return;
  }
  const frozen = JSON.parse(readFileSync(freezePath, "utf8"));
  for (let round = 1; round <= 6; round += 1) {
    const pad = String(round).padStart(2, "0");
    assert.equal(
      sha256File(`results/runs/round-${pad}-chrome.json`),
      frozen.chrome[`round-${pad}`]
    );
    assert.equal(
      sha256File(`results/runs/round-${pad}-wasm.json`),
      frozen.wasm[`round-${pad}`]
    );
    assert.equal(
      sha256File(`results/corpora/round-${pad}.json`),
      frozen.corpora[`round-${pad}`]
    );
  }
  assert.equal(
    frozen.models["model.esen.intgemm.alphas.bin"],
    "4aed7734152ae0045d1a69ae49c86cfda18f53c61f90e95e1d1de1c7c7c3b033"
  );
});
