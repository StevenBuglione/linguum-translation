import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import {
  firstTranslationProbe,
  playbackWorkload,
  realisticSubtitleSchedule,
  runBurst,
  runMicroBatch,
  runSequential,
  summarizeRun,
  warmupSentences
} from "../src/translation/common/benchmark.js";
import { summarizeLatencies } from "../src/translation/common/statistics.js";

const corpus = JSON.parse(
  readFileSync(new URL("../src/translation/common/corpus.json", import.meta.url), "utf8")
);

test("warmup is 20 throwaway sentences from the canonical corpus", () => {
  assert.equal(warmupSentences(corpus).length, 20);
  assert.equal(firstTranslationProbe(corpus), corpus.firstTranslationProbe);
});

test("sequential awaits each translation in order and returns wall clock", async () => {
  const seen = [];
  const { records, wallClockMs } = await runSequential({
    items: ["a", "b", "c"],
    engine: "mozilla-bergamot",
    pair: "es-en",
    translate: async (text) => {
      seen.push(text);
      return { translation: text.toUpperCase(), inferenceMs: 5 };
    }
  });
  assert.deepEqual(seen, ["a", "b", "c"]);
  assert.equal(records[0].translation, "A");
  assert.equal(records[0].id, 0);
  assert.equal(typeof wallClockMs, "number");
  assert.ok(wallClockMs >= 0);
});

test("burst runs with bounded concurrency", async () => {
  let inflight = 0;
  let max = 0;
  const { records, wallClockMs } = await runBurst({
    items: ["a", "b", "c", "d"],
    engine: "chrome-translator-api",
    pair: "es-en",
    concurrency: 2,
    translate: async (text) => {
      inflight += 1;
      max = Math.max(max, inflight);
      await new Promise((resolve) => setTimeout(resolve, 20));
      inflight -= 1;
      return { translation: text, inferenceMs: 20 };
    }
  });
  assert.equal(records.length, 4);
  assert.ok(max <= 2);
  assert.deepEqual(records.map((record) => record.id), [0, 1, 2, 3]);
  assert.ok(wallClockMs >= 20);
});

test("burst throughput uses wall clock not summed latency", async () => {
  const { records, wallClockMs } = await runBurst({
    items: ["a", "b"],
    engine: "mozilla-bergamot",
    pair: "es-en",
    concurrency: 2,
    translate: async (text) => {
      await new Promise((resolve) => setTimeout(resolve, 100));
      return { translation: text, inferenceMs: 100 };
    }
  });
  assert.ok(wallClockMs < 180, `wallClockMs=${wallClockMs}`);
  assert.ok(wallClockMs >= 90, `wallClockMs=${wallClockMs}`);
  const stats = summarizeLatencies(records, wallClockMs);
  assert.ok(stats.translationsPerSecond > 12, `tps=${stats.translationsPerSecond}`);
  const summedMs = records.reduce((sum, sample) => sum + sample.totalMs, 0);
  assert.ok(summedMs > 180, `summedMs=${summedMs}`);
  assert.ok(stats.translationsPerSecond > records.length / (summedMs / 1000));
});

test("microbatch throughput uses wall clock not summed per-item latency", async () => {
  const { records, wallClockMs } = await runMicroBatch({
    items: ["a", "b"],
    engine: "mozilla-bergamot",
    pair: "es-en",
    batchSize: 2,
    translateBatch: async (texts) => {
      await new Promise((resolve) => setTimeout(resolve, 100));
      return texts.map((text) => ({ translation: text, inferenceMs: 100 }));
    }
  });
  assert.ok(wallClockMs < 180, `wallClockMs=${wallClockMs}`);
  const stats = summarizeLatencies(records, wallClockMs);
  assert.ok(stats.translationsPerSecond > 12, `tps=${stats.translationsPerSecond}`);
});

test("summarizeRun matches required schema fields", () => {
  const run = summarizeRun({
    engine: "mozilla-bergamot",
    version: "4.0",
    languagePair: "es-en",
    run: 1,
    round: 1,
    seed: 42001,
    corpusSha256: "a".repeat(64),
    mode: "sequential",
    environment: {
      cpu: "x",
      ramGb: 16,
      gpu: "y",
      windows: "z",
      playbackActive: false
    },
    model: { name: "m", version: "1", bytes: 1 },
    engineSetupMs: 10,
    firstTranslationMs: 12,
    wallClockMs: 10,
    records: [
      {
        engine: "mozilla-bergamot",
        pair: "es-en",
        id: 0,
        source: "a",
        characters: 4,
        words: 1,
        queueMs: 0,
        inferenceMs: 10,
        totalMs: 10
      }
    ]
  });
  assert.equal(run.translations, 1);
  assert.equal(run.p50Ms, 10);
  assert.equal(run.engineSetupMs, 10);
  assert.equal(run.firstTranslationMs, 12);
  assert.equal(run.wallClockMs, 10);
  assert.ok("translationsPerSecond" in run);
});

test("summarizeRun rejects missing wallClockMs", () => {
  assert.throws(
    () =>
      summarizeRun({
        engine: "mozilla-bergamot",
        version: "4.0",
        languagePair: "es-en",
        run: 1,
        mode: "sequential",
        environment: {
          cpu: "x",
          ramGb: 16,
          gpu: "y",
          windows: "z",
          playbackActive: false
        },
        model: { name: "m", version: "1", bytes: 1 },
        engineSetupMs: 1,
        firstTranslationMs: 1,
        records: []
      }),
    /wallClockMs/
  );
});

test("subtitle schedule is strictly increasing", () => {
  const stamps = realisticSubtitleSchedule(8);
  assert.equal(stamps[0], 0);
  for (let i = 1; i < stamps.length; i += 1) {
    assert.ok(stamps[i] > stamps[i - 1]);
  }
});

test("playback workload includes normal burst and heavy", () => {
  const workload = playbackWorkload({
    short: ["uno dos tres cuatro cinco", "a b c d e f"],
    items: ["uno dos tres cuatro cinco"]
  });
  assert.ok(workload.normal.length > 0);
  assert.equal(workload.burst[1].atMs - workload.burst[0].atMs < 500, true);
  assert.ok(workload.heavy.length >= 200);
});
