import { test } from "node:test";
import assert from "node:assert/strict";
import {
  ACCEPTANCE_KEYS,
  CHECKLIST,
  getService,
  isServiceGreen,
  listServices
} from "../src/ecs/services.cjs";

test("streaming order is Netflix, Prime, Max, YouTube", () => {
  assert.deepEqual(
    listServices().map((service) => service.id),
    ["netflix", "prime", "max", "youtube"]
  );
});

test("service URLs are official sites", () => {
  assert.equal(getService("netflix").url, "https://www.netflix.com/");
  assert.equal(getService("prime").url, "https://www.primevideo.com/");
  assert.equal(getService("max").url, "https://www.max.com/");
  assert.match(getService("youtube").url, /^https:\/\/www\.youtube\.com\//);
});

test("unknown service throws", () => {
  assert.throws(() => getService("hulu"), /Unknown service/);
});

test("GREEN requires video audio fullscreen subtitles", () => {
  assert.deepEqual(ACCEPTANCE_KEYS, ["video", "audio", "fullscreen", "subtitles"]);
  assert.equal(
    isServiceGreen({ video: true, audio: true, fullscreen: true, subtitles: true }),
    true
  );
  assert.equal(
    isServiceGreen({ video: true, audio: true, fullscreen: true, subtitles: false }),
    false
  );
});

test("checklist includes login through session restart", () => {
  assert.ok(CHECKLIST.includes("login"));
  assert.ok(CHECKLIST.includes("2 minutes continuous playback"));
  assert.ok(CHECKLIST.includes("session still authenticated"));
});
