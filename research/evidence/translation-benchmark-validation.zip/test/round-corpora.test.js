import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { generateRoundCorpora } from "../scripts/generate-round-corpora.mjs";
import {
  ROUND_COUNT,
  ROUND_SEEDS,
  buildRoundCorpus,
  hashItems
} from "../src/translation/common/rounds.js";

const corpusPath = fileURLToPath(new URL("../src/translation/common/corpus.json", import.meta.url));
const corpus = JSON.parse(readFileSync(corpusPath, "utf8"));

test("deterministic round corpora: 6 files, same set, different order, correct seeds and hashes", () => {
  const tmp = mkdtempSync(path.join(os.tmpdir(), "round-corpora-"));
  try {
    const files = generateRoundCorpora({
      corpusPath,
      outDir: tmp
    });
    assert.equal(files.length, ROUND_COUNT);

    const loaded = [];
    for (let round = 1; round <= ROUND_COUNT; round += 1) {
      const payload = JSON.parse(
        readFileSync(path.join(tmp, `round-${String(round).padStart(2, "0")}.json`), "utf8")
      );
      loaded.push(payload);
      assert.equal(payload.round, round);
      assert.equal(payload.seed, ROUND_SEEDS[round - 1]);
      assert.equal(payload.items.length, 500);
      assert.equal(new Set(payload.items).size, 500);
      assert.deepEqual([...payload.items].sort(), [...corpus.items].sort());
      assert.equal(payload.sourceCorpusSha256, hashItems(corpus.items));
      assert.equal(payload.roundCorpusSha256, hashItems(payload.items));
      const rebuilt = buildRoundCorpus(corpus.items, round, payload.seed);
      assert.deepEqual(payload.items, rebuilt.items);
    }

    for (let i = 0; i < loaded.length; i += 1) {
      for (let j = i + 1; j < loaded.length; j += 1) {
        assert.notDeepEqual(loaded[i].items, loaded[j].items);
        assert.notEqual(loaded[i].roundCorpusSha256, loaded[j].roundCorpusSha256);
      }
    }
  } finally {
    rmSync(tmp, { recursive: true, force: true });
  }
});
