import { test } from "node:test";
import assert from "node:assert/strict";
import {
  aggregateValidatedSet,
  classifyNative,
  validateCompleteSet
} from "../src/translation/common/aggregate.js";
import { ENGINE_IDS, ROUND_SEEDS, runFileName } from "../src/translation/common/rounds.js";

function makeSamples(items, totalMs) {
  return items.map((source, id) => ({
    engine: "x",
    pair: "es-en",
    id,
    source,
    translation: "x",
    characters: source.length,
    words: 1,
    bucket: "short",
    queueMs: 0,
    inferenceMs: totalMs,
    totalMs
  }));
}

function makePayload({ engineKey, round, items, p50, p95, p99, tps, hash = "a".repeat(64) }) {
  const wallClockMs = 500 / tps * 1000;
  const sequential = {
    engine: ENGINE_IDS[engineKey],
    version: "test",
    languagePair: "es-en",
    run: round,
    round,
    seed: ROUND_SEEDS[round - 1],
    corpusSha256: hash,
    mode: "sequential",
    environment: {
      cpu: "c",
      ramGb: 16,
      gpu: "g",
      windows: "w",
      playbackActive: false
    },
    model: { name: "m", version: "1", bytes: 1 },
    engineSetupMs: 10,
    firstTranslationMs: 12,
    wallClockMs,
    translations: 500,
    p50Ms: p50,
    p90Ms: p50,
    p95Ms: p95,
    p99Ms: p99,
    meanMs: p50,
    translationsPerSecond: tps,
    wordsPerSecond: tps * 5,
    buckets: {
      tiny: { count: 100, mean: p50, p50, p90: p95, p95, p99, min: 1, max: p99 },
      short: { count: 200, mean: p50, p50, p90: p95, p95, p99, min: 1, max: p99 },
      medium: { count: 150, mean: p50, p50, p90: p95, p95, p99, min: 1, max: p99 },
      long: { count: 50, mean: p50, p50, p90: p95, p95, p99, min: 1, max: p99 }
    },
    samples: makeSamples(items, p50)
  };
  return {
    engine: ENGINE_IDS[engineKey],
    run: round,
    round,
    seed: ROUND_SEEDS[round - 1],
    corpusSha256: hash,
    results: [sequential]
  };
}

function itemsForRound(round) {
  return Array.from({ length: 500 }, (_, i) => `r${round}-item-${i}`);
}

function completeSet({ nativeP95 = 20, chromeP95 = 40 } = {}) {
  const payloadsByFile = {};
  const corporaByRound = {};
  for (let round = 1; round <= 6; round += 1) {
    const items = itemsForRound(round);
    const hash = "a".repeat(64);
    corporaByRound[round] = {
      seed: ROUND_SEEDS[round - 1],
      corpusSha256: hash,
      items
    };
    payloadsByFile[runFileName(round, "chrome")] = makePayload({
      engineKey: "chrome",
      round,
      items,
      p50: chromeP95 - 10,
      p95: chromeP95,
      p99: chromeP95 + 10,
      tps: 40,
      hash
    });
    payloadsByFile[runFileName(round, "wasm")] = makePayload({
      engineKey: "wasm",
      round,
      items,
      p50: 30,
      p95: 50,
      p99: 70,
      tps: 25,
      hash
    });
    payloadsByFile[runFileName(round, "native")] = makePayload({
      engineKey: "native",
      round,
      items,
      p50: nativeP95 - 5,
      p95: nativeP95,
      p99: nativeP95 + 10,
      tps: 80,
      hash
    });
  }
  return { payloadsByFile, corporaByRound };
}

test("aggregator rejects missing rounds, hash mismatch, and source-order mismatch", () => {
  const { payloadsByFile, corporaByRound } = completeSet();
  delete payloadsByFile["round-03-wasm.json"];
  const missing = validateCompleteSet(payloadsByFile, corporaByRound);
  assert.equal(missing.valid, false);
  assert.match(missing.errors.join("\n"), /round-03-wasm/);

  const mismatched = completeSet();
  mismatched.payloadsByFile["round-02-native.json"].corpusSha256 = "b".repeat(64);
  mismatched.payloadsByFile["round-02-native.json"].results[0].corpusSha256 = "b".repeat(64);
  const hashFail = validateCompleteSet(mismatched.payloadsByFile, mismatched.corporaByRound);
  assert.equal(hashFail.valid, false);
  assert.match(hashFail.errors.join("\n"), /corpus hashes differ|corpusSha256/);

  const order = completeSet();
  order.payloadsByFile["round-01-chrome.json"].results[0].samples[17].source = "DIFFERENT";
  const orderFail = validateCompleteSet(order.payloadsByFile, order.corporaByRound);
  assert.equal(orderFail.valid, false);
  assert.match(orderFail.errors.join("\n"), /sample 17/);
});

test("aggregator accepts a balanced 6-round set and classifies native as faster", () => {
  const { payloadsByFile, corporaByRound } = completeSet();
  const complete = validateCompleteSet(payloadsByFile, corporaByRound);
  assert.equal(complete.valid, true, complete.errors.join("\n"));
  const aggregate = aggregateValidatedSet(payloadsByFile, corporaByRound);
  assert.equal(aggregate.roundsCompleted, 6);
  assert.equal(aggregate.totalMeasuredSamplesPerEngine, 3000);
  assert.equal(aggregate.nativeVsChrome.p95Wins, 6);
  assert.equal(aggregate.nativeVsChrome.decision, "FASTER THAN CHROME");
  assert.equal(aggregate.wasm.decision, "VIABLE");
});

test("native classification requires 5/6 p95 wins for FASTER THAN CHROME", () => {
  const nativeRuns = [10, 10, 10, 10, 10, 200].map((p95, index) => ({
    round: index + 1,
    p50Ms: 8,
    p95Ms: p95,
    p99Ms: Math.min(p95 + 20, 240),
    translationsPerSecond: 20
  }));
  const chromeRuns = nativeRuns.map(() => ({
    p50Ms: 20,
    p95Ms: 40,
    p99Ms: 60,
    translationsPerSecond: 15
  }));
  const slowerRound = classifyNative(nativeRuns, chromeRuns);
  assert.equal(slowerRound.p95Wins, 5);
  assert.equal(slowerRound.absolutePass, false);
  assert.equal(slowerRound.decision, "NOT VIABLE");

  const allFaster = classifyNative(
    nativeRuns.map((run, index) => ({ ...run, p95Ms: 20, p99Ms: 30 })),
    chromeRuns
  );
  assert.equal(allFaster.decision, "FASTER THAN CHROME");
});
