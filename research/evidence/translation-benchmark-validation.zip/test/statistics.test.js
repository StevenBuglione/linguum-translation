import { test } from "node:test";
import assert from "node:assert/strict";
import {
  classifyBucket,
  classifyMozillaVsChrome,
  mean,
  percentile,
  standardDeviation,
  summarizeLatencies,
  wordCount
} from "../src/translation/common/statistics.js";

test("wordCount splits on whitespace and ignores extras", () => {
  assert.equal(wordCount("¿Qué pasó?"), 2);
  assert.equal(wordCount("  No lo sé.  "), 3);
  assert.equal(wordCount(""), 0);
});

test("classifyBucket maps subtitle lengths", () => {
  assert.equal(classifyBucket("Sí."), "tiny");
  assert.equal(classifyBucket("No puedo creer que hayas hecho eso."), "short");
  assert.equal(
    classifyBucket("Hay demasiadas preguntas y muy poco tiempo para resolver esto ahora mismo, amigo."),
    "medium"
  );
});

test("percentile interpolates", () => {
  assert.equal(percentile([1, 2, 3, 4], 50), 2.5);
  assert.equal(percentile([10], 95), 10);
  assert.equal(percentile([], 50), 0);
});

test("mean of samples", () => {
  assert.equal(mean([10, 20, 30]), 20);
});

test("standardDeviation uses sample variance", () => {
  assert.equal(standardDeviation([1, 2, 3]), 1);
});

test("summarizeLatencies requires wallClockMs and uses it for throughput", () => {
  const samples = Array.from({ length: 10 }, (_, id) => ({
    totalMs: (id + 1) * 10,
    inferenceMs: (id + 1) * 8,
    queueMs: (id + 1) * 2,
    words: 5,
    characters: 20
  }));
  assert.throws(() => summarizeLatencies(samples), /wallClockMs/);
  const stats = summarizeLatencies(samples, 100);
  assert.equal(stats.count, 10);
  assert.equal(stats.wallClockMs, 100);
  assert.equal(stats.minMs, 10);
  assert.equal(stats.maxMs, 100);
  assert.equal(stats.translationsPerSecond, 100);
  assert.ok(stats.p50Ms > 0);
});

test("Mozilla vs Chrome classification uses plan gates", () => {
  const faster = classifyMozillaVsChrome(
    { p50Ms: 28, p95Ms: 48, p99Ms: 70, translationsPerSecond: 20 },
    { p50Ms: 65, p95Ms: 105 }
  );
  assert.equal(faster.winner, "MOZILLA");
  assert.equal(faster.strictWin, true);
  assert.equal(faster.translationClass, "VIABLE");

  const fail = classifyMozillaVsChrome(
    { p50Ms: 200, p95Ms: 280, p99Ms: 400, translationsPerSecond: 3 },
    { p50Ms: 50, p95Ms: 70 }
  );
  assert.equal(fail.winner, "FAIL");
  assert.equal(fail.absolutePass, false);
});
