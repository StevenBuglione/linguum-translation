import { test } from "node:test";
import assert from "node:assert/strict";
import {
  validateBenchmarkResult,
  validateMeasuredRun
} from "../src/translation/common/validate-result.js";

const validSequential = {
  engine: "mozilla-bergamot",
  version: "4.0",
  languagePair: "es-en",
  run: 1,
  round: 1,
  seed: 42001,
  corpusSha256: "a".repeat(64),
  mode: "sequential",
  environment: {
    cpu: "test-cpu",
    ramGb: 32,
    gpu: "test-gpu",
    windows: "Windows 11",
    playbackActive: false
  },
  model: { name: "model.esen.intgemm.alphas.bin", version: "2.0", bytes: 123 },
  engineSetupMs: 800,
  firstTranslationMs: 40,
  wallClockMs: 12000,
  translations: 500,
  p50Ms: 30,
  p90Ms: 40,
  p95Ms: 50,
  p99Ms: 70,
  meanMs: 32,
  translationsPerSecond: 25,
  wordsPerSecond: 200,
  samples: Array.from({ length: 500 }, (_, id) => ({
    id,
    source: `item-${id}`,
    translation: "x",
    totalMs: 20
  }))
};

const validPayload = {
  engine: "mozilla-bergamot",
  run: 1,
  round: 1,
  seed: 42001,
  corpusSha256: "a".repeat(64),
  results: [validSequential]
};

test("accepts a complete sequential result", () => {
  const { valid: ok, errors } = validateBenchmarkResult(validSequential);
  assert.equal(ok, true, errors.join("\n"));
});

test("accepts native engine id", () => {
  const native = { ...validSequential, engine: "mozilla-bergamot-native" };
  const { valid: ok, errors } = validateBenchmarkResult(native);
  assert.equal(ok, true, errors.join("\n"));
});

test("rejects missing p95 and unknown engine", () => {
  const { p95Ms, ...rest } = validSequential;
  const missing = validateBenchmarkResult(rest);
  assert.equal(missing.valid, false);
  const engine = validateBenchmarkResult({ ...validSequential, engine: "google-cloud" });
  assert.equal(engine.valid, false);
});

test("validateMeasuredRun rejects wrong run, engine, hash, and count", () => {
  const items = validSequential.samples.map((sample) => sample.source);
  const expected = {
    engine: "mozilla-bergamot",
    run: 1,
    round: 1,
    seed: 42001,
    corpusSha256: "a".repeat(64),
    sequentialCount: 500,
    items
  };
  assert.equal(validateMeasuredRun(validPayload, expected).valid, true);

  assert.equal(
    validateMeasuredRun({ ...validPayload, run: 2 }, expected).valid,
    false
  );
  assert.equal(
    validateMeasuredRun({ ...validPayload, engine: "chrome-translator-api" }, expected).valid,
    false
  );
  assert.equal(
    validateMeasuredRun({ ...validPayload, corpusSha256: "b".repeat(64) }, expected).valid,
    false
  );
  const short = {
    ...validPayload,
    results: [{ ...validSequential, samples: validSequential.samples.slice(0, 10), translations: 10 }]
  };
  assert.equal(validateMeasuredRun(short, expected).valid, false);
});

test("validateMeasuredRun rejects stale output whose sample order does not match the round corpus", () => {
  const items = validSequential.samples.map((sample) => sample.source);
  const swapped = [...items];
  swapped[17] = "different source";
  const result = validateMeasuredRun(validPayload, {
    engine: "mozilla-bergamot",
    run: 1,
    round: 1,
    seed: 42001,
    corpusSha256: "a".repeat(64),
    sequentialCount: 500,
    items: swapped
  });
  assert.equal(result.valid, false);
  assert.match(result.errors.join("\n"), /sample 17 source mismatch/);
});
