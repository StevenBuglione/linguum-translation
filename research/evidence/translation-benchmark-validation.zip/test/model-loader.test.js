import { test } from "node:test";
import assert from "node:assert/strict";
import {
  filesFromPairRecords,
  gemmPrecisionForModelName,
  pairId,
  selectBergamotWasm,
  selectLatestPair
} from "../src/translation/mozilla/model-loader.js";

test("pairId formats language pair", () => {
  assert.equal(pairId("es", "en"), "es-en");
});

test("selectLatestPair prefers highest version", () => {
  const records = [
    { fromLang: "es", toLang: "en", version: "2.0", last_modified: 1, fileType: "model" },
    { fromLang: "es", toLang: "en", version: "2.1", last_modified: 2, fileType: "model" },
    { fromLang: "es", toLang: "en", version: "2.1", last_modified: 3, fileType: "lex" },
    { fromLang: "en", toLang: "es", version: "9.9", last_modified: 9, fileType: "model" }
  ];
  const selected = selectLatestPair(records, "es", "en");
  assert.equal(selected.length, 2);
  assert.ok(selected.every((record) => record.version === "2.1"));
});

test("filesFromPairRecords requires model and vocab", () => {
  assert.throws(
    () =>
      filesFromPairRecords([
        {
          fileType: "lex",
          name: "lex.bin",
          version: "1",
          fromLang: "es",
          toLang: "en",
          hash: "abc",
          attachment: { hash: "abc", size: 1, location: "x", filename: "lex.bin" }
        }
      ]),
    /missing model/
  );
});

test("selectBergamotWasm picks newest translator build", () => {
  const selected = selectBergamotWasm([
    {
      name: "bergamot-translator",
      version: "3.0",
      last_modified: 1,
      hash: "aaa",
      attachment: { hash: "aaa", size: 1, location: "old.wasm", filename: "bergamot-translator.wasm" }
    },
    {
      name: "bergamot-translator",
      version: "4.0",
      last_modified: 2,
      hash: "bbb",
      attachment: { hash: "bbb", size: 2, location: "new.wasm", filename: "bergamot-translator.wasm" }
    },
    {
      name: "fasttext-wasm",
      version: "9.0",
      last_modified: 9,
      hash: "ccc",
      attachment: { hash: "ccc", size: 3, location: "ft.wasm", filename: "fasttext.wasm" }
    }
  ]);
  assert.equal(selected.version, "4.0");
  assert.match(selected.url, /new\.wasm$/);
});

test("gemm precision matches Firefox worker rules", () => {
  assert.equal(gemmPrecisionForModelName("model.esen.intgemm.alphas.bin"), "int8shiftAlphaAll");
  assert.equal(gemmPrecisionForModelName("model.esen.intgemm8.bin"), "int8shiftAll");
});
