import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { classifyBucket, wordCount } from "../src/translation/common/statistics.js";

const corpus = JSON.parse(
  readFileSync(new URL("../src/translation/common/corpus.json", import.meta.url), "utf8")
);

test("corpus has 500 unique Spanish strings in four buckets", () => {
  assert.equal(corpus.tiny.length, 100);
  assert.equal(corpus.short.length, 200);
  assert.equal(corpus.medium.length, 150);
  assert.equal(corpus.long.length, 50);
  assert.equal(corpus.items.length, 500);
  assert.equal(new Set(corpus.items).size, 500);
});

test("warmup isolation: 20 warmups, unique measured set, zero overlap, probe exclusive", () => {
  assert.equal(corpus.warmup.length, 20);
  assert.equal(corpus.items.length, 500);
  assert.equal(new Set(corpus.items).size, 500);
  assert.equal(typeof corpus.firstTranslationProbe, "string");
  assert.ok(corpus.firstTranslationProbe.length > 0);
  assert.equal(corpus.warmup.includes(corpus.firstTranslationProbe), false);
  assert.equal(corpus.items.includes(corpus.firstTranslationProbe), false);
  const intersection = corpus.warmup.filter((line) => corpus.items.includes(line));
  assert.deepEqual(intersection, []);
});

test("bucket word counts match the plan", () => {
  for (const line of corpus.tiny) {
    assert.equal(classifyBucket(line), "tiny", line);
    assert.ok(wordCount(line) >= 1 && wordCount(line) <= 4, line);
  }
  for (const line of corpus.short) {
    assert.equal(classifyBucket(line), "short", line);
  }
  for (const line of corpus.medium) {
    assert.equal(classifyBucket(line), "medium", line);
  }
  for (const line of corpus.long) {
    assert.equal(classifyBucket(line), "long", line);
  }
});

test("corpus includes realistic subtitle punctuation", () => {
  const joined = corpus.items.join("\n");
  assert.match(joined, /¿/);
  assert.match(joined, /¡|!/);
  assert.match(joined, /\.\.\./);
  assert.match(joined, /María/);
  assert.match(joined, /\d/);
});
