"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { createStaticServer } = require("../src/ecs/static-server.cjs");
const { repoRoot, safeResultsFile } = require("../src/ecs/diagnostics.cjs");
const {
  parseArgs,
  killBenchmarkChrome,
  killPidOnPort,
  launchChrome,
  waitForJsonFile,
  closeHttpServer,
  sleep
} = require("./lib/bench-util.cjs");

function toUrlPath(value) {
  const normalized = String(value).replaceAll("\\", "/");
  if (/^https?:\/\//i.test(normalized)) {
    return normalized;
  }
  return normalized.startsWith("/") ? normalized : `/${normalized}`;
}

async function main() {
  const args = parseArgs();
  if (!args.run || !args.output || !args.corpus) {
    throw new Error("usage: node scripts/run-chrome-bench.cjs --run N --corpus path --output path");
  }

  const root = repoRoot();
  const run = Number(args.run);
  const round = Number(args.round || args.run);
  const corpusPath = path.resolve(root, args.corpus);
  const roundCorpus = JSON.parse(fs.readFileSync(corpusPath, "utf8"));
  const outFile = safeResultsFile(args.output.replace(/^results[/\\]/, ""));
  const errorFile = outFile.replace(/\.json$/i, ".error.json");
  fs.rmSync(outFile, { force: true });
  fs.rmSync(errorFile, { force: true });
  killBenchmarkChrome();
  killPidOnPort(8766);
  await sleep(400);

  const { assertMeasuredRun } = await import("../src/translation/common/validate-result.js");

  let server = null;
  let origin = null;
  let lastBindError = null;
  for (const port of [8766, 8767, 8768, 8769, 8770]) {
    try {
      const started = await createStaticServer({ port });
      server = started.server;
      origin = started.origin;
      break;
    } catch (error) {
      lastBindError = error;
      console.error(`port ${port} unavailable: ${error.message}`);
    }
  }
  if (!server) {
    throw lastBindError || new Error("failed to bind chrome benchmark static server");
  }
  const corpusUrl = toUrlPath(path.relative(root, corpusPath));
  const outputRel = path.relative(path.join(root, "results"), outFile).replaceAll("\\", "/");
  const params = new URLSearchParams({
    autorun: "1",
    run: String(run),
    round: String(round),
    corpus: corpusUrl,
    output: outputRel,
    sequentialOnly: "1"
  });
  const url = `${origin}/src/translation/chrome/index.html?${params.toString()}`;
  console.log(`Opening isolated Chrome: ${url}`);
  const { child } = launchChrome(url);

  try {
    const payload = await waitForJsonFile(outFile, 20 * 60 * 1000, { errorFile });
    assertMeasuredRun(payload, {
      engine: "chrome-translator-api",
      run,
      round,
      seed: roundCorpus.seed,
      corpusSha256: roundCorpus.roundCorpusSha256,
      sequentialCount: 500,
      items: roundCorpus.items
    });
    console.log(`Saved ${outFile}`);
    const sequential = (payload.results || []).find((result) => result.mode === "sequential");
    if (sequential) {
      console.log(
        `Chrome sequential p50=${sequential.p50Ms.toFixed(2)} p95=${sequential.p95Ms.toFixed(2)} tps=${sequential.translationsPerSecond.toFixed(2)} chrome=${payload.chromeVersion || sequential.environment?.chromeVersion || "?"}`
      );
    }
  } finally {
    killBenchmarkChrome();
    if (child.pid) {
      try {
        process.kill(child.pid);
      } catch {
        // already gone
      }
    }
    await closeHttpServer(server);
  }
}

main().catch((error) => {
  console.error(error.stack || error);
  process.exit(1);
});
