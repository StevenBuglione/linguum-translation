"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { execFileSync } = require("node:child_process");
const { repoRoot } = require("../src/ecs/diagnostics.cjs");

const ROOT = repoRoot();
const REPO = path.join(ROOT, "native", "mozilla-translations-firefox");
const EXPECTED = "eea6e5a80aa4ddd86d9cc35ce9a65b79aa3ab96d";

function git(args) {
  return execFileSync("git", ["-C", REPO, ...args], { encoding: "utf8" }).trim();
}

const head = git(["rev-parse", "HEAD"]);
if (head !== EXPECTED) {
  throw new Error(`Firefox-pinned revision FAIL: ${head} != ${EXPECTED}`);
}
const version = fs
  .readFileSync(path.join(REPO, "inference", "BERGAMOT_VERSION"), "utf8")
  .trim();
if (version !== "v0.6.0") {
  throw new Error(`Bergamot version FAIL: ${version}`);
}
const submodules = git(["submodule", "status", "--recursive"]);
const lines = [
  "CURRENT MOZILLA SOURCE MANIFEST",
  `repository: mozilla/translations`,
  `HEAD: ${head}`,
  `BERGAMOT_VERSION: ${version}`,
  "",
  "submodule status --recursive",
  submodules,
  ""
];
const dest = path.join(ROOT, "results", "current-mozilla-source-manifest.txt");
fs.writeFileSync(dest, `${lines.join("\n")}\n`, "utf8");
console.log(lines.join("\n"));
console.log(`Wrote ${dest}`);
