import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  ROUND_COUNT,
  ROUND_SEEDS,
  buildRoundCorpus,
  hashItems,
  roundFileName
} from "../src/translation/common/rounds.js";

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");

export function generateRoundCorpora({
  corpusPath = path.join(ROOT, "src", "translation", "common", "corpus.json"),
  outDir = path.join(ROOT, "results", "corpora")
} = {}) {
  const corpus = JSON.parse(fs.readFileSync(corpusPath, "utf8"));

  if (!Array.isArray(corpus.items) || corpus.items.length !== 500) {
    throw new Error("base corpus items must contain exactly 500 measured strings");
  }
  if (new Set(corpus.items).size !== 500) {
    throw new Error("base corpus items must be unique");
  }

  const sourceCorpusSha256 = hashItems(corpus.items);
  fs.mkdirSync(outDir, { recursive: true });

  const written = [];
  for (let round = 1; round <= ROUND_COUNT; round += 1) {
    const seed = ROUND_SEEDS[round - 1];
    const roundCorpus = buildRoundCorpus(corpus.items, round, seed);
    if (roundCorpus.sourceCorpusSha256 !== sourceCorpusSha256) {
      throw new Error("source corpus hash mismatch while generating round corpora");
    }
    if (new Set(roundCorpus.items).size !== 500) {
      throw new Error(`round ${round} lost uniqueness`);
    }
    const sameSet =
      [...roundCorpus.items].sort().join("\n") === [...corpus.items].sort().join("\n");
    if (!sameSet) {
      throw new Error(`round ${round} changed the measured string set`);
    }
    const dest = path.join(outDir, roundFileName(round));
    fs.writeFileSync(dest, `${JSON.stringify(roundCorpus, null, 2)}\n`, "utf8");
    written.push({
      round,
      seed,
      file: dest,
      roundCorpusSha256: roundCorpus.roundCorpusSha256,
      sourceCorpusSha256
    });
  }

  const orders = written.map((row) =>
    JSON.parse(fs.readFileSync(row.file, "utf8")).items.join("\n")
  );
  if (new Set(orders).size !== ROUND_COUNT) {
    throw new Error("round corpora are not uniquely ordered");
  }

  return written;
}

const isDirectRun =
  Boolean(process.argv[1]) &&
  path.normalize(path.resolve(process.argv[1])).toLowerCase() ===
    path.normalize(fileURLToPath(import.meta.url)).toLowerCase();
if (isDirectRun) {
  const written = generateRoundCorpora();
  console.log(
    JSON.stringify(
      {
        ok: true,
        sourceCorpusSha256: written[0].sourceCorpusSha256,
        rounds: written.map((row) => ({
          round: row.round,
          seed: row.seed,
          roundCorpusSha256: row.roundCorpusSha256
        }))
      },
      null,
      2
    )
  );
}
