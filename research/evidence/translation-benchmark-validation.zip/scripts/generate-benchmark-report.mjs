import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { sequentialResult } from "../src/translation/common/validate-result.js";
import { median as medianFn, mean, standardDeviation, percentile } from "../src/translation/common/statistics.js";

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const RESULTS = path.join(ROOT, "results");

function readJson(rel) {
  return JSON.parse(fs.readFileSync(path.join(RESULTS, rel), "utf8"));
}

function fmt(value, digits = 2) {
  if (value === null || value === undefined || Number.isNaN(value) || value === Infinity) {
    return "";
  }
  return Number(value).toFixed(digits);
}

function yn(ok) {
  return ok ? "PASS" : "FAIL";
}

function oldNativeSummary() {
  const dir = path.join(RESULTS, "archive", "browsermt-9271618", "runs");
  if (!fs.existsSync(dir)) {
    return null;
  }
  const p50 = [];
  const p95 = [];
  const p99 = [];
  const tps = [];
  const shortP95 = [];
  const mediumP95 = [];
  const longP95 = [];
  for (let round = 1; round <= 6; round += 1) {
    const file = path.join(dir, `round-0${round}-native.json`);
    if (!fs.existsSync(file)) {
      return null;
    }
    const sequential = sequentialResult(JSON.parse(fs.readFileSync(file, "utf8")));
    p50.push(sequential.p50Ms);
    p95.push(sequential.p95Ms);
    p99.push(sequential.p99Ms);
    tps.push(sequential.translationsPerSecond);
    if (sequential.buckets) {
      shortP95.push(sequential.buckets.short.p95);
      mediumP95.push(sequential.buckets.medium.p95);
      longP95.push(sequential.buckets.long.p95);
    }
  }
  return {
    p50: medianFn(p50),
    p95: medianFn(p95),
    p99: medianFn(p99),
    tps: medianFn(tps),
    shortP95: shortP95.length ? medianFn(shortP95) : null,
    mediumP95: mediumP95.length ? medianFn(mediumP95) : null,
    longP95: longP95.length ? medianFn(longP95) : null
  };
}

const aggregate = readJson("aggregate/translation-comparison.json");
const machine = fs.existsSync(path.join(RESULTS, "machine.json"))
  ? readJson("machine.json")
  : {};
const preflight = fs.existsSync(path.join(RESULTS, "chrome-preflight.json"))
  ? readJson("chrome-preflight.json")
  : null;
const build = fs.existsSync(path.join(RESULTS, "current-mozilla-native-build.json"))
  ? readJson("current-mozilla-native-build.json")
  : null;
const agreement = fs.existsSync(path.join(RESULTS, "current-native-vs-wasm-differences.json"))
  ? readJson("current-native-vs-wasm-differences.json")
  : null;
const frozen = fs.existsSync(path.join(RESULTS, "frozen-baseline-sha256.json"))
  ? readJson("frozen-baseline-sha256.json")
  : null;

const chrome = aggregate.engines.chrome;
const wasm = aggregate.engines.wasm;
const native = aggregate.engines.native;
const vs = aggregate.nativeVsChrome;
const oldNative = oldNativeSummary();

const sourceOk = build?.revision === "eea6e5a80aa4ddd86d9cc35ce9a65b79aa3ab96d";
const sixRounds = native.runs?.length === 6;
const frozenOk = Boolean(frozen);
const absP95 = vs.p95Pass;
const absP99 = vs.p99Pass;
const tpsPass = vs.tpsPass;
const validated = sourceOk && sixRounds && frozenOk && absP95 && absP99 && tpsPass;

const lines = [];
const push = (line = "") => lines.push(line);

push("TRANSLATION PERFORMANCE VALIDATION");
push("");
push(`Rounds completed: ${aggregate.roundsCompleted} / 6`);
push(`Samples per engine per round: ${aggregate.samplesPerEnginePerRound}`);
push(`Total measured samples per engine: ${aggregate.totalMeasuredSamplesPerEngine}`);
push("Warmup per engine per run: 20");
push("Warmup overlap with corpus: 0");
push("Corpus order: deterministic and paired per round");
push(`Chrome model pre-downloaded: ${preflight?.availabilityAfter === "available" ? "YES" : "UNKNOWN"}`);
push("Caches:");
push("  WASM Bergamot: 0");
push("  Native Bergamot: 0");
push("");
push("NATIVE ENGINE SOURCE");
push("");
push("Repository:");
push("mozilla/translations");
push("");
push("Firefox-pinned revision:");
push("eea6e5a80aa4ddd86d9cc35ce9a65b79aa3ab96d");
push("");
push("Bergamot:");
push("v0.6.0");
push("");
push("Service:");
push("AsyncService");
push("");
push("Workers:");
push("1");
push("");
push("Cache:");
push("0");
push("");
push("CPU backend:");
push("FBGEMM");
push("");
push("Build:");
push("Release x64");
push("");
push("Architecture:");
push("AVX2");
push("");
push("Machine");
push("──────────────────────────");
push(`CPU: ${machine.cpu || ""}`);
push(`RAM: ${machine.ramGb || ""} GB`);
push(`Windows: ${machine.windows || ""}`);
push(`GPU: ${machine.gpu || ""}`);
push(`Chrome version: ${preflight?.chromeVersion || ""}`);
push("");
push("                         Chrome       WASM       Native");
push("");
push(`Median run p50           ${fmt(chrome.acrossRuns.p50Ms.median).padStart(8)}   ${fmt(wasm.acrossRuns.p50Ms.median).padStart(8)}   ${fmt(native.acrossRuns.p50Ms.median).padStart(8)}`);
push(`Median run p95           ${fmt(chrome.acrossRuns.p95Ms.median).padStart(8)}   ${fmt(wasm.acrossRuns.p95Ms.median).padStart(8)}   ${fmt(native.acrossRuns.p95Ms.median).padStart(8)}`);
push(`Median run p99           ${fmt(chrome.acrossRuns.p99Ms.median).padStart(8)}   ${fmt(wasm.acrossRuns.p99Ms.median).padStart(8)}   ${fmt(native.acrossRuns.p99Ms.median).padStart(8)}`);
push("");
push(`Mean run p50             ${fmt(chrome.acrossRuns.p50Ms.mean).padStart(8)}   ${fmt(wasm.acrossRuns.p50Ms.mean).padStart(8)}   ${fmt(native.acrossRuns.p50Ms.mean).padStart(8)}`);
push(`Mean run p95             ${fmt(chrome.acrossRuns.p95Ms.mean).padStart(8)}   ${fmt(wasm.acrossRuns.p95Ms.mean).padStart(8)}   ${fmt(native.acrossRuns.p95Ms.mean).padStart(8)}`);
push(`Mean run p99             ${fmt(chrome.acrossRuns.p99Ms.mean).padStart(8)}   ${fmt(wasm.acrossRuns.p99Ms.mean).padStart(8)}   ${fmt(native.acrossRuns.p99Ms.mean).padStart(8)}`);
push("");
push(`p95 stddev               ${fmt(chrome.acrossRuns.p95Ms.stddev).padStart(8)}   ${fmt(wasm.acrossRuns.p95Ms.stddev).padStart(8)}   ${fmt(native.acrossRuns.p95Ms.stddev).padStart(8)}`);
push("");
push(`Pooled p50               ${fmt(chrome.pooled.p50Ms).padStart(8)}   ${fmt(wasm.pooled.p50Ms).padStart(8)}   ${fmt(native.pooled.p50Ms).padStart(8)}`);
push(`Pooled p95               ${fmt(chrome.pooled.p95Ms).padStart(8)}   ${fmt(wasm.pooled.p95Ms).padStart(8)}   ${fmt(native.pooled.p95Ms).padStart(8)}`);
push(`Pooled p99               ${fmt(chrome.pooled.p99Ms).padStart(8)}   ${fmt(wasm.pooled.p99Ms).padStart(8)}   ${fmt(native.pooled.p99Ms).padStart(8)}`);
push("");
push(`Median TPS               ${fmt(chrome.acrossRuns.translationsPerSecond.median).padStart(8)}   ${fmt(wasm.acrossRuns.translationsPerSecond.median).padStart(8)}   ${fmt(native.acrossRuns.translationsPerSecond.median).padStart(8)}`);
push(`Median words/sec         ${fmt(chrome.acrossRuns.wordsPerSecond.median).padStart(8)}   ${fmt(wasm.acrossRuns.wordsPerSecond.median).padStart(8)}   ${fmt(native.acrossRuns.wordsPerSecond.median).padStart(8)}`);
push("");
push("CURRENT FIREFOX NATIVE");
push("");
for (const run of native.runs) {
  push(`Round ${run.round}`);
  push(`p50: ${fmt(run.p50Ms)}`);
  push(`p95: ${fmt(run.p95Ms)}`);
  push(`p99: ${fmt(run.p99Ms)}`);
  push(`TPS: ${fmt(run.translationsPerSecond)}`);
  push("");
}
push("CURRENT FIREFOX NATIVE AGGREGATE");
push("");
push(`Median p50: ${fmt(native.acrossRuns.p50Ms.median)}`);
push(`Median p95: ${fmt(native.acrossRuns.p95Ms.median)}`);
push(`Median p99: ${fmt(native.acrossRuns.p99Ms.median)}`);
push(`Median TPS: ${fmt(native.acrossRuns.translationsPerSecond.median)}`);
push("");
push(`Mean p50: ${fmt(native.acrossRuns.p50Ms.mean)}`);
push(`Mean p95: ${fmt(native.acrossRuns.p95Ms.mean)}`);
push(`Mean p99: ${fmt(native.acrossRuns.p99Ms.mean)}`);
push("");
push(`p95 stddev: ${fmt(native.acrossRuns.p95Ms.stddev)}`);
push("");
push("| Metric              | Chrome | Firefox WASM | Old Native | Current Firefox Native |");
push("| ------------------- | -----: | -----------: | ---------: | ---------------------: |");
push(`| Median p50          | ${fmt(chrome.acrossRuns.p50Ms.median)} | ${fmt(wasm.acrossRuns.p50Ms.median)} | ${fmt(oldNative?.p50)} | ${fmt(native.acrossRuns.p50Ms.median)} |`);
push(`| Median p95          | ${fmt(chrome.acrossRuns.p95Ms.median)} | ${fmt(wasm.acrossRuns.p95Ms.median)} | ${fmt(oldNative?.p95)} | ${fmt(native.acrossRuns.p95Ms.median)} |`);
push(`| Median p99          | ${fmt(chrome.acrossRuns.p99Ms.median)} | ${fmt(wasm.acrossRuns.p99Ms.median)} | ${fmt(oldNative?.p99)} | ${fmt(native.acrossRuns.p99Ms.median)} |`);
push(`| TPS                 | ${fmt(chrome.acrossRuns.translationsPerSecond.median)} | ${fmt(wasm.acrossRuns.translationsPerSecond.median)} | ${fmt(oldNative?.tps)} | ${fmt(native.acrossRuns.translationsPerSecond.median)} |`);
push(`| Short subtitle p95  | ${fmt(chrome.buckets.short.p95)} | ${fmt(wasm.buckets.short.p95)} | ${fmt(oldNative?.shortP95)} | ${fmt(native.buckets.short.p95)} |`);
push(`| Medium subtitle p95 | ${fmt(chrome.buckets.medium.p95)} | ${fmt(wasm.buckets.medium.p95)} | ${fmt(oldNative?.mediumP95)} | ${fmt(native.buckets.medium.p95)} |`);
push(`| Long subtitle p95   | ${fmt(chrome.buckets.long.p95)} | ${fmt(wasm.buckets.long.p95)} | ${fmt(oldNative?.longP95)} | ${fmt(native.buckets.long.p95)} |`);
push("");
push("CURRENT FIREFOX NATIVE VS CHROME");
push("");
push(`p50 wins: ${vs.p50Wins} / 6`);
push(`p95 wins: ${vs.p95Wins} / 6`);
push(`p99 wins: ${vs.p99Wins} / 6`);
push("");
push("median p50 ratio:");
push(`native / chrome = ${fmt(vs.medianP50Ratio, 3)}`);
push("");
push("median p95 ratio:");
push(`native / chrome = ${fmt(vs.medianP95Ratio, 3)}`);
push("");
push("median p99 ratio:");
push(`native / chrome = ${fmt(vs.medianP99Ratio, 3)}`);
push("");
if (oldNative) {
  push("CURRENT FIREFOX NATIVE VS OLD NATIVE");
  push("");
  push(`p50 delta: ${fmt(native.acrossRuns.p50Ms.median - oldNative.p50)} ms (ratio ${fmt(native.acrossRuns.p50Ms.median / oldNative.p50, 3)})`);
  push(`p95 delta: ${fmt(native.acrossRuns.p95Ms.median - oldNative.p95)} ms (ratio ${fmt(native.acrossRuns.p95Ms.median / oldNative.p95, 3)})`);
  push(`p99 delta: ${fmt(native.acrossRuns.p99Ms.median - oldNative.p99)} ms (ratio ${fmt(native.acrossRuns.p99Ms.median / oldNative.p99, 3)})`);
  push(`throughput delta: ${fmt(native.acrossRuns.translationsPerSecond.median - oldNative.tps)} TPS (ratio ${fmt(native.acrossRuns.translationsPerSecond.median / oldNative.tps, 3)})`);
  push("");
}
push("STARTUP — INFORMATIONAL");
push("");
push(`Median engineSetupMs Chrome/WASM/Native: ${fmt(chrome.acrossRuns.engineSetupMs.median)} / ${fmt(wasm.acrossRuns.engineSetupMs.median)} / ${fmt(native.acrossRuns.engineSetupMs.median)}`);
push(`Median firstTranslationMs Chrome/WASM/Native: ${fmt(chrome.acrossRuns.firstTranslationMs.median)} / ${fmt(wasm.acrossRuns.firstTranslationMs.median)} / ${fmt(native.acrossRuns.firstTranslationMs.median)}`);
push("");
push("CURRENT FIREFOX NATIVE BERGAMOT");
push("");
push("Source verification:");
push(yn(sourceOk));
push("");
push("Firefox-pinned revision:");
push(yn(sourceOk));
push("");
push("Six rounds completed:");
push(yn(sixRounds));
push("");
push("Same frozen corpora:");
push(yn(frozenOk));
push("");
push("Chrome/WASM baselines unchanged:");
push(yn(frozenOk));
push("");
push("Absolute subtitle p95:");
push(yn(absP95));
push("");
push("Absolute subtitle p99:");
push(yn(absP99));
push("");
push("Throughput:");
push(yn(tpsPass));
push("");
push("Native vs Chrome:");
push(vs.decision);
push("");
push("Output agreement with Firefox WASM:");
if (agreement) {
  push(`${agreement.exactMatches} / 500`);
  push(`${agreement.exactMatchPercent}%`);
} else {
  push("not computed");
}
push("");
push("FINAL DECISION:");
push("");
push(validated ? "CURRENT MOZILLA NATIVE TRANSLATION" : "CURRENT MOZILLA NATIVE TRANSLATION");
push(validated ? "IS VALIDATED." : "IS NOT VALIDATED.");
push("");
push("KOTLIN INTEGRATION: DO NOT START automatically. Return these results for architectural review first.");

const dest = path.join(RESULTS, "FINAL_BENCHMARK_REPORT.md");
fs.writeFileSync(dest, `${lines.join("\n")}\n`, "utf8");
console.log(lines.join("\n"));
console.log(`Wrote ${dest}`);
