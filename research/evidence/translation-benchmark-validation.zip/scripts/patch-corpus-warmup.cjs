"use strict";

const fs = require("node:fs");
const path = require("node:path");

const corpusPath = path.join(__dirname, "..", "src", "translation", "common", "corpus.json");
const corpus = JSON.parse(fs.readFileSync(corpusPath, "utf8"));

if (corpus.items.length !== 500 || new Set(corpus.items).size !== 500) {
  throw new Error("refusing to patch: measured corpus is not 500 unique items");
}

corpus.firstTranslationProbe =
  "Esta oración se usa únicamente para medir la primera traducción.";
corpus.warmup = [
  "Lucía dejó las llaves junto a la ventana.",
  "Mañana iremos temprano al mercado central.",
  "El ascensor se detuvo en el séptimo piso.",
  "Carlos prometió llamar después de la reunión.",
  "Nunca había visto una tormenta tan silenciosa.",
  "Guarda ese documento antes de cerrar la computadora.",
  "El café de la esquina abre a las seis.",
  "Necesitamos otra botella de agua para el viaje.",
  "La puerta azul conduce al patio interior.",
  "Recuérdame comprar pan cuando salgamos.",
  "Anoche dejaron un paquete frente a mi casa.",
  "El autobús cambia de ruta durante el festival.",
  "Prefiero sentarme cerca de la salida.",
  "La reserva está a nombre de Daniela Torres.",
  "Apaga la luz del pasillo cuando termines.",
  "El museo cierra media hora más tarde los viernes.",
  "Nos encontraremos debajo del reloj de la estación.",
  "Olvidé cargar el teléfono antes de salir.",
  "El perro escondió su juguete detrás del sofá.",
  "Pon la chaqueta en la silla junto a la puerta."
];

const overlap = corpus.warmup.filter((line) => corpus.items.includes(line));
if (overlap.length) {
  throw new Error(`warmup overlaps measured corpus: ${overlap.join(" | ")}`);
}
if (corpus.items.includes(corpus.firstTranslationProbe)) {
  throw new Error("probe is present in measured corpus");
}
if (corpus.warmup.includes(corpus.firstTranslationProbe)) {
  throw new Error("probe is present in warmup");
}

const ordered = {
  language: corpus.language,
  target: corpus.target,
  generatedAt: corpus.generatedAt,
  counts: corpus.counts,
  firstTranslationProbe: corpus.firstTranslationProbe,
  warmup: corpus.warmup,
  tiny: corpus.tiny,
  short: corpus.short,
  medium: corpus.medium,
  long: corpus.long,
  items: corpus.items
};

fs.writeFileSync(corpusPath, `${JSON.stringify(ordered, null, 2)}\n`, "utf8");
console.log(
  `Patched ${corpusPath}: warmup=${ordered.warmup.length} items=${ordered.items.length}`
);
