import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { sequentialResult } from "../src/translation/common/validate-result.js";

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const RESULTS = path.join(ROOT, "results");

function loadSamples(engine, round) {
  const file = path.join(RESULTS, "runs", `round-0${round}-${engine}.json`);
  const sequential = sequentialResult(JSON.parse(fs.readFileSync(file, "utf8")));
  return sequential.samples || [];
}

const wasmBySource = new Map();
for (const sample of loadSamples("wasm", 1)) {
  wasmBySource.set(sample.source, sample.translation);
}

const nativeBySource = new Map();
for (const sample of loadSamples("native", 1)) {
  nativeBySource.set(sample.source, sample.translation);
}

if (wasmBySource.size !== 500 || nativeBySource.size !== 500) {
  throw new Error(`expected 500 unique sources, wasm=${wasmBySource.size} native=${nativeBySource.size}`);
}

const differences = [];
let matches = 0;
for (const [source, wasm] of wasmBySource) {
  const native = nativeBySource.get(source);
  if (native === wasm) {
    matches += 1;
  } else {
    differences.push({ source, wasm, native: native ?? "" });
  }
}

const payload = {
  comparedBy: "source-text",
  uniqueSources: 500,
  exactMatches: matches,
  different: differences.length,
  exactMatchPercent: Number(((matches / 500) * 100).toFixed(2)),
  differences
};
fs.writeFileSync(
  path.join(RESULTS, "current-native-vs-wasm-differences.json"),
  `${JSON.stringify(payload, null, 2)}\n`,
  "utf8"
);

const review = [
  "CURRENT FIREFOX NATIVE vs FIREFOX WASM — first 50 differences",
  "",
  `exact matches: ${matches} / 500 (${payload.exactMatchPercent}%)`,
  `different: ${differences.length} / 500`,
  "",
  "Do not treat non-100% equality as an automatic failure. AsyncService and BlockingService may differ.",
  ""
];
for (const [index, row] of differences.slice(0, 50).entries()) {
  review.push(`## ${index + 1}`);
  review.push("");
  review.push("source:");
  review.push(row.source);
  review.push("");
  review.push("WASM:");
  review.push(row.wasm);
  review.push("");
  review.push("native:");
  review.push(row.native);
  review.push("");
}
fs.writeFileSync(path.join(RESULTS, "current-native-vs-wasm-review.md"), `${review.join("\n")}\n`, "utf8");
console.log(`exact matches: ${matches} / 500 (${payload.exactMatchPercent}%)`);
console.log(`Wrote results/current-native-vs-wasm-differences.json`);
console.log(`Wrote results/current-native-vs-wasm-review.md`);
