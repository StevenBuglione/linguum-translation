"use strict";

const path = require("node:path");
const { collectMachine, writeJson, repoRoot } = require("../src/ecs/diagnostics.cjs");

collectMachine()
  .then((machine) => {
    const file = path.join(repoRoot(), "results", "machine.json");
    writeJson(file, machine);
    console.log(JSON.stringify(machine, null, 2));
    console.log(`Wrote ${file}`);
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
