import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  classifyMozillaVsChrome
} from "../src/translation/common/statistics.js";

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const RESULTS = path.join(ROOT, "results");

function readJson(name) {
  const file = path.join(RESULTS, name);
  if (!fs.existsSync(file)) {
    return null;
  }
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function sequential(bundle) {
  if (!bundle) {
    return null;
  }
  if (Array.isArray(bundle.results)) {
    return bundle.results.find((result) => result.mode === "sequential") || bundle.results[0];
  }
  return bundle;
}

function fmt(value, digits = 2) {
  if (value === null || value === undefined || Number.isNaN(value)) {
    return "";
  }
  return Number(value).toFixed(digits);
}

function winner(a, b, higherIsBetter = false) {
  if (a == null || b == null || a === "" || b === "") {
    return "";
  }
  if (higherIsBetter) {
    if (a > b) return "Mozilla";
    if (b > a) return "Chrome";
    return "tie";
  }
  if (a < b) return "Mozilla";
  if (b < a) return "Chrome";
  return "tie";
}

function serviceLine(streaming, id) {
  const row = streaming?.services?.[id];
  if (!row) {
    return "NOT RUN (login required)";
  }
  const pass = ["video", "audio", "fullscreen", "subtitles"].every(
    (key) => row[key] === true || row.checklist?.[key] === "pass"
  );
  if (pass) {
    return "PASS";
  }
  const pending = ["pending", "needs-user-gesture", "blocked-login", "not-required"].includes(
    row.video
  ) || row.checklist?.video === "pending";
  if (pending) {
    return "INCOMPLETE (waiting for login or user gesture)";
  }
  return "FAIL / INCOMPLETE";
}

const machine = readJson("machine.json") || {};
const mozilla = sequential(readJson("mozilla-translation.json"));
const chrome = sequential(readJson("chrome-translation.json"));
const native = sequential(readJson("native-bergamot-translation.json"));
const streaming = readJson("streaming.json");
const playback = readJson("playback-translation.json");

const comparison =
  mozilla && chrome ? classifyMozillaVsChrome(mozilla, chrome) : null;

const mozillaShort = mozilla?.buckets?.short || null;
const chromeShort = chrome?.buckets?.short || null;
const mozillaLong = mozilla?.buckets?.long || null;
const chromeLong = chrome?.buckets?.long || null;

const report = `# FINAL_REPORT

WINDOWS ARCHITECTURE SPIKE

Host
──────────────────────────
Windows 11: ${machine.windows ? "PASS" : "UNKNOWN"}
Physical local session: ${machine.session?.physicalLocalSession ? "YES" : "UNKNOWN"}
RDP: ${machine.session?.rdp ? "CONNECTED" : "DISCONNECTED"}
CPU: ${machine.cpu || ""}
RAM: ${machine.ramGb || ""} GB
GPU: ${machine.gpu || ""}
GPU driver: ${machine.gpuDriver || ""}
Display: ${machine.displayResolution || ""} @ ${machine.refreshRate || "?"} Hz


CastLabs ECS
──────────────────────────
Version: ${machine.versions?.electron || "43.2.0+wvcus (pinned)"}
Chromium: ${machine.versions?.chrome || ""}
Node: ${machine.versions?.node || machine.node || ""}
Widevine: ${machine.widevine ? "recorded" : "see ECS run"}

Netflix: ${serviceLine(streaming, "netflix")}
Prime:   ${serviceLine(streaming, "prime")}
Max:     ${serviceLine(streaming, "max")}
YouTube control: ${serviceLine(streaming, "youtube")}

UA spoof:             NO
Browser flags:        NO
DRM workaround:       NO
Custom codecs:        NO
Custom Chromium:      NO


Translation
──────────────────────────
Pair: Spanish → English

Chrome Translator API

p50: ${fmt(chrome?.p50Ms)}
p95: ${fmt(chrome?.p95Ms)}
p99: ${fmt(chrome?.p99Ms)}
translations/sec: ${fmt(chrome?.translationsPerSecond)}


Mozilla Firefox Translations / Bergamot WASM

p50: ${fmt(mozilla?.p50Ms)}
p95: ${fmt(mozilla?.p95Ms)}
p99: ${fmt(mozilla?.p99Ms)}
translations/sec: ${fmt(mozilla?.translationsPerSecond)}


Mozilla Bergamot native C++

p50: ${fmt(native?.p50Ms)}
p95: ${fmt(native?.p95Ms)}
p99: ${fmt(native?.p99Ms)}
translations/sec: ${fmt(native?.translationsPerSecond)}


Mozilla vs Chrome
──────────────────────────
WASM p50 ratio vs Chrome: ${fmt(comparison?.p50Ratio)}
WASM p95 ratio vs Chrome: ${fmt(comparison?.p95Ratio)}
Native p50 ratio vs Chrome: ${chrome?.p50Ms ? fmt(native?.p50Ms / chrome.p50Ms) : ""}
Native p95 ratio vs Chrome: ${chrome?.p95Ms ? fmt(native?.p95Ms / chrome.p95Ms) : ""}
Native vs WASM p95: ${mozilla?.p95Ms ? fmt(native?.p95Ms / mozilla.p95Ms) : ""}

Winner (WASM vs Chrome):
${comparison?.winner || "INCOMPLETE"}

Winner including native C++:
${
  native && chrome
    ? native.p50Ms < chrome.p50Ms && native.p95Ms < chrome.p95Ms
      ? "NATIVE MOZILLA BERGAMOT"
      : "CHROME"
    : "INCOMPLETE"
}

STRICT_WIN: ${comparison?.strictWin ? "YES" : "NO"}
Throughput >= 10/sec: ${comparison?.throughputPass ? "YES" : "NO / UNKNOWN"}


Streaming + Mozilla
──────────────────────────
Netflix: ${playback?.netflix?.status || serviceLine(streaming, "netflix")}
Prime: ${playback?.prime?.status || serviceLine(streaming, "prime")}
Max: ${playback?.max?.status || serviceLine(streaming, "max")}

Translation p95 while playing: ${fmt(playback?.p95Ms)}
Dropped-frame impact: ${playback?.droppedFrameImpact ?? ""}
Audio impact: ${playback?.audioImpact ?? ""}
DRM impact: ${playback?.drmImpact ?? ""}


FINAL DECISION
──────────────────────────

CASTLABS ECS:
${streaming ? "SEE SERVICE LINES ABOVE" : "NOT YET RUN (login required)"}

MOZILLA TRANSLATION:
${comparison?.translationClass || (mozilla ? "MEASURED" : "NOT YET RUN")}

OVERALL DESKTOP ARCHITECTURE:
${
  comparison?.translationClass === "VIABLE" && streaming
    ? "PENDING STREAMING GATES"
    : "INCOMPLETE UNTIL LOGIN + BENCHES"
}

## Comparison table

| Metric              | WASM Bergamot | Native C++ Bergamot | Chrome Translator |
| ------------------- | ------------: | ------------------: | ----------------: |
| Warm p50            | ${fmt(mozilla?.p50Ms)} ms | ${fmt(native?.p50Ms)} ms | ${fmt(chrome?.p50Ms)} ms |
| Warm p95            | ${fmt(mozilla?.p95Ms)} ms | ${fmt(native?.p95Ms)} ms | ${fmt(chrome?.p95Ms)} ms |
| Warm p99            | ${fmt(mozilla?.p99Ms)} ms | ${fmt(native?.p99Ms)} ms | ${fmt(chrome?.p99Ms)} ms |
| translations/sec    | ${fmt(mozilla?.translationsPerSecond)} | ${fmt(native?.translationsPerSecond)} | ${fmt(chrome?.translationsPerSecond)} |
| words/sec           | ${fmt(mozilla?.wordsPerSecond)} | ${fmt(native?.wordsPerSecond)} | ${fmt(chrome?.wordsPerSecond)} |
| cold initialization | ${fmt(mozilla?.initializationMs)} | ${fmt(native?.initializationMs)} | ${fmt(chrome?.initializationMs)} |

## Playback table

| Mozilla under video  | Netflix | Prime | Max |
| -------------------- | ------: | ----: | --: |
| p50                  | ${fmt(playback?.netflix?.p50Ms)} | ${fmt(playback?.prime?.p50Ms)} | ${fmt(playback?.max?.p50Ms)} |
| p95                  | ${fmt(playback?.netflix?.p95Ms)} | ${fmt(playback?.prime?.p95Ms)} | ${fmt(playback?.max?.p95Ms)} |
| p99                  | ${fmt(playback?.netflix?.p99Ms)} | ${fmt(playback?.prime?.p99Ms)} | ${fmt(playback?.max?.p99Ms)} |
| Video remains smooth | ${playback?.netflix?.video || ""} | ${playback?.prime?.video || ""} | ${playback?.max?.video || ""} |
| Audio remains smooth | ${playback?.netflix?.audio || ""} | ${playback?.prime?.audio || ""} | ${playback?.max?.audio || ""} |
| DRM remains active   | ${playback?.netflix?.drm || ""} | ${playback?.prime?.drm || ""} | ${playback?.max?.drm || ""} |
`;

fs.mkdirSync(RESULTS, { recursive: true });
fs.writeFileSync(path.join(RESULTS, "FINAL_REPORT.md"), report, "utf8");
console.log(report);
