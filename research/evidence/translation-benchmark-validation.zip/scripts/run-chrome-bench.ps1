$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
$run = "1"
if ($args.Count -ge 1) { $run = $args[0] }
Write-Host "Chrome Translator API bench in installed Google Chrome, run $run"
node scripts/run-chrome-bench.cjs --run $run --fresh
