$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

$session = $env:SESSIONNAME
if ($session -match "RDP") {
  Write-Error "PLAN.md forbids RDP. Disconnect remote desktop and run on the physical console."
}

Write-Host "Launching CastLabs ECS harness on the physical session."
Write-Host "Authenticate in Netflix, Prime, and Max when the streaming windows open."
Write-Host "YouTube is the no-login control."
npx electron . --mode=harness
