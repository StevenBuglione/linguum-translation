"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { parseArgs, repoRoot } = require("./lib/bench-util.cjs");

async function main() {
  const { ENGINE_IDS: ids } = await import("../src/translation/common/rounds.js");
  const { assertMeasuredRun } = await import("../src/translation/common/validate-result.js");
  const args = parseArgs();
  const root = repoRoot();
  const engineKey = args.engine;
  const round = Number(args.round || args.run);
  if (!ids[engineKey]) {
    throw new Error(`unknown engine ${engineKey}`);
  }
  const corpus = JSON.parse(fs.readFileSync(path.resolve(root, args.corpus), "utf8"));
  const payload = JSON.parse(fs.readFileSync(path.resolve(root, args.output), "utf8"));
  assertMeasuredRun(payload, {
    engine: ids[engineKey],
    run: round,
    round,
    seed: corpus.seed,
    corpusSha256: corpus.roundCorpusSha256,
    sequentialCount: 500,
    items: corpus.items
  });
  console.log(`validated ${args.output}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
