"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { repoRoot, writeJson } = require("../src/ecs/diagnostics.cjs");
const { sha256File } = require("./lib/bench-util.cjs");

const ROOT = repoRoot();
const RESULTS = path.join(ROOT, "results");
const ARCHIVE = path.join(RESULTS, "archive", "browsermt-9271618");

function copyFile(src, dest) {
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(src, dest);
}

function hashOrThrow(rel) {
  const file = path.join(RESULTS, rel);
  if (!fs.existsSync(file)) {
    throw new Error(`missing ${rel}`);
  }
  return sha256File(file);
}

const archiveFiles = [
  "runs/round-01-native.json",
  "runs/round-02-native.json",
  "runs/round-03-native.json",
  "runs/round-04-native.json",
  "runs/round-05-native.json",
  "runs/round-06-native.json",
  "aggregate/translation-comparison.json",
  "FINAL_BENCHMARK_REPORT.md"
];

for (const rel of archiveFiles) {
  copyFile(path.join(RESULTS, rel), path.join(ARCHIVE, rel));
}

const oldNative = JSON.parse(
  fs.readFileSync(path.join(RESULTS, "runs", "round-01-native.json"), "utf8")
);
writeJson(path.join(ARCHIVE, "native-build-manifest.json"), {
  engine: "mozilla-bergamot-native",
  implementation: "browsermt-native",
  sourceRepository: "browsermt/bergamot-translator",
  sourceRevision: "9271618ebbdc5d21ac4dc4df9e72beb7ce644774",
  marianCommit: oldNative.marianCommit || "2781d735",
  service: oldNative.service || "AsyncService",
  workers: oldNative.workers ?? 1,
  cacheSize: oldNative.cacheSize ?? 0,
  build: oldNative.build || "Release",
  architecture: oldNative.architecture || "x64",
  cpuIsa: oldNative.cpuIsa || "AVX2",
  intgemm: oldNative.intgemm ?? true,
  sgemm: oldNative.sgemm || "onnxjs-fallback",
  binary: "native/bergamot-translator/build-native/app/native-bench.exe",
  archivedAt: new Date().toISOString()
});

const chrome = {};
const wasm = {};
const corpora = {};
for (let round = 1; round <= 6; round += 1) {
  const pad = String(round).padStart(2, "0");
  chrome[`round-${pad}`] = hashOrThrow(`runs/round-${pad}-chrome.json`);
  wasm[`round-${pad}`] = hashOrThrow(`runs/round-${pad}-wasm.json`);
  corpora[`round-${pad}`] = hashOrThrow(`corpora/round-${pad}.json`);
}

const modelPath = path.join(ROOT, "artifacts", "mozilla", "models", "es-en", "model.esen.intgemm.alphas.bin");
const vocabPath = path.join(ROOT, "artifacts", "mozilla", "models", "es-en", "vocab.esen.spm");
const lexPath = path.join(ROOT, "artifacts", "mozilla", "models", "es-en", "lex.50.50.esen.s2t.bin");
const modelSha = sha256File(modelPath);
if (modelSha !== "4aed7734152ae0045d1a69ae49c86cfda18f53c61f90e95e1d1de1c7c7c3b033") {
  throw new Error(`es-en model hash mismatch: ${modelSha}`);
}

const frozen = {
  generatedAt: new Date().toISOString(),
  chrome,
  wasm,
  corpora,
  models: {
    "model.esen.intgemm.alphas.bin": modelSha,
    "vocab.esen.spm": sha256File(vocabPath),
    "lex.50.50.esen.s2t.bin": sha256File(lexPath)
  }
};
writeJson(path.join(RESULTS, "frozen-baseline-sha256.json"), frozen);
console.log(JSON.stringify(frozen, null, 2));
console.log(`Archived old native results to ${ARCHIVE}`);
