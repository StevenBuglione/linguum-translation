"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { spawnSync } = require("node:child_process");

const ROOT = path.join(__dirname, "..");
const STAGE = path.join(path.dirname(ROOT), "performance-test-handoff-min");
const ZIP = path.join(path.dirname(ROOT), "performance-test-handoff-min.zip");

const SKIP_DIR_NAMES = new Set([
  "node_modules",
  "bergamot-translator",
  "mozilla-translations-firefox",
  "build-native",
  "build-harness",
  "chrome-benchmark-profile",
  ".git"
]);

const SKIP_FILE_EXTS = new Set([
  ".exe",
  ".dll",
  ".lib",
  ".pdb",
  ".obj",
  ".wasm",
  ".zst",
  ".bin",
  ".spm",
  ".node",
  ".tflite"
]);

function shouldSkipDir(name) {
  return SKIP_DIR_NAMES.has(name);
}

function shouldSkipFile(filePath, name) {
  const ext = path.extname(name).toLowerCase();
  if (SKIP_FILE_EXTS.has(ext)) {
    return true;
  }
  if (name === "native-bench.exe") {
    return true;
  }
  const rel = path.relative(ROOT, filePath).replaceAll("\\", "/");
  if (rel.startsWith("artifacts/mozilla/models/")) {
    return true;
  }
  if (rel.startsWith("artifacts/mozilla/engine/") && ext !== ".js" && ext !== ".json") {
    return true;
  }
  return false;
}

function copyTree(fromDir, toDir) {
  fs.mkdirSync(toDir, { recursive: true });
  for (const entry of fs.readdirSync(fromDir, { withFileTypes: true })) {
    if (entry.name.startsWith(".") && entry.name !== ".gitkeep") {
      continue;
    }
    const src = path.join(fromDir, entry.name);
    const dest = path.join(toDir, entry.name);
    if (entry.isDirectory()) {
      if (shouldSkipDir(entry.name)) {
        continue;
      }
      copyTree(src, dest);
      continue;
    }
    if (shouldSkipFile(src, entry.name)) {
      continue;
    }
    fs.copyFileSync(src, dest);
  }
}

if (fs.existsSync(STAGE)) {
  fs.rmSync(STAGE, { recursive: true, force: true });
}
if (fs.existsSync(ZIP)) {
  fs.rmSync(ZIP, { force: true });
}

copyTree(ROOT, STAGE);
fs.writeFileSync(
  path.join(STAGE, "README-HANDOFF-ZIP.txt"),
  [
    "Minified performance-test zip for GPT-Pro.",
    "Excluded: node_modules, Electron binaries, Bergamot clone/build, WASM, model .bin/.spm, Chrome profile, native-bench.exe.",
    "Included: source, tests, scripts, corpus, results/runs, results/corpora, aggregate, FINAL_BENCHMARK_REPORT.md, chrome-preflight.json, machine.json, HANDOFF.md, harness-fix.md.",
    "Start at results/FINAL_BENCHMARK_REPORT.md and HANDOFF.md.",
    ""
  ].join("\n"),
  "utf8"
);

const zip = spawnSync(
  "powershell.exe",
  [
    "-NoProfile",
    "-Command",
    `Compress-Archive -Path '${STAGE}\\*' -DestinationPath '${ZIP}' -Force`
  ],
  { encoding: "utf8", windowsHide: true }
);
if (zip.status !== 0) {
  console.error(zip.stdout);
  console.error(zip.stderr);
  throw new Error("zip failed");
}

const stat = fs.statSync(ZIP);
console.log(`Wrote ${ZIP} (${(stat.size / 1024).toFixed(1)} KB)`);
console.log(`Staging folder ${STAGE}`);
