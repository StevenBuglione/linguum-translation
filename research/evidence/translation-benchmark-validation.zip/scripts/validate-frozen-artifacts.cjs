"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { execFileSync } = require("node:child_process");
const { repoRoot, sha256File } = require("./lib/bench-util.cjs");

const ROOT = repoRoot();
const FROZEN = {
  wasmVersion: "4.0",
  wasmSha256: "f38ef807636a7c994afedaab7ff8ffe0d590d21897f05139f747b80fd7bbe926",
  modelVersion: "2.0",
  modelName: "model.esen.intgemm.alphas.bin",
  modelSha256: "4aed7734152ae0045d1a69ae49c86cfda18f53c61f90e95e1d1de1c7c7c3b033",
  vocabName: "vocab.esen.spm",
  lexName: "lex.50.50.esen.s2t.bin",
  bergamotCommit: "9271618ebbdc5d21ac4dc4df9e72beb7ce644774",
  marianCommitPrefix: "2781d735"
};

function gitRev(dir) {
  return execFileSync("git", ["-C", dir, "rev-parse", "HEAD"], {
    encoding: "utf8"
  }).trim();
}

function main() {
  const errors = [];
  const manifestPath = path.join(ROOT, "artifacts", "mozilla", "manifest.json");
  if (!fs.existsSync(manifestPath)) {
    throw new Error("missing artifacts/mozilla/manifest.json — do not refetch; restore the frozen artifacts");
  }
  const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
  const wasmPath = path.join(ROOT, "artifacts", "mozilla", "engine", "bergamot-translator.wasm");
  const modelDir = path.join(ROOT, "artifacts", "mozilla", "models", "es-en");
  const files = {
    wasm: wasmPath,
    model: path.join(modelDir, FROZEN.modelName),
    vocab: path.join(modelDir, FROZEN.vocabName),
    lex: path.join(modelDir, FROZEN.lexName)
  };
  for (const [name, filePath] of Object.entries(files)) {
    if (!fs.existsSync(filePath)) {
      errors.push(`missing ${name}: ${filePath}`);
    }
  }
  if (errors.length) {
    throw new Error(errors.join("\n"));
  }

  const hashes = {
    wasm: sha256File(files.wasm),
    model: sha256File(files.model),
    vocab: sha256File(files.vocab),
    lex: sha256File(files.lex)
  };

  if (hashes.wasm !== FROZEN.wasmSha256) {
    errors.push(`WASM hash mismatch: ${hashes.wasm} != ${FROZEN.wasmSha256}`);
  }
  if (hashes.model !== FROZEN.modelSha256) {
    errors.push(`model hash mismatch: ${hashes.model} != ${FROZEN.modelSha256}`);
  }

  const pair = manifest.pairs?.["es-en"];
  if (!pair) {
    errors.push("manifest missing es-en pair");
  } else {
    if (pair.modelVersion !== FROZEN.modelVersion) {
      errors.push(`manifest model version ${pair.modelVersion} != ${FROZEN.modelVersion}`);
    }
    if (pair.files?.model?.sha256 !== FROZEN.modelSha256) {
      errors.push("manifest model sha256 does not match frozen hash");
    }
    if (pair.files?.model?.sha256 !== hashes.model) {
      errors.push("on-disk model hash does not match manifest");
    }
    if (pair.files?.vocab?.sha256 !== hashes.vocab) {
      errors.push("on-disk vocab hash does not match manifest");
    }
    if (pair.files?.lex?.sha256 !== hashes.lex) {
      errors.push("on-disk lex hash does not match manifest");
    }
    if (pair.files?.vocab?.name !== FROZEN.vocabName) {
      errors.push(`vocab name ${pair.files?.vocab?.name} != ${FROZEN.vocabName}`);
    }
    if (pair.files?.lex?.name !== FROZEN.lexName) {
      errors.push(`lex name ${pair.files?.lex?.name} != ${FROZEN.lexName}`);
    }
  }

  if (manifest.engine?.version !== FROZEN.wasmVersion) {
    errors.push(`WASM version ${manifest.engine?.version} != ${FROZEN.wasmVersion}`);
  }
  if (manifest.engine?.sha256 !== FROZEN.wasmSha256) {
    errors.push("manifest WASM sha256 does not match frozen hash");
  }

  const bergamotDir = path.join(ROOT, "native", "bergamot-translator");
  const marianDir = path.join(bergamotDir, "3rd_party", "marian-dev");
  const bergamotCommit = gitRev(bergamotDir);
  const marianCommit = gitRev(marianDir);
  if (bergamotCommit !== FROZEN.bergamotCommit) {
    errors.push(`bergamot commit ${bergamotCommit} != ${FROZEN.bergamotCommit}`);
  }
  if (!marianCommit.startsWith(FROZEN.marianCommitPrefix)) {
    errors.push(`marian commit ${marianCommit} does not start with ${FROZEN.marianCommitPrefix}`);
  }

  const nativeExe = [
    path.join(bergamotDir, "build-native", "app", "Release", "native-bench.exe"),
    path.join(bergamotDir, "build-native", "app", "native-bench.exe"),
    path.join(bergamotDir, "build-native", "native-bench.exe")
  ].find((candidate) => fs.existsSync(candidate));

  if (errors.length) {
    throw new Error(`Frozen artifact validation failed:\n${errors.join("\n")}`);
  }

  const report = {
    ok: true,
    wasmVersion: FROZEN.wasmVersion,
    hashes,
    bergamotCommit,
    marianCommit,
    nativeExe: nativeExe || null
  };
  console.log(JSON.stringify(report, null, 2));
}

main();
