"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { repoRoot, writeJson } = require("../src/ecs/diagnostics.cjs");

const ROOT = repoRoot();
const cachePath = path.join(
  ROOT,
  "native",
  "mozilla-translations-firefox",
  "inference",
  "build-harness",
  "CMakeCache.txt"
);
const cache = fs.readFileSync(cachePath, "utf8");
function cacheValue(key) {
  const match = cache.match(new RegExp(`^${key}:\\w+=(.*)$`, "m"));
  return match ? match[1].trim() : null;
}

const exe = path.join(
  ROOT,
  "native",
  "mozilla-translations-firefox",
  "inference",
  "build-harness",
  "src",
  "app",
  "Release",
  "harness-native-bench.exe"
);
if (!fs.existsSync(exe)) {
  throw new Error("harness-native-bench.exe missing");
}

const useFbgemm = cacheValue("USE_FBGEMM") === "ON";
const useStatic = cacheValue("USE_STATIC_LIBS") === "ON";
const compileCpu = cacheValue("COMPILE_CPU") === "ON";
const compileCuda = cacheValue("COMPILE_CUDA") === "ON";
const compileWasm = cacheValue("COMPILE_WASM") === "ON";
const buildArch = cacheValue("BUILD_ARCH");
if (!useFbgemm || !useStatic || !compileCpu || compileCuda || compileWasm || buildArch !== "native") {
  throw new Error("Firefox-current native CMake flags failed verification");
}

const payload = {
  repository: "mozilla/translations",
  revision: "eea6e5a80aa4ddd86d9cc35ce9a65b79aa3ab96d",
  bergamotVersion: "v0.6.0",
  buildType: "Release",
  compiler: "MSVC",
  architecture: "x64",
  buildArch,
  expectedIsa: "AVX2",
  service: "AsyncService",
  workers: 1,
  cacheSize: 0,
  useFbgemm,
  useStaticLibs: useStatic,
  compileCpu,
  compileCuda,
  compileWasm,
  useMkl: cacheValue("USE_MKL"),
  useIntgemm: cacheValue("USE_INTGEMM"),
  useOnnxSgemm: cacheValue("USE_ONNX_SGEMM"),
  modelSha256: "4aed7734152ae0045d1a69ae49c86cfda18f53c61f90e95e1d1de1c7c7c3b033",
  executable: path.relative(ROOT, exe).replaceAll("\\", "/")
};
writeJson(path.join(ROOT, "results", "current-mozilla-native-build.json"), payload);
console.log(JSON.stringify(payload, null, 2));
