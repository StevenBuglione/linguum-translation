"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { spawn, execFileSync } = require("node:child_process");

const ROOT = path.join(__dirname, "..");
const PROFILE = path.join(ROOT, "tmp", "chrome-benchmark-profile");

function chromePath() {
  const candidates = [
    process.env.CHROME_PATH,
    path.join(process.env.LOCALAPPDATA || "", "Google/Chrome/Application/chrome.exe"),
    "C:/Program Files/Google/Chrome/Application/chrome.exe",
    "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe"
  ].filter(Boolean);
  const found = candidates.find((candidate) => fs.existsSync(candidate));
  if (!found) {
    throw new Error("Google Chrome not found. Set CHROME_PATH.");
  }
  return found;
}

function chromeVersion() {
  try {
    const dir = path.dirname(chromePath());
    const versions = fs
      .readdirSync(dir, { withFileTypes: true })
      .filter((entry) => entry.isDirectory() && /^\d+\./.test(entry.name))
      .map((entry) => entry.name)
      .sort();
    if (versions.length) {
      return `Google Chrome ${versions.at(-1)}`;
    }
  } catch {
    // fall through
  }
  return "Google Chrome";
}

function launchChrome(url) {
  fs.mkdirSync(PROFILE, { recursive: true });
  const args = [
    `--user-data-dir=${PROFILE}`,
    "--new-window",
    "--no-first-run",
    "--no-default-browser-check",
    url
  ];
  return spawn(chromePath(), args, {
    stdio: "ignore",
    windowsHide: false
  });
}

function powershell(command) {
  return execFileSync(
    "powershell.exe",
    ["-NoProfile", "-Command", command],
    { encoding: "utf8", windowsHide: true }
  );
}

function benchmarkPids(kind) {
  const filters = {
    chrome: `$_.Name -match 'chrome\\.exe$' -and $_.CommandLine -like '*chrome-benchmark-profile*'`,
    electron: `$_.Name -match 'electron\\.exe$' -and $_.CommandLine -like '*mozilla-bench*'`,
    native: `$_.Name -match 'native-bench\\.exe$'`
  };
  const filter = filters[kind];
  if (!filter) {
    throw new Error(`unknown process kind ${kind}`);
  }
  const stdout = powershell(
    `Get-CimInstance Win32_Process | Where-Object { ${filter} } | Select-Object -ExpandProperty ProcessId`
  );
  return stdout
    .split(/\s+/)
    .map((value) => Number(value))
    .filter((value) => Number.isInteger(value) && value > 0);
}

function killPids(pids) {
  for (const pid of pids) {
    try {
      execFileSync("taskkill", ["/PID", String(pid), "/T", "/F"], { stdio: "ignore" });
    } catch {
      // already gone
    }
  }
}

function killChromeBenchmark() {
  killPids(benchmarkPids("chrome"));
}

function listBenchmarkProcesses() {
  return {
    chrome: benchmarkPids("chrome"),
    electron: benchmarkPids("electron"),
    native: benchmarkPids("native")
  };
}

async function waitUntilGone(kind, timeoutMs = 15000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    if (benchmarkPids(kind).length === 0) {
      return;
    }
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  throw new Error(`${kind} benchmark process still running`);
}

module.exports = {
  ROOT,
  PROFILE,
  chromePath,
  chromeVersion,
  launchChrome,
  killChromeBenchmark,
  listBenchmarkProcesses,
  waitUntilGone,
  benchmarkPids
};
