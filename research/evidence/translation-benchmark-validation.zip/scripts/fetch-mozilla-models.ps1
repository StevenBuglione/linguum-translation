$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
node scripts/generate-corpus.cjs
node scripts/fetch-mozilla-models.cjs
