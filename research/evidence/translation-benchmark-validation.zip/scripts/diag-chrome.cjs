"use strict";

const fs = require("node:fs");
const { execFileSync } = require("node:child_process");
const { listBenchmarkProcesses } = require("./chrome-launch.cjs");

console.log("round-01-chrome.json", fs.existsSync("results/runs/round-01-chrome.json"));
console.log("preflight", fs.existsSync("results/chrome-preflight.json"));
console.log("benchmark pids", listBenchmarkProcesses());

const script = `
Get-CimInstance Win32_Process |
  Where-Object { $_.Name -eq 'chrome.exe' } |
  ForEach-Object {
    $cmd = $_.CommandLine
    if ($cmd -and ($cmd -like '*chrome-benchmark-profile*' -or $cmd -like '*8766*')) {
      '{0}|{1}' -f $_.ProcessId, $cmd
    }
  }
`;
const out = execFileSync("powershell.exe", ["-NoProfile", "-Command", script], {
  encoding: "utf8",
  windowsHide: true
});
console.log(out || "(no matching chrome command lines)");
