import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { assertMeasuredRun } from "../src/translation/common/validate-result.js";
import { ENGINE_IDS } from "../src/translation/common/rounds.js";

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");

function argValue(name) {
  const index = process.argv.indexOf(`--${name}`);
  if (index >= 0) {
    return process.argv[index + 1];
  }
  const prefixed = process.argv.find((arg) => arg.startsWith(`--${name}=`));
  if (prefixed) {
    return prefixed.slice(name.length + 3);
  }
  return null;
}

function main() {
  const file = path.resolve(ROOT, argValue("file"));
  const engineKey = argValue("engine");
  const run = Number(argValue("run"));
  const corpusPath = path.resolve(ROOT, argValue("corpus"));
  const payload = JSON.parse(fs.readFileSync(file, "utf8"));
  const corpus = JSON.parse(fs.readFileSync(corpusPath, "utf8"));
  assertMeasuredRun(payload, {
    engine: ENGINE_IDS[engineKey],
    run,
    round: corpus.round,
    seed: corpus.seed,
    corpusSha256: corpus.roundCorpusSha256,
    sequentialCount: 500,
    items: corpus.items
  });
  console.log(`validated ${file}`);
}

main();
