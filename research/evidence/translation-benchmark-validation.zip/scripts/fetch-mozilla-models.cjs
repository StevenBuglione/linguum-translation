"use strict";

const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { decompress } = require("fzstd");

const ROOT = path.join(__dirname, "..");
const ENGINE_DIR = path.join(ROOT, "artifacts", "mozilla", "engine");
const MODELS_DIR = path.join(ROOT, "artifacts", "mozilla", "models");
const MANIFEST_PATH = path.join(ROOT, "artifacts", "mozilla", "manifest.json");

const REMOTE_SETTINGS_MODELS =
  "https://firefox.settings.services.mozilla.com/v1/buckets/main/collections/translations-models/records";
const REMOTE_SETTINGS_WASM =
  "https://firefox.settings.services.mozilla.com/v1/buckets/main/collections/translations-wasm/records";
const ATTACHMENT_ROOT = "https://firefox-settings-attachments.cdn.mozilla.net/";
const FIREFOX_JS_URL =
  "https://raw.githubusercontent.com/mozilla-firefox/firefox/main/toolkit/components/translations/bergamot-translator/bergamot-translator.js";
const FIREFOX_CI_WASM_ZST =
  "https://storage.googleapis.com/moz-fx-translations-data--303e-prod-translations-data/firefox-ci/wasm/bergamot-translator.wasm.zst";
const FIREFOX_CI_WASM_SHA256 =
  "327fcfc7b7e9d95f6fa0844ebf899cfc05469872ef02d3aef5783182839a6255";

const PAIRS = [
  ["es", "en"],
  ["en", "es"]
];

function sha256(buffer) {
  return crypto.createHash("sha256").update(buffer).digest("hex");
}

async function fetchBuffer(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`GET ${url} failed: ${response.status} ${response.statusText}`);
  }
  return Buffer.from(await response.arrayBuffer());
}

async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`GET ${url} failed: ${response.status} ${response.statusText}`);
  }
  return response.json();
}

function attachmentUrl(location) {
  return `${ATTACHMENT_ROOT}${location}`;
}

function selectLatestPair(records, fromLang, toLang) {
  const matches = records.filter(
    (record) => record.fromLang === fromLang && record.toLang === toLang
  );
  if (!matches.length) {
    throw new Error(`No Remote Settings records for ${fromLang}-${toLang}`);
  }
  matches.sort((a, b) => {
    const version = String(b.version).localeCompare(String(a.version), undefined, {
      numeric: true
    });
    if (version !== 0) {
      return version;
    }
    return (b.last_modified || 0) - (a.last_modified || 0);
  });
  const latestVersion = matches[0].version;
  return matches.filter((record) => record.version === latestVersion);
}

function selectBergamotWasm(records) {
  const wasmRecords = records.filter((record) => record.name === "bergamot-translator");
  wasmRecords.sort((a, b) =>
    String(b.version).localeCompare(String(a.version), undefined, { numeric: true })
  );
  return wasmRecords[0] || null;
}

function writeFile(filePath, buffer) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, buffer);
}

async function downloadVerified(url, expectedSha, label) {
  const started = Date.now();
  const buffer = await fetchBuffer(url);
  const actual = sha256(buffer);
  if (expectedSha && actual !== expectedSha.toLowerCase()) {
    throw new Error(`${label} hash mismatch: expected ${expectedSha}, got ${actual}`);
  }
  return {
    buffer,
    sha256: actual,
    bytes: buffer.byteLength,
    downloadMs: Date.now() - started,
    url
  };
}

async function main() {
  fs.mkdirSync(ENGINE_DIR, { recursive: true });
  fs.mkdirSync(MODELS_DIR, { recursive: true });

  const downloadLog = [];
  const modelsJson = await fetchJson(REMOTE_SETTINGS_MODELS);
  const wasmJson = await fetchJson(REMOTE_SETTINGS_WASM);
  const releasedWasm = selectBergamotWasm(wasmJson.data || []);

  console.log("Downloading current Firefox bergamot-translator.js…");
  const js = await downloadVerified(FIREFOX_JS_URL, null, "bergamot-translator.js");
  writeFile(path.join(ENGINE_DIR, "bergamot-translator.js"), js.buffer);
  downloadLog.push({
    kind: "engine-js",
    source: "Firefox in-tree bergamot-translator.js",
    ...js,
    buffer: undefined
  });

  console.log("Downloading Firefox CI Bergamot WASM v4 (matches current JS glue)…");
  const wasmZst = await downloadVerified(
    FIREFOX_CI_WASM_ZST,
    FIREFOX_CI_WASM_SHA256,
    "bergamot-translator.wasm.zst"
  );
  const wasm = Buffer.from(decompress(wasmZst.buffer));
  const wasmSha = sha256(wasm);
  writeFile(path.join(ENGINE_DIR, "bergamot-translator.wasm"), wasm);
  writeFile(path.join(ENGINE_DIR, "bergamot-translator.wasm.zst"), wasmZst.buffer);
  downloadLog.push({
    kind: "engine-wasm",
    source: "Firefox CI translations-fetch.yml tr8ns.inference (version 4.0)",
    url: FIREFOX_CI_WASM_ZST,
    sha256: wasmSha,
    compressedSha256: wasmZst.sha256,
    bytes: wasm.byteLength,
    compressedBytes: wasmZst.bytes,
    downloadMs: wasmZst.downloadMs
  });

  if (releasedWasm) {
    downloadLog.push({
      kind: "engine-wasm-remote-settings",
      note: "Production Remote Settings WASM (not used for inference if JS requires v4)",
      version: releasedWasm.version,
      release: releasedWasm.release,
      revision: releasedWasm.revision,
      sha256: releasedWasm.hash,
      url: attachmentUrl(releasedWasm.attachment.location)
    });
  }

  const pairs = {};
  for (const [fromLang, toLang] of PAIRS) {
    const id = `${fromLang}-${toLang}`;
    console.log(`Downloading released Firefox model ${id}…`);
    const records = selectLatestPair(modelsJson.data || [], fromLang, toLang);
    const files = {};
    const pairDir = path.join(MODELS_DIR, id);
    fs.mkdirSync(pairDir, { recursive: true });
    for (const record of records) {
      const file = await downloadVerified(
        attachmentUrl(record.attachment.location),
        (record.hash || record.attachment.hash).toLowerCase(),
        `${id} ${record.fileType}`
      );
      const filename = record.attachment.filename || record.name;
      const relativePath = path
        .join("artifacts", "mozilla", "models", id, filename)
        .replaceAll("\\", "/");
      writeFile(path.join(pairDir, filename), file.buffer);
      files[record.fileType] = {
        name: record.name,
        fileType: record.fileType,
        version: record.version,
        sha256: file.sha256,
        bytes: file.bytes,
        downloadMs: file.downloadMs,
        url: file.url,
        filename,
        relativePath
      };
      console.log(`  ${record.fileType}: ${filename} (${file.bytes} bytes)`);
    }
    pairs[id] = {
      languagePair: id,
      modelVersion: records[0].version,
      source: "Mozilla released Firefox model (Remote Settings main/translations-models)",
      downloadedAt: new Date().toISOString(),
      files
    };
  }

  const manifest = {
    downloadedAt: new Date().toISOString(),
    engine: {
      jsRelativePath: "artifacts/mozilla/engine/bergamot-translator.js",
      wasmRelativePath: "artifacts/mozilla/engine/bergamot-translator.wasm",
      version: "4.0",
      source: "Firefox CI bergamot-translator.wasm.zst + Firefox in-tree JS glue",
      sha256: wasmSha,
      bytes: wasm.byteLength,
      jsBytes: js.bytes,
      jsSha256: js.sha256
    },
    pairs,
    downloads: downloadLog.map(({ buffer, ...rest }) => rest)
  };

  writeFile(MANIFEST_PATH, Buffer.from(`${JSON.stringify(manifest, null, 2)}\n`, "utf8"));
  console.log(`Wrote ${MANIFEST_PATH}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
