$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
$run = "1"
if ($args.Count -ge 1) { $run = $args[0] }
Write-Host "Mozilla Bergamot bench inside ECS, run $run"
npx electron . --mode=mozilla-bench --run=$run
