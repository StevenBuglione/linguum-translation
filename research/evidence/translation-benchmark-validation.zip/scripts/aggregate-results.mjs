import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { aggregateValidatedSet } from "../src/translation/common/aggregate.js";
import { ROUND_COUNT, padRound, runFileName, roundFileName } from "../src/translation/common/rounds.js";

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const RESULTS = path.join(ROOT, "results");

const payloadsByFile = {};
for (let round = 1; round <= ROUND_COUNT; round += 1) {
  for (const engine of ["chrome", "wasm", "native"]) {
    const name = runFileName(round, engine);
    const file = path.join(RESULTS, "runs", name);
    if (!fs.existsSync(file)) {
      throw new Error(`missing ${file}`);
    }
    payloadsByFile[name] = JSON.parse(fs.readFileSync(file, "utf8"));
  }
}

const corporaByRound = {};
for (let round = 1; round <= ROUND_COUNT; round += 1) {
  const file = path.join(RESULTS, "corpora", roundFileName(round));
  if (!fs.existsSync(file)) {
    throw new Error(`missing ${file}`);
  }
  const corpus = JSON.parse(fs.readFileSync(file, "utf8"));
  corporaByRound[round] = {
    seed: corpus.seed,
    corpusSha256: corpus.roundCorpusSha256,
    items: corpus.items
  };
}

const aggregate = aggregateValidatedSet(payloadsByFile, corporaByRound);
const outDir = path.join(RESULTS, "aggregate");
fs.mkdirSync(outDir, { recursive: true });
const dest = path.join(outDir, "translation-comparison.json");
fs.writeFileSync(
  dest,
  `${JSON.stringify(
    {
      generatedAt: new Date().toISOString(),
      ...aggregate
    },
    null,
    2
  )}\n`,
  "utf8"
);
console.log(`Wrote ${dest}`);
console.log(
  `Native decision=${aggregate.nativeVsChrome.decision} WASM=${aggregate.wasm.decision}`
);
