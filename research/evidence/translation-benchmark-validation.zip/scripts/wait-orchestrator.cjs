"use strict";

const fs = require("node:fs");
const { execFileSync } = require("node:child_process");

function listRuns() {
  if (!fs.existsSync("results/runs")) {
    return [];
  }
  return fs
    .readdirSync("results/runs")
    .filter((name) => name.endsWith(".json") && !name.includes("progress") && !name.includes("error"))
    .sort();
}

function processAlive(pid) {
  try {
    execFileSync("powershell.exe", ["-NoProfile", "-Command", `Get-Process -Id ${pid} | Out-Null`], {
      windowsHide: true
    });
    return true;
  } catch {
    return false;
  }
}

const pid = Number(process.argv[2] || 15916);
const timeoutMs = Number(process.argv[3] || 240000);
const started = Date.now();
console.log("watching pid", pid, "files", listRuns().join(", "));
while (Date.now() - started < timeoutMs) {
  if (!processAlive(pid)) {
    console.log("exited after", Date.now() - started, "ms");
    console.log("files", listRuns().join(", "));
    process.exit(0);
  }
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 5000);
  console.log("still running", Math.round((Date.now() - started) / 1000), "s files=", listRuns().join(", "));
}
console.log("timeout files", listRuns().join(", "));
process.exit(2);
