"use strict";

const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");
const { spawnSync } = require("node:child_process");
const { repoRoot, safeResultsFile, writeJson } = require("../src/ecs/diagnostics.cjs");
const { parseArgs, sha256File, loadMachine } = require("./lib/bench-util.cjs");

const ROOT = repoRoot();
const FIREFOX_REVISION = "eea6e5a80aa4ddd86d9cc35ce9a65b79aa3ab96d";
const BERGAMOT_VERSION = "v0.6.0";
const MODEL_SHA = "4aed7734152ae0045d1a69ae49c86cfda18f53c61f90e95e1d1de1c7c7c3b033";

function findExe() {
  const candidates = [
    path.join(
      ROOT,
      "native",
      "mozilla-translations-firefox",
      "inference",
      "build-harness",
      "src",
      "app",
      "Release",
      "harness-native-bench.exe"
    ),
    path.join(
      ROOT,
      "native",
      "mozilla-translations-firefox",
      "inference",
      "build-harness",
      "Release",
      "harness-native-bench.exe"
    ),
    path.join(
      ROOT,
      "native",
      "mozilla-translations-firefox",
      "inference",
      "build-harness",
      "src",
      "app",
      "harness-native-bench.exe"
    )
  ];
  const found = candidates.find((candidate) => fs.existsSync(candidate));
  if (!found) {
    throw new Error("harness-native-bench.exe not found. Build Firefox-current native first.");
  }
  return found;
}

function writeYml() {
  const modelDir = path.join(ROOT, "artifacts", "mozilla", "models", "es-en");
  const slash = (p) => p.replaceAll("\\", "/");
  const config = `
beam-size: 1
normalize: 1.0
word-penalty: 0
max-length-break: 128
mini-batch-words: 1024
workspace: 128
max-length-factor: 2.0
skip-cost: true
cpu-threads: 0
quiet: true
quiet-translation: true
gemm-precision: int8shiftAlphaAll
alignment: soft
models:
  - ${slash(path.join(modelDir, "model.esen.intgemm.alphas.bin"))}
vocabs:
  - ${slash(path.join(modelDir, "vocab.esen.spm"))}
  - ${slash(path.join(modelDir, "vocab.esen.spm"))}
shortlist:
  - ${slash(path.join(modelDir, "lex.50.50.esen.s2t.bin"))}
  - false
`.trimStart();
  const tmp = path.join(ROOT, "native", "tmp");
  fs.mkdirSync(tmp, { recursive: true });
  const configPath = path.join(tmp, "es-en.yml");
  fs.writeFileSync(configPath, config, "utf8");
  return { configPath, modelDir, tmp };
}

async function main() {
  const args = parseArgs();
  if (!args.run || !args.output || !args.corpus) {
    throw new Error("usage: node scripts/run-native-bench.cjs --run N --corpus path --output path");
  }

  const {
    summarizeRun,
    firstTranslationProbe,
    warmupSentences
  } = await import("../src/translation/common/benchmark.js");
  const { characterCount } = await import("../src/translation/common/statistics.js");
  const { assertMeasuredRun } = await import("../src/translation/common/validate-result.js");

  const run = Number(args.run);
  const round = Number(args.round || args.run);
  const baseCorpus = JSON.parse(
    fs.readFileSync(path.join(ROOT, "src", "translation", "common", "corpus.json"), "utf8")
  );
  const roundCorpus = JSON.parse(fs.readFileSync(path.resolve(ROOT, args.corpus), "utf8"));
  if (roundCorpus.round !== round) {
    throw new Error(`corpus round ${roundCorpus.round} does not match --round ${round}`);
  }
  if (!Array.isArray(roundCorpus.items) || roundCorpus.items.length !== 500) {
    throw new Error("round corpus must contain 500 measured strings");
  }

  const warmup = warmupSentences(baseCorpus);
  const probe = firstTranslationProbe(baseCorpus);
  const frozenPath = path.join(ROOT, "results", "frozen-baseline-sha256.json");
  if (fs.existsSync(frozenPath)) {
    const frozen = JSON.parse(fs.readFileSync(frozenPath, "utf8"));
    const pad = String(round).padStart(2, "0");
    const expectedCorpus = frozen.corpora?.[`round-${pad}`];
    const actualCorpus = sha256File(path.resolve(ROOT, args.corpus));
    if (expectedCorpus && actualCorpus !== expectedCorpus) {
      throw new Error(
        `corpus SHA mismatch for round ${round}: expected ${expectedCorpus}, got ${actualCorpus}`
      );
    }
    const chromeSha = frozen.chrome?.[`round-${pad}`];
    const wasmSha = frozen.wasm?.[`round-${pad}`];
    const chromeFile = path.join(ROOT, "results", "runs", `round-${pad}-chrome.json`);
    const wasmFile = path.join(ROOT, "results", "runs", `round-${pad}-wasm.json`);
    if (chromeSha && sha256File(chromeFile) !== chromeSha) {
      throw new Error(`frozen Chrome round-${pad} hash changed`);
    }
    if (wasmSha && sha256File(wasmFile) !== wasmSha) {
      throw new Error(`frozen WASM round-${pad} hash changed`);
    }
  }

  const { configPath, modelDir, tmp } = writeYml();
  const modelSha = sha256File(path.join(modelDir, "model.esen.intgemm.alphas.bin"));
  if (modelSha !== MODEL_SHA) {
    throw new Error(`es-en model SHA mismatch: ${modelSha}`);
  }
  const measuredPath = path.join(tmp, "measured.txt");
  const warmupPath = path.join(tmp, "warmup.txt");
  const probePath = path.join(tmp, "probe.txt");
  fs.writeFileSync(measuredPath, `${roundCorpus.items.join("\n")}\n`, "utf8");
  fs.writeFileSync(warmupPath, `${warmup.join("\n")}\n`, "utf8");
  fs.writeFileSync(probePath, `${probe}\n`, "utf8");

  const exe = findExe();
  console.log(`Running ${exe}`);
  const spawned = spawnSync(exe, [configPath, measuredPath, warmupPath, probePath], {
    encoding: "utf8",
    maxBuffer: 64 * 1024 * 1024,
    windowsHide: true
  });
  if (spawned.status !== 0) {
    console.error(spawned.stdout);
    console.error(spawned.stderr);
    throw new Error(`native-bench exited ${spawned.status}`);
  }

  const parsed = JSON.parse(spawned.stdout);
  if (parsed.service !== "AsyncService") {
    throw new Error(`native-bench must use AsyncService, got ${parsed.service}`);
  }
  if (parsed.workers !== 1 || parsed.cacheSize !== 0) {
    throw new Error("native-bench must use workers=1 cacheSize=0");
  }
  if (parsed.warmup !== 20) {
    throw new Error(`native-bench warmup count ${parsed.warmup} != 20`);
  }

  const machine = loadMachine();
  const records = parsed.samples.map((sample, id) => {
    const source = sample.source;
    return {
      engine: "mozilla-bergamot-native",
      pair: "es-en",
      id,
      source,
      translation: sample.translation,
      characters: characterCount(source),
      words: source.trim().split(/\s+/).filter(Boolean).length,
      bucket: (() => {
        const words = source.trim().split(/\s+/).filter(Boolean).length;
        if (words <= 4) return "tiny";
        if (words <= 10) return "short";
        if (words <= 20) return "medium";
        if (words <= 35) return "long";
        return "out-of-range";
      })(),
      queueMs: 0,
      inferenceMs: sample.totalMs,
      totalMs: sample.totalMs
    };
  });

  const sequential = summarizeRun({
    engine: "mozilla-bergamot-native",
    version: `mozilla/translations@${FIREFOX_REVISION} bergamot ${BERGAMOT_VERSION}`,
    languagePair: "es-en",
    run,
    round,
    seed: roundCorpus.seed,
    corpusSha256: roundCorpus.roundCorpusSha256,
    mode: "sequential",
    environment: {
      cpu: machine.cpu || os.cpus()[0]?.model,
      ramGb: machine.ramGb || Number((os.totalmem() / 1024 ** 3).toFixed(2)),
      gpu: machine.gpu || "unused",
      windows: machine.windows || os.version(),
      playbackActive: false,
      service: "AsyncService"
    },
    model: {
      name: "model.esen.intgemm.alphas.bin",
      version: "2.0",
      bytes: fs.statSync(path.join(modelDir, "model.esen.intgemm.alphas.bin")).size,
      sha256: sha256File(path.join(modelDir, "model.esen.intgemm.alphas.bin"))
    },
    engineSetupMs: parsed.engineSetupMs,
    firstTranslationMs: parsed.firstTranslationMs,
    wallClockMs: parsed.wallClockMs,
    records
  });

  sequential.service = "AsyncService";
  sequential.workers = 1;
  sequential.cacheSize = 0;
  sequential.build = "Release";
  sequential.architecture = "x64";
  sequential.cpuIsa = "AVX2";
  sequential.implementation = "firefox-current-native";
  sequential.sourceRepository = "mozilla/translations";
  sequential.sourceRevision = FIREFOX_REVISION;
  sequential.bergamotVersion = BERGAMOT_VERSION;
  sequential.mathBackend = "FBGEMM";

  const payload = {
    engine: "mozilla-bergamot-native",
    implementation: "firefox-current-native",
    sourceRepository: "mozilla/translations",
    sourceRevision: FIREFOX_REVISION,
    bergamotVersion: BERGAMOT_VERSION,
    version: sequential.version,
    run,
    round,
    seed: roundCorpus.seed,
    corpusSha256: roundCorpus.roundCorpusSha256,
    service: "AsyncService",
    workers: 1,
    cacheSize: 0,
    mathBackend: "FBGEMM",
    build: "Release",
    architecture: "x64",
    cpuIsa: "AVX2",
    engineSetupMs: parsed.engineSetupMs,
    firstTranslationMs: parsed.firstTranslationMs,
    wallClockMs: parsed.wallClockMs,
    results: [sequential]
  };

  assertMeasuredRun(payload, {
    engine: "mozilla-bergamot-native",
    run,
    round,
    seed: roundCorpus.seed,
    corpusSha256: roundCorpus.roundCorpusSha256,
    sequentialCount: 500,
    items: roundCorpus.items
  });

  const outFile = safeResultsFile(String(args.output).replace(/^results[/\\]/, ""));
  fs.rmSync(outFile, { force: true });
  writeJson(outFile, payload);
  console.log(
    `native sequential n=${sequential.translations} p50=${sequential.p50Ms.toFixed(2)} p95=${sequential.p95Ms.toFixed(2)} p99=${sequential.p99Ms.toFixed(2)} tps=${sequential.translationsPerSecond.toFixed(2)}`
  );
  console.log(`Wrote ${outFile}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
