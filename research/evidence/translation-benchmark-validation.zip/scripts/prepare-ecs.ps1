$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

Write-Host "Installing pinned CastLabs ECS 43.2.0+wvcus and Node dependencies..."
npm install

Write-Host "Collecting machine inventory..."
node scripts/collect-machine.cjs

Write-Host "ECS prepare complete. Next: scripts/fetch-mozilla-models.ps1"
