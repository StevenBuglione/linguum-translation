"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { createStaticServer } = require("../src/ecs/static-server.cjs");
const { repoRoot, writeJson } = require("../src/ecs/diagnostics.cjs");
const {
  killBenchmarkChrome,
  launchChrome,
  waitForJsonFile,
  closeHttpServer
} = require("./lib/bench-util.cjs");

async function main() {
  killBenchmarkChrome();
  const root = repoRoot();
  const outFile = path.join(root, "results", "chrome-preflight.json");
  const errorFile = path.join(root, "results", "chrome-preflight.error.json");
  fs.rmSync(outFile, { force: true });
  fs.rmSync(errorFile, { force: true });

  const { server, origin } = await createStaticServer({ port: 8766 });
  const url = `${origin}/src/translation/chrome/index.html?preflight=1&autorun=1`;
  console.log(`Chrome preflight: ${url}`);
  const { child } = launchChrome(url);

  try {
    const payload = await waitForJsonFile(outFile, 10 * 60 * 1000, { errorFile });
    if (!payload.ok) {
      throw new Error("Chrome preflight did not report ok=true");
    }
    if (payload.availabilityAfter !== "available") {
      throw new Error(
        `Chrome language pack not locally available after preflight (availabilityAfter=${payload.availabilityAfter})`
      );
    }
    writeJson(outFile, payload);
    console.log(`Saved ${outFile}`);
    console.log(
      `availability ${payload.availabilityBefore} -> ${payload.availabilityAfter}; translation=${payload.translation}`
    );
  } finally {
    killBenchmarkChrome();
    if (child.pid) {
      try {
        process.kill(child.pid);
      } catch {
        // already gone
      }
    }
    await closeHttpServer(server);
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
