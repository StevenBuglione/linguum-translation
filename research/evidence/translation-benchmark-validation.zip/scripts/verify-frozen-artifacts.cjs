"use strict";

const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { execFileSync } = require("node:child_process");

const ROOT = path.join(__dirname, "..");
const EXPECTED = {
  wasm: {
    path: path.join(ROOT, "artifacts", "mozilla", "engine", "bergamot-translator.wasm"),
    sha256: "f38ef807636a7c994afedaab7ff8ffe0d590d21897f05139f747b80fd7bbe926"
  },
  model: {
    path: path.join(ROOT, "artifacts", "mozilla", "models", "es-en", "model.esen.intgemm.alphas.bin"),
    sha256: "4aed7734152ae0045d1a69ae49c86cfda18f53c61f90e95e1d1de1c7c7c3b033"
  },
  vocab: {
    path: path.join(ROOT, "artifacts", "mozilla", "models", "es-en", "vocab.esen.spm"),
    sha256: "5ae254fa9b15aa182e70fd2a6186b1333c63a29a48043a9224c6aa4fcac058ad"
  },
  lex: {
    path: path.join(ROOT, "artifacts", "mozilla", "models", "es-en", "lex.50.50.esen.s2t.bin"),
    sha256: "e2610211d3b9577d012638fe7e7e74ed7b4b708ce96b9e792e67c282a6492daa"
  },
  nativeCommit: "9271618ebbdc5d21ac4dc4df9e72beb7ce644774"
};

function sha256File(filePath) {
  const hash = crypto.createHash("sha256");
  hash.update(fs.readFileSync(filePath));
  return hash.digest("hex");
}

function main() {
  const manifest = JSON.parse(
    fs.readFileSync(path.join(ROOT, "artifacts", "mozilla", "manifest.json"), "utf8")
  );
  const mismatches = [];

  for (const [name, expected] of Object.entries(EXPECTED)) {
    if (name === "nativeCommit") {
      continue;
    }
    if (!fs.existsSync(expected.path)) {
      mismatches.push(`${name}: missing ${expected.path}`);
      continue;
    }
    const actual = sha256File(expected.path);
    if (actual !== expected.sha256) {
      mismatches.push(`${name}: expected ${expected.sha256}, got ${actual}`);
    } else {
      console.log(`${name}: ${actual} OK`);
    }
  }

  if (manifest.engine.sha256 !== EXPECTED.wasm.sha256) {
    mismatches.push(`manifest wasm sha mismatch: ${manifest.engine.sha256}`);
  }
  if (manifest.pairs["es-en"].files.model.sha256 !== EXPECTED.model.sha256) {
    mismatches.push("manifest es-en model sha mismatch");
  }
  if (manifest.engine.version !== "4.0") {
    mismatches.push(`WASM version ${manifest.engine.version}, expected 4.0`);
  }
  if (manifest.pairs["es-en"].modelVersion !== "2.0") {
    mismatches.push(`es-en model version ${manifest.pairs["es-en"].modelVersion}, expected 2.0`);
  }

  const nativeRepo = path.join(ROOT, "native", "bergamot-translator");
  const head = execFileSync("git", ["-C", nativeRepo, "rev-parse", "HEAD"], {
    encoding: "utf8"
  }).trim();
  if (head !== EXPECTED.nativeCommit) {
    mismatches.push(`native HEAD ${head}, expected ${EXPECTED.nativeCommit}`);
  } else {
    console.log(`native commit: ${head} OK`);
  }

  if (mismatches.length) {
    throw new Error(`Frozen artifact check failed:\n${mismatches.join("\n")}`);
  }
  console.log("Frozen Mozilla artifacts and native revision match the existing result.");
}

main();
