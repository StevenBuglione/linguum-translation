"use strict";

const { execFileSync } = require("node:child_process");

const stdout = execFileSync(
  "powershell.exe",
  [
    "-NoProfile",
    "-Command",
    "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'run-translation-rounds|mozilla-bench|run-chrome-bench|native-bench|prepare-chrome' } | Select-Object ProcessId, Name, CommandLine | ConvertTo-Json"
  ],
  { encoding: "utf8", windowsHide: true }
);
console.log(stdout || "none");
