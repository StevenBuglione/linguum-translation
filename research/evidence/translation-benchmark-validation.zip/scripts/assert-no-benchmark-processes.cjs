"use strict";

const { assertNoBenchmarkProcesses, parseArgs } = require("./lib/bench-util.cjs");

const args = parseArgs();
assertNoBenchmarkProcesses({ killStale: Boolean(args["kill-stale"] || args.kill) });
console.log("No leftover benchmark processes.");
