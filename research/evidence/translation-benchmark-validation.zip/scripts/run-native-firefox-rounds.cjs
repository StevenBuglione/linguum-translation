"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { spawnSync } = require("node:child_process");
const { repoRoot } = require("../src/ecs/diagnostics.cjs");
const { sha256File } = require("./lib/bench-util.cjs");

const ROOT = repoRoot();
const FROZEN = JSON.parse(
  fs.readFileSync(path.join(ROOT, "results", "frozen-baseline-sha256.json"), "utf8")
);

function run(cmd, args) {
  console.log(`>> ${cmd} ${args.join(" ")}`);
  const result = spawnSync(cmd, args, { stdio: "inherit", cwd: ROOT, windowsHide: true });
  if (result.status !== 0) {
    throw new Error(`${cmd} exited ${result.status}`);
  }
}

function assertFrozen() {
  for (let round = 1; round <= 6; round += 1) {
    const pad = String(round).padStart(2, "0");
    const corpus = sha256File(path.join(ROOT, "results", "corpora", `round-${pad}.json`));
    const chrome = sha256File(path.join(ROOT, "results", "runs", `round-${pad}-chrome.json`));
    const wasm = sha256File(path.join(ROOT, "results", "runs", `round-${pad}-wasm.json`));
    if (corpus !== FROZEN.corpora[`round-${pad}`]) {
      throw new Error(`corpus round-${pad} hash changed`);
    }
    if (chrome !== FROZEN.chrome[`round-${pad}`]) {
      throw new Error(`chrome round-${pad} hash changed`);
    }
    if (wasm !== FROZEN.wasm[`round-${pad}`]) {
      throw new Error(`wasm round-${pad} hash changed`);
    }
  }
}

assertFrozen();
for (let round = 1; round <= 6; round += 1) {
  const pad = String(round).padStart(2, "0");
  const corpus = `results/corpora/round-${pad}.json`;
  const output = `runs/round-${pad}-native.json`;
  run("node", [
    "scripts/run-native-bench.cjs",
    "--run",
    String(round),
    "--round",
    String(round),
    "--corpus",
    corpus,
    "--output",
    output
  ]);
  if (round < 6) {
    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 10000);
  }
}
assertFrozen();
console.log("Six Firefox-current native rounds complete. Frozen Chrome/WASM/corpora unchanged.");
