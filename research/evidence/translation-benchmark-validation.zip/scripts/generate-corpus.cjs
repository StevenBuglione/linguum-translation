"use strict";

const fs = require("node:fs");
const path = require("node:path");

function countWords(text) {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

const tiny = [
  "Sí.",
  "No.",
  "Vamos.",
  "¿Qué?",
  "¿Quién?",
  "¿Cuándo?",
  "¿Dónde?",
  "Espera.",
  "Corre.",
  "Cuidado.",
  "Basta.",
  "Mira.",
  "Escucha.",
  "Tranquilo.",
  "Despacio.",
  "Ahora.",
  "Luego.",
  "Nunca.",
  "Siempre.",
  "Quizá.",
  "Claro.",
  "Exacto.",
  "Imposible.",
  "Perfecto.",
  "Horrible.",
  "Genial.",
  "¿En serio?",
  "¿De verdad?",
  "No entiendo.",
  "No lo sé.",
  "Ven conmigo.",
  "¿Qué pasó?",
  "¿Estás bien?",
  "Estoy bien.",
  "Tengo miedo.",
  "Tengo hambre.",
  "Hace frío.",
  "Hace calor.",
  "Es tarde.",
  "Es pronto.",
  "Perdóname.",
  "Lo siento.",
  "Gracias, María.",
  "Hasta mañana.",
  "Nos vemos.",
  "Estoy listo.",
  "No puedo.",
  "Sí puedo.",
  "Dilo otra vez.",
  "Más despacio.",
  "Más rápido.",
  "A la izquierda.",
  "A la derecha.",
  "Hacia atrás.",
  "Sigue adelante.",
  "Cierra la puerta.",
  "Abre la ventana.",
  "Apaga la luz.",
  "Enciende eso.",
  "No grites.",
  "No llores.",
  "No mires.",
  "Confía en mí.",
  "Te quiero.",
  "Te odio.",
  "Eres increíble.",
  "Eres imposible.",
  "Qué locura.",
  "Qué desastre.",
  "Qué alivio.",
  "Son las ocho.",
  "Son las doce.",
  "Cinco minutos.",
  "Dos horas.",
  "Tres días.",
  "El lunes.",
  "El viernes.",
  "En marzo.",
  "En 1998.",
  "En 2024.",
  "Número siete.",
  "Número veintitrés.",
  "Calle Mayor.",
  "Hotel Central.",
  "Aeropuerto Norte.",
  "Estación Sur.",
  "Doctor Herrera.",
  "Capitán Ruiz.",
  "Señora López.",
  "Buenos días.",
  "Buenas noches.",
  "¿Qué haces?",
  "¿Qué quieres?",
  "¿Me oyes?",
  "¿Me ves?",
  "Estoy aquí.",
  "No hay nadie.",
  "Hay alguien.",
  "Ya viene.",
  "Bueno... espera."
];

const shortSeeds = [
  "No puedo creer que hayas hecho eso.",
  "Tenemos que salir de aquí ahora mismo.",
  "¿Quieres venir conmigo esta noche?",
  "¿Qué demonios estás haciendo ahora?",
  "Bueno... no estoy seguro de nada.",
  "Son las ocho y media, date prisa.",
  "María, espera un segundo, por favor.",
  "No, no, no. Escúchame con atención.",
  "¿En serio quieres hacer esto ahora?",
  "El tren sale a las cinco en punto.",
  "No me mires con esa cara otra vez.",
  "Creo que es una mala idea, Daniel.",
  "Hace un frío terrible esta noche.",
  "¿Puedes repetir eso más despacio?",
  "Hay tres policías frente al edificio.",
  "Tu hermano llamó hace diez minutos.",
  "Deja las llaves sobre la mesa, Lucía.",
  "No voy a esperar hasta mañana.",
  "¿Recuerdas lo que pasó en Madrid?",
  "Esto no puede estar pasando otra vez."
];

const names = [
  "María",
  "Daniel",
  "Lucía",
  "Pablo",
  "Elena",
  "Javier",
  "Carmen",
  "Andrés",
  "Sofía",
  "Mateo"
];
const places = [
  "Madrid",
  "Barcelona",
  "Valencia",
  "Sevilla",
  "Bilbao",
  "el aeropuerto",
  "la estación",
  "el hotel",
  "la plaza",
  "el hospital"
];
const times = [
  "ahora mismo",
  "esta noche",
  "mañana temprano",
  "el viernes",
  "en cinco minutos",
  "a las tres",
  "después del almuerzo",
  "antes del amanecer",
  "el 12 de junio",
  "en 2019"
];
const verbs = [
  "salir",
  "esperar",
  "escuchar",
  "correr",
  "esconderte",
  "llamar",
  "decir la verdad",
  "cerrar la puerta",
  "mirar atrás",
  "confiar en mí"
];

function uniquePush(target, text, min, max) {
  const words = countWords(text);
  if (words < min || words > max) {
    return false;
  }
  if (target.includes(text)) {
    return false;
  }
  target.push(text);
  return true;
}

function generateShort(count) {
  const out = [];
  shortSeeds.forEach((line) => uniquePush(out, line, 5, 10));
  [
    "Cinco, cuatro, tres... ahora, ¡corre!",
    "¡No toques eso, te puedes lastimar!",
    "¡Date prisa, el auto no va a esperar!",
    "¡Cierra la puerta y no mires atrás!"
  ].forEach((line) => uniquePush(out, line, 5, 10));
  for (const name of names) {
    for (const place of places) {
      uniquePush(out, `${name}, tenemos que ir a ${place} ahora.`, 5, 10);
      uniquePush(out, `No quiero volver a ${place} contigo, ${name}.`, 5, 10);
      uniquePush(out, `¿De verdad viste a ${name} en ${place}?`, 5, 10);
    }
  }
  for (const time of times) {
    uniquePush(out, `El avión sale ${time}, no llegamos.`, 5, 10);
    uniquePush(out, `Prométeme que estarás listo ${time}.`, 5, 10);
    uniquePush(out, `Nadie iba a decir nada ${time}.`, 5, 10);
  }
  for (const verb of verbs) {
    uniquePush(out, `No es momento de ${verb}, ¿me oyes?`, 5, 10);
    uniquePush(out, `Si te digo que debes ${verb}, hazlo.`, 5, 10);
  }
  const extras = [
    "Hay veinticuatro personas en esa habitación.",
    "El número de vuelo es IB 3472.",
    "Tu teléfono sonó tres veces seguidas.",
    "No... no creo que sea una coincidencia.",
    "¿Quién dejó esa carta sobre mi cama?",
    "La contraseña cambió el martes pasado.",
    "Estamos a dos cuadras del río.",
    "Esa foto es de agosto de 2003.",
    "Habla más bajo, nos pueden oír.",
    "Traje café, pan y las llaves viejas.",
    "El perro ladró cuando abrieron la reja.",
    "No hay señal en este sótano húmedo.",
    "Cinco, cuatro, tres... ahora, ¡corre!",
    "¡No toques eso, te puedes lastimar!",
    "¡Date prisa, el auto no va a esperar!",
    "¿Cuánto dinero queda en la caja?",
    "Ella dijo que volvería a las nueve.",
    "Esto duele más de lo que esperaba.",
    "No firmes nada sin leerlo dos veces.",
    "La luz roja parpadea otra vez.",
    "¿Puedes cubrirme dos minutos, por favor?",
    "El mapa no coincide con las calles."
  ];
  extras.forEach((line) => uniquePush(out, line, 5, 10));
  if (out.length < count) {
    throw new Error(`short corpus too small: ${out.length}`);
  }
  return out.slice(0, count);
}

function generateMedium(count) {
  const out = [];
  const templates = [
    (name, place, time) =>
      `Escúchame bien, ${name}: si no salimos de ${place} ${time}, no vamos a contar esto mañana.`,
    (name, place, time) =>
      `No es que no te crea, ${name}, pero lo que viste en ${place} ${time} no tiene ningún sentido.`,
    (name, place, time) =>
      `Hay demasiadas preguntas y muy poco tiempo; ${name} dijo que el paquete estaría en ${place} ${time}.`,
    (name, place, time) =>
      `¿En serio piensas cruzar la ciudad hasta ${place} ${time} sin decirle nada a ${name}?`,
    (name, place, time) =>
      `${name} dejó una nota: «No abras la puerta de ${place} hasta que yo vuelva ${time}».`,
    (name, place, time) =>
      `El reloj de la cocina marca las ocho y media, y todavía no sabemos si ${name} llegó a ${place}.`,
    (name, place, time) =>
      `Bueno... si fallamos ahora, ${name}, nadie en ${place} va a creer que lo intentamos ${time}.`,
    (name, place, time) =>
      `Traje los documentos, las fotos y el número de teléfono, pero ${name} no estaba en ${place} ${time}.`,
    (name, place, time) =>
      `No grites, no corras y no mires atrás hasta que cruzemos ${place} con ${name} ${time}.`,
    (name, place, time) =>
      `Hace tres años, en ${place}, ${name} me dijo que esto iba a pasar ${time}, y no le hice caso.`
  ];
  for (const template of templates) {
    for (const name of names) {
      for (const place of places) {
        for (const time of times) {
          uniquePush(out, template(name, place, time), 11, 20);
          if (out.length >= count) {
            return out.slice(0, count);
          }
        }
      }
    }
  }
  throw new Error(`medium corpus too small: ${out.length}`);
}

function generateLong(count) {
  const out = [];
  const templates = [
    (name, place, time, verb) =>
      `No voy a repetirlo otra vez, ${name}: tenemos que ${verb} antes de llegar a ${place}, porque ${time} ya va a ser demasiado tarde para deshacer lo que hicimos anoche.`,
    (name, place, time, verb) =>
      `Cuando ${name} abrió la caja en ${place}, encontró una carta, un reloj roto y una foto de 1998, y entonces entendió por qué nadie quería ${verb} ${time}.`,
    (name, place, time, verb) =>
      `El plan era simple —entrar, ${verb}, salir— pero en ${place} había cámaras, dos guardias y el hermano de ${name}, así que ${time} todo se torció en menos de un minuto.`,
    (name, place, time, verb) =>
      `Si me estás oyendo, ${name}, deja de discutir y empieza a ${verb}; el tren hacia ${place} no espera y ${time} no habrá otro hasta el lunes a las seis y cuarto.`,
    (name, place, time, verb) =>
      `A veces pienso que debimos quedarnos callados, ${name}, en vez de ir a ${place} a ${verb} frente a toda esa gente ${time}, con la lluvia y los flashes y las preguntas sin respuesta.`
  ];
  for (const template of templates) {
    for (const name of names) {
      for (const place of places) {
        for (const time of times) {
          for (const verb of verbs) {
            uniquePush(out, template(name, place, time, verb), 21, 35);
            if (out.length >= count) {
              return out.slice(0, count);
            }
          }
        }
      }
    }
  }
  throw new Error(`long corpus too small: ${out.length}`);
}

function main() {
  if (tiny.length !== 100) {
    throw new Error(`expected 100 tiny strings, got ${tiny.length}`);
  }
  tiny.forEach((line) => {
    const words = countWords(line);
    if (words < 1 || words > 4) {
      throw new Error(`tiny out of range (${words}): ${line}`);
    }
  });
  if (new Set(tiny).size !== tiny.length) {
    throw new Error("tiny contains duplicates");
  }

  const short = generateShort(200);
  const medium = generateMedium(150);
  const long = generateLong(50);
  const items = [...tiny, ...short, ...medium, ...long];
  if (items.length !== 500) {
    throw new Error(`expected 500 items, got ${items.length}`);
  }
  if (new Set(items).size !== 500) {
    throw new Error("corpus contains duplicates");
  }

  const existingPath = path.join(__dirname, "..", "src", "translation", "common", "corpus.json");
  const existing = fs.existsSync(existingPath)
    ? JSON.parse(fs.readFileSync(existingPath, "utf8"))
    : {};
  const corpus = {
    language: "es",
    target: "en",
    generatedAt: new Date().toISOString(),
    counts: { tiny: tiny.length, short: short.length, medium: medium.length, long: long.length, total: items.length },
    firstTranslationProbe:
      existing.firstTranslationProbe ||
      "Esta oración se usa únicamente para medir la primera traducción.",
    warmup: existing.warmup || [],
    tiny,
    short,
    medium,
    long,
    items
  };

  const outPath = path.join(__dirname, "..", "src", "translation", "common", "corpus.json");
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, `${JSON.stringify(corpus, null, 2)}\n`, "utf8");
  console.log(`Wrote ${outPath} (${items.length} unique strings)`);
}

main();
