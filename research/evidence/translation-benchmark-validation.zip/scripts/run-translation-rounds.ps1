param(
    [int]$StartRound = 1,
    [switch]$SkipPrep
)

$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

function Invoke-Checked {
    param(
        [Parameter(Mandatory = $true)]
        [string]$FilePath,
        [string[]]$ArgumentList = @()
    )
    Write-Host ">> $FilePath $($ArgumentList -join ' ')"
    $previous = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    & $FilePath @ArgumentList
    $code = $LASTEXITCODE
    $ErrorActionPreference = $previous
    if ($null -eq $code) {
        $code = 0
    }
    if ($code -ne 0) {
        throw "Command failed ($code): $FilePath $($ArgumentList -join ' ')"
    }
}

function Get-OrderForRound([int]$Round) {
    switch ($Round) {
        1 { @("native", "chrome", "wasm") }
        2 { @("chrome", "wasm", "native") }
        3 { @("wasm", "native", "chrome") }
        4 { @("native", "wasm", "chrome") }
        5 { @("wasm", "chrome", "native") }
        6 { @("chrome", "native", "wasm") }
        default { throw "Unsupported round $Round" }
    }
}

function Assert-NoBenchmarkProcesses {
    Invoke-Checked -FilePath node -ArgumentList @("scripts/assert-no-benchmark-processes.cjs", "--kill-stale")
}

function Run-Engine {
    param(
        [string]$Engine,
        [int]$Round,
        [string]$Corpus
    )
    $pad = "{0:D2}" -f $Round
    $outputRel = "runs/round-$pad-$Engine.json"
    $outputPath = "results/$outputRel"
    if (Test-Path $outputPath) {
        Write-Host "Checking existing $outputPath"
        node "scripts/validate-run.cjs" "--engine" $Engine "--round" "$Round" "--corpus" $Corpus "--output" $outputPath
        if ($LASTEXITCODE -eq 0) {
            Write-Host "Skipping valid existing $outputPath"
            return
        }
    }
    switch ($Engine) {
        "chrome" {
            Invoke-Checked -FilePath node -ArgumentList @(
                "scripts/run-chrome-bench.cjs",
                "--run", "$Round",
                "--round", "$Round",
                "--corpus", $Corpus,
                "--output", $outputRel
            )
        }
        "wasm" {
            Invoke-Checked -FilePath npx -ArgumentList @(
                "electron", ".",
                "--mode=mozilla-bench",
                "--run=$Round",
                "--round=$Round",
                "--corpus=$Corpus",
                "--output=$outputRel",
                "--sequentialOnly=1"
            )
        }
        "native" {
            Invoke-Checked -FilePath node -ArgumentList @(
                "scripts/run-native-bench.cjs",
                "--run", "$Round",
                "--round", "$Round",
                "--corpus", $Corpus,
                "--output", $outputRel
            )
        }
        default { throw "Unknown engine $Engine" }
    }
    Invoke-Checked -FilePath node -ArgumentList @(
        "scripts/validate-run.cjs",
        "--engine", $Engine,
        "--round", "$Round",
        "--corpus", $Corpus,
        "--output", $outputPath
    )
}

if (-not $SkipPrep) {
    Write-Host "=== 1. npm test ==="
    Invoke-Checked -FilePath npm -ArgumentList @("test")

    Write-Host "=== 2. Frozen Mozilla artifacts ==="
    Invoke-Checked -FilePath node -ArgumentList @("scripts/validate-frozen-artifacts.cjs")

    Write-Host "=== 3. Native revision ==="
    $rev = git -C native/bergamot-translator rev-parse HEAD
    if ($rev -ne "9271618ebbdc5d21ac4dc4df9e72beb7ce644774") {
        throw "Unexpected bergamot commit $rev"
    }

    Write-Host "=== 4. Rebuild native-bench ==="
    $vcvars = "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
    if (-not (Test-Path $vcvars)) {
        throw "vcvars64.bat not found at $vcvars"
    }
    cmd.exe /c "`"$vcvars`" && cd /d native\bergamot-translator\build-native && ninja native-bench"
    if ($LASTEXITCODE -ne 0) {
        throw "ninja native-bench failed"
    }

    Write-Host "=== Collect machine.json ==="
    Invoke-Checked -FilePath node -ArgumentList @("scripts/collect-machine.cjs")

    Write-Host "=== 5. Chrome preflight ==="
    Invoke-Checked -FilePath node -ArgumentList @("scripts/prepare-chrome-benchmark.cjs")

    Write-Host "=== Reset run directories ==="
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue "results/runs"
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue "results/corpora"
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue "results/aggregate"
    New-Item -ItemType Directory -Force "results/runs" | Out-Null
    New-Item -ItemType Directory -Force "results/corpora" | Out-Null
    New-Item -ItemType Directory -Force "results/aggregate" | Out-Null

    Write-Host "=== 6. Generate round corpora ==="
    Invoke-Checked -FilePath node -ArgumentList @("scripts/generate-round-corpora.mjs")
} else {
    Write-Host "=== SkipPrep: keeping existing machine/preflight/corpora/runs ==="
}

for ($round = $StartRound; $round -le 6; $round++) {
    $pad = "{0:D2}" -f $round
    $corpus = "results/corpora/round-$pad.json"
    $order = Get-OrderForRound $round
    Write-Host "=== Round $round order: $($order -join ' -> ') ==="
    foreach ($engine in $order) {
        Assert-NoBenchmarkProcesses
        Run-Engine -Engine $engine -Round $round -Corpus $corpus
        Start-Sleep -Seconds 10
    }
}

Write-Host "=== 8. Aggregate ==="
Invoke-Checked -FilePath node -ArgumentList @("scripts/aggregate-results.mjs")

Write-Host "=== 9. Final report ==="
Invoke-Checked -FilePath node -ArgumentList @("scripts/generate-benchmark-report.mjs")

Write-Host "=== 10. npm test again ==="
Invoke-Checked -FilePath npm -ArgumentList @("test")

Write-Host "BENCHMARK ORCHESTRATION COMPLETE"
