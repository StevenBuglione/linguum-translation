nslation Benchmark Validation — Fix Before Any Kotlin Work

## Objective

Fix the existing benchmark so we can make a defensible final decision between:

* Google Chrome `Translator` API
* Mozilla/Firefox Bergamot WASM
* Native Mozilla Bergamot C++

The current native result is highly promising, but the harness has several methodological problems that must be corrected before we freeze the translation architecture.

**Do not implement Kotlin, JNI, JNA, KMP, C ABI wrappers, subtitle extraction, or production integration during this task.**

This task ends when we have a clean, reproducible, statistically useful multi-round benchmark report.

---

# 1. Freeze all engine/model versions first

Do **not** update dependencies or download newer Mozilla artifacts before rerunning.

Use the exact artifacts that produced the existing result.

Current Mozilla artifacts:

* Firefox Bergamot WASM version: `4.0`
* WASM SHA-256:
  `f38ef807636a7c994afedaab7ff8ffe0d590d21897f05139f747b80fd7bbe926`
* es→en model version: `2.0`
* model:
  `model.esen.intgemm.alphas.bin`
* model SHA-256:
  `4aed7734152ae0045d1a69ae49c86cfda18f53c61f90e95e1d1de1c7c7c3b033`
* vocab:
  `vocab.esen.spm`
* shortlist:
  `lex.50.50.esen.s2t.bin`

Native Bergamot:

* upstream:
  `browsermt/bergamot-translator`
* commit:
  `9271618ebbdc5d21ac4dc4df9e72beb7ce644774`
* Marian:
  `2781d735`
* use current working native build configuration
* `AsyncService`
* `numWorkers = 1`
* `cacheSize = 0`
* MSVC x64 Release
* `/arch:AVX2`
* native intgemm enabled
* existing ONNX SGEMM fallback
* do **not** switch BLAS implementations during this validation

Chrome:

* use currently installed stable Google Chrome
* record exact Chrome version in every run
* do not update Chrome between rounds

Also retain the existing `package-lock.json`.

The goal is to fix the harness, **not change the engines being measured**.

---

# 2. Fix the warmup contamination immediately

Current problem:

Six existing warmup strings also occur in the measured 500-string corpus:

```text
Sí.
Vamos.
¿Qué pasó?
No lo sé.
Ven conmigo.
¿En serio quieres hacer esto ahora?
```

This must be fixed.

There must be:

* exactly 1 first-translation probe
* exactly 20 warmup strings
* exactly 500 measured strings
* zero overlap between probe, warmup, and measured corpus
* 500 measured strings must remain unique

Do **not** change the existing 500 measured strings.

Move warmup data into:

```text
src/translation/common/corpus.json
```

so every engine uses the exact same warmup data.

Add:

```json
{
  "firstTranslationProbe": "Esta oración se usa únicamente para medir la primera traducción.",
  "warmup": [
    "Lucía dejó las llaves junto a la ventana.",
    "Mañana iremos temprano al mercado central.",
    "El ascensor se detuvo en el séptimo piso.",
    "Carlos prometió llamar después de la reunión.",
    "Nunca había visto una tormenta tan silenciosa.",
    "Guarda ese documento antes de cerrar la computadora.",
    "El café de la esquina abre a las seis.",
    "Necesitamos otra botella de agua para el viaje.",
    "La puerta azul conduce al patio interior.",
    "Recuérdame comprar pan cuando salgamos.",
    "Anoche dejaron un paquete frente a mi casa.",
    "El autobús cambia de ruta durante el festival.",
    "Prefiero sentarme cerca de la salida.",
    "La reserva está a nombre de Daniela Torres.",
    "Apaga la luz del pasillo cuando termines.",
    "El museo cierra media hora más tarde los viernes.",
    "Nos encontraremos debajo del reloj de la estación.",
    "Olvidé cargar el teléfono antes de salir.",
    "El perro escondió su juguete detrás del sofá.",
    "Pon la chaqueta en la silla junto a la puerta."
  ]
}
```

Keep the existing measured `items`, `tiny`, `short`, `medium`, and `long` data.

Remove the duplicated hard-coded warmup arrays from:

```text
src/translation/common/benchmark.js
scripts/run-native-bench.cjs
```

All three engines must read the warmup from the same corpus source.

Add unit tests asserting:

```text
warmup.length === 20
items.length === 500
new Set(items).size === 500

firstTranslationProbe ∉ warmup
firstTranslationProbe ∉ items

intersection(warmup, items).length === 0
```

---

# 3. Stop overwriting benchmark results

Current broken behavior:

```text
results/chrome-translation.json
results/mozilla-translation.json
results/native-bergamot-translation.json
```

are overwritten.

This invalidates the claimed multi-round benchmark.

Replace this with:

```text
results/
├── runs/
│   ├── round-01-chrome.json
│   ├── round-01-wasm.json
│   ├── round-01-native.json
│   ├── round-02-chrome.json
│   ├── round-02-wasm.json
│   ├── round-02-native.json
│   └── ...
│
├── corpora/
│   ├── round-01.json
│   ├── round-02.json
│   └── ...
│
├── aggregate/
│   └── translation-comparison.json
│
└── FINAL_BENCHMARK_REPORT.md
```

Before a complete benchmark:

```text
delete results/runs/
delete results/corpora/
delete results/aggregate/
```

Never rely on a stale file to detect benchmark completion.

---

# 4. Fix the Chrome stale-result bug

Current `scripts/run-chrome-bench.cjs` waits for:

```text
results/chrome-translation.json
```

but only deletes it when `--fresh` is explicitly passed.

The multi-round script doesn't pass `--fresh`.

Therefore later Chrome runs can immediately consume an older result and falsely report completion.

Replace this architecture entirely.

Each Chrome invocation must be given:

```text
--run <N>
--output round-NN-chrome.json
--corpus /results/corpora/round-NN.json
```

Before launching Chrome:

```javascript
fs.rmSync(outFile, { force: true });
```

Then wait **only** for that exact output file.

After reading it, verify:

```text
payload.run === expectedRun
payload.round === expectedRound
payload.engine === "chrome-translator-api"
payload.results sequential count === 500
payload.corpusSha256 === expected corpus SHA
```

If any mismatch occurs:

```text
FAIL THE RUN
```

Do not silently continue.

---

# 5. Give Chrome an isolated benchmark profile

Do not reuse Steve's normal Chrome session.

Use a dedicated persistent profile such as:

```text
tmp/chrome-benchmark-profile/
```

Launch Chrome with:

```text
--user-data-dir=<absolute benchmark profile path>
--new-window
--no-first-run
--no-default-browser-check
```

Do **not** use:

```text
UA spoofing
performance flags
feature-disabling flags
GPU flags
translation flags
```

The dedicated profile exists only to:

* avoid extensions
* avoid unrelated tabs
* prevent the normal Chrome process from contaminating the benchmark
* preserve the locally downloaded Chrome translation model between rounds

Do not run Chrome detached and leave processes/windows open.

After each benchmark output is safely written:

* close that benchmark Chrome process
* ensure its process tree is gone before the next engine starts

On Windows, using `taskkill /PID <pid> /T /F` after result completion is acceptable for this disposable benchmark profile.

---

# 6. Add a Chrome preflight before measured rounds

Measured Chrome rounds must not include model download/setup noise.

Create:

```text
scripts/prepare-chrome-benchmark.cjs
```

It must:

1. launch the dedicated Chrome benchmark profile
2. open the translation benchmark page
3. check:

```javascript
Translator.availability({
  sourceLanguage: "es",
  targetLanguage: "en"
})
```

4. if the language pack needs download, let Chrome download it
5. create the translator
6. perform one test translation
7. close Chrome
8. save:

```text
results/chrome-preflight.json
```

Measured rounds start only after the Chrome model is locally available.

If a measured round begins downloading a model:

```text
ABORT THE ROUND
```

and redo the preflight.

---

# 7. Deterministically shuffle the measured corpus per round

Current measured order is:

```text
100 tiny
200 short
150 medium
50 long
```

That can correlate sentence length with CPU temperature, boost behavior, or later-run system state.

Create:

```text
scripts/generate-round-corpora.mjs
```

Use deterministic Fisher-Yates shuffling with a fixed PRNG.

Use exactly six seeds:

```text
round 1 = 42001
round 2 = 42002
round 3 = 42003
round 4 = 42004
round 5 = 42005
round 6 = 42006
```

For every round write:

```text
results/corpora/round-01.json
...
round-06.json
```

Each file contains:

```json
{
  "round": 1,
  "seed": 42001,
  "items": [500 shuffled strings],
  "sourceCorpusSha256": "...",
  "roundCorpusSha256": "..."
}
```

The original 500 strings must not be modified.

Only their order changes.

**All three engines in a given round must consume the exact same round corpus file.**

Do not independently shuffle inside Chrome, WASM, or native.

That guarantees identical ordering.

---

# 8. Use six rounds, not three or five

There are three engines.

Three engines have exactly:

```text
3! = 6
```

possible execution orders.

Use all six permutations so engine position is perfectly balanced.

Run exactly:

```text
Round 1:
Native
Chrome
WASM

Round 2:
Chrome
WASM
Native

Round 3:
WASM
Native
Chrome

Round 4:
Native
WASM
Chrome

Round 5:
WASM
Chrome
Native

Round 6:
Chrome
Native
WASM
```

This means every engine appears:

* first exactly twice
* second exactly twice
* third exactly twice

This removes a large amount of thermal/order bias.

Between engines:

```powershell
Start-Sleep -Seconds 10
```

Before every round:

```text
verify no previous Chrome benchmark process
verify no previous Electron benchmark process
verify no native benchmark process
```

---

# 9. Replace `run-translation-rounds.ps1`

The script must now orchestrate:

```text
preflight
generate corpora
six balanced rounds
three engines per round
validate every result
aggregate results
generate final report
```

Pseudo-flow:

```powershell
npm test

node scripts/prepare-chrome-benchmark.cjs

node scripts/generate-round-corpora.mjs

foreach ($round in 1..6) {

    $order = Get-OrderForRound($round)

    foreach ($engine in $order) {

        Assert-NoBenchmarkProcesses

        Run-Engine `
            -Engine $engine `
            -Round $round `
            -Corpus "results/corpora/round-$round.json"

        Validate-Result

        Start-Sleep -Seconds 10
    }
}

node scripts/aggregate-results.mjs

node scripts/generate-benchmark-report.mjs
```

The orchestration script must stop immediately on any failed run.

No partial success should be presented as a valid six-round benchmark.

---

# 10. Fix native runner to support actual rounds

Current:

```text
scripts/run-native-bench.cjs
```

hard-codes:

```javascript
run: 1
```

and always writes:

```text
native-bergamot-translation.json
```

Change it to require:

```text
--run N
--corpus path
--output path
```

Example:

```powershell
node scripts/run-native-bench.cjs `
    --run 3 `
    --corpus results/corpora/round-03.json `
    --output results/runs/round-03-native.json
```

The native runner must use:

```text
corpus.warmup from the canonical base corpus
+
the shuffled measured items from round-03.json
```

The output must record:

```json
{
  "engine": "mozilla-bergamot-native",
  "run": 3,
  "round": 3,
  "seed": 42003,
  "corpusSha256": "...",
  "service": "AsyncService",
  "workers": 1,
  "cacheSize": 0
}
```

---

# 11. Correct the native metadata

Current result incorrectly says:

```text
bergamot-translator native C++ BlockingService
```

That is false.

The actual code uses:

```cpp
AsyncService
```

Change the metadata to something like:

```json
{
  "engine": "mozilla-bergamot-native",
  "version": "bergamot-translator@9271618ebbdc5d21ac4dc4df9e72beb7ce644774",
  "service": "AsyncService",
  "workers": 1,
  "cacheSize": 0,
  "build": "Release",
  "architecture": "x64",
  "cpuIsa": "AVX2",
  "intgemm": true,
  "sgemm": "onnxjs-fallback",
  "marianCommit": "2781d735"
}
```

Do not claim `BlockingService` anywhere in the generated report.

---

# 12. Fix initialization timing

Current initialization values are not comparable.

Native currently constructs:

```cpp
AsyncService
TranslationModel
```

**before** starting the initialization timer.

Mozilla loads model files before its timer.

Chrome measures a different lifecycle.

Replace the current meaning with three explicit metrics:

```text
engineSetupMs
firstTranslationMs
warmInference
```

### Chrome

`engineSetupMs`:

Start timer immediately before:

```javascript
Translator.availability(...)
Translator.create(...)
```

End when the translator is ready.

The Chrome model must already be downloaded from the preflight.

Then translate:

```text
firstTranslationProbe
```

and record:

```text
firstTranslationMs
```

Then run the 20 warmup strings.

Then measured benchmark.

### Mozilla WASM

`engineSetupMs` starts **before**:

```javascript
loadLocalManifest()
loadPairBuffers()
worker creation
WASM initialization
model creation
```

Ends when worker sends:

```text
ready
```

Then translate the canonical first probe.

Record:

```text
firstTranslationMs
```

Then 20 warmups.

### Native

Move the setup timer to before:

```cpp
parseOptionsFromFilePath()
AsyncService construction
createCompatibleModel()
```

End after the model is ready.

Record this as:

```text
engineSetupMs
```

Then translate the canonical first probe and record:

```text
firstTranslationMs
```

Then perform the 20 canonical warmups.

Then begin measured translations.

Do not include the probe in warmup.

Do not include warmup in measured samples.

### Important

Do **not** use engine setup to determine the performance winner.

The primary decision remains warm subtitle translation.

Setup metrics are informational.

---

# 13. Fix throughput math

Current:

```javascript
elapsedMs =
    samples.reduce(
        (sum, sample) => sum + sample.totalMs,
        0
    );
```

is not valid for concurrent/burst workloads.

If two requests execute concurrently for 100 ms:

```text
actual elapsed = 100 ms
current calculation = 200 ms
```

That halves reported throughput incorrectly.

Change the benchmark functions to explicitly measure wall clock.

### `runSequential`

Return:

```javascript
{
  records,
  wallClockMs
}
```

where:

```javascript
const runStartedAt = performance.now();

...perform all sequential translations...

const wallClockMs =
    performance.now() - runStartedAt;
```

### `runBurst`

Same:

```javascript
const runStartedAt = performance.now();

await Promise.all(...workers);

const wallClockMs =
    performance.now() - runStartedAt;
```

### `runMicroBatch`

Same:

```javascript
const runStartedAt = performance.now();

...all batches...

const wallClockMs =
    performance.now() - runStartedAt;
```

Then:

```text
translationsPerSecond =
    records.length / (wallClockMs / 1000)

wordsPerSecond =
    totalWords / (wallClockMs / 1000)

charactersPerSecond =
    totalCharacters / (wallClockMs / 1000)
```

Per-item latency remains derived from the individual records.

**Latency and throughput must use separate concepts.**

---

# 14. Change `summarizeLatencies`

Update:

```text
src/translation/common/statistics.js
```

so:

```javascript
summarizeLatencies(samples, wallClockMs)
```

requires real wall-clock duration for throughput.

Do not silently fall back to summing `totalMs` for burst/batch workloads.

Return:

```json
{
  "count": 500,
  "wallClockMs": 12345,
  "p50Ms": 0,
  "p95Ms": 0,
  "p99Ms": 0,
  "translationsPerSecond": 0,
  "wordsPerSecond": 0,
  "charactersPerSecond": 0
}
```

Add a standard-deviation helper for later run-level aggregation.

---

# 15. Update `summarizeRun`

Change:

```javascript
summarizeRun(...)
```

to receive:

```text
records
wallClockMs
engineSetupMs
firstTranslationMs
```

Output all three.

Every result must include:

```json
{
  "engineSetupMs": 0,
  "firstTranslationMs": 0,
  "wallClockMs": 0
}
```

---

# 16. Report metrics by subtitle bucket

For every **sequential** run, calculate independently:

```text
tiny
short
medium
long
```

For each bucket report:

```text
count
mean
p50
p90
p95
p99
min
max
```

The final report must contain at least:

| Bucket | Chrome p95 | WASM p95 | Native p95 |
| ------ | ---------: | -------: | ---------: |
| Tiny   |            |          |            |
| Short  |            |          |            |
| Medium |            |          |            |
| Long   |            |          |            |

`short` is especially important because 5–10-word strings are highly representative of live subtitles.

---

# 17. Do not report JS heap as total engine memory

Current Chrome/Mozilla values based on:

```javascript
performance.memory.usedJSHeapSize
```

do **not** represent the actual engine/model memory.

They omit important browser/WASM/native allocations.

Change field naming to:

```text
jsHeapUsedMb
```

and mark it:

```text
informational only
```

Remove it from any cross-engine winner table.

For this rerun:

* memory must **not** affect the pass/fail decision
* native RSS/working-set measurement may be recorded if easy
* do not delay the benchmark over memory instrumentation

If native working set is added, label it separately:

```text
nativeWorkingSetMb
nativePeakWorkingSetMb
```

Never compare that directly to Chrome's JS heap.

---

# 18. Fix the result JSON schema

Current schema does not even allow:

```text
mozilla-bergamot-native
```

as an engine.

Update:

```text
src/translation/common/result-schema.json
```

Engine enum:

```json
[
  "chrome-translator-api",
  "mozilla-bergamot",
  "mozilla-bergamot-native"
]
```

Add:

```text
round
seed
corpusSha256
engineSetupMs
firstTranslationMs
wallClockMs
```

Change memory fields so they can legitimately be null or be stored under an informational memory object.

Example:

```json
"memory": {
  "type": ["object", "null"]
}
```

---

# 19. Validate exact corpus identity

Every result must include:

```text
round
seed
corpusSha256
```

The aggregator must reject a round unless:

```text
Chrome SHA
==
WASM SHA
==
Native SHA
```

for that round.

It must also verify the actual `source` sequence in all 500 sample records is identical across all three engines.

If sample 17 differs between engines:

```text
FAIL THE ROUND
```

This prevents accidental corpus mismatch.

---

# 20. Add tests for all benchmark bugs

Keep the existing tests.

Add tests for:

### Warmup isolation

```text
20 warmups
500 measured
zero intersection
probe not present anywhere else
```

### Round corpora

```text
6 round files
500 items each
all unique
same underlying set
different deterministic order
correct seed
correct hash
```

### Throughput

Synthetic test:

```text
2 concurrent requests
100 ms each
wall time ≈ 100 ms
TPS must use 100 ms, not 200 ms
```

### Microbatch throughput

Same principle.

### Result validation

Reject:

```text
wrong run number
wrong engine
wrong corpus hash
wrong sample count
stale output
```

### Aggregator

Reject if:

```text
not exactly 6 sequential runs per engine
round missing
engine missing
corpus hashes differ
sample source order differs
```

Before benchmarking:

```powershell
npm test
```

must be fully green.

Report the new test count.

---

# 21. Do not regenerate the existing measured corpus

The existing 500 strings are good.

Keep:

```text
100 tiny
200 short
150 medium
50 long
```

The only corpus changes are:

* add canonical first probe
* replace contaminated warmup set
* create shuffled per-round copies of the same measured strings

That preserves continuity with the original benchmark.

---

# 22. Add run-level aggregation

Create:

```text
scripts/aggregate-results.mjs
```

It must load all:

```text
6 Chrome runs
6 WASM runs
6 native runs
```

For each engine calculate the run-level distribution of:

```text
p50
p95
p99
mean
translations/sec
words/sec
```

For each metric report:

```text
mean across runs
median across runs
standard deviation
min
max
```

Also calculate pooled sample latency across all:

```text
6 × 500 = 3,000
```

measured translations per engine.

Report pooled statistics separately.

Do **not** substitute pooled p95 for run-to-run variance.

We need both.

---

# 23. Add paired round comparisons

Because all three engines receive the same shuffled corpus within a round, compare them as paired runs.

For every round calculate:

```text
native p50 / Chrome p50
native p95 / Chrome p95
native p99 / Chrome p99

WASM p50 / Chrome p50
WASM p95 / Chrome p95
WASM p99 / Chrome p99
```

Example:

```text
Round 1 native/Chrome p95 = 0.68
Round 2 native/Chrome p95 = 0.73
...
```

Report:

```text
median ratio
mean ratio
min ratio
max ratio
```

Also report:

```text
Native p95 wins vs Chrome: X / 6
Native p50 wins vs Chrome: X / 6
```

This is more meaningful than quoting one lucky run.

---

# 24. Final performance classification

### Native Bergamot absolute viability

Every native round must satisfy:

```text
p95 <= 150 ms
p99 <= 250 ms
translations/sec >= 10
```

If not:

```text
NATIVE NOT VALIDATED
```

### Native vs Chrome strict win

Call native **faster than Chrome** only if:

```text
median native p50 <= median Chrome p50

AND

median native p95 <= median Chrome p95

AND

native p95 beats Chrome p95 in at least 5 of 6 rounds
```

### Equivalent

If native remains within:

```text
10%
```

of Chrome p95 and satisfies absolute subtitle latency:

```text
NATIVE EQUIVALENT / VIABLE
```

### WASM

Use the same absolute subtitle gates:

```text
p95 <= 150 ms
p99 <= 250 ms
```

but WASM does not need to beat native.

---

# 25. Generate a new final report

Do not reuse the current `FINAL_REPORT.md` logic that reads one file per engine.

Create:

```text
results/FINAL_BENCHMARK_REPORT.md
```

It must start with:

```text
TRANSLATION PERFORMANCE VALIDATION

Rounds completed: 6 / 6
Samples per engine per round: 500
Total measured samples per engine: 3,000
Warmup per engine per run: 20
Warmup overlap with corpus: 0
Corpus order: deterministic and paired per round
Chrome model pre-downloaded: YES
Caches:
  WASM Bergamot: 0
  Native Bergamot: 0
```

Then a table:

```text
                         Chrome       WASM       Native

Median run p50
Median run p95
Median run p99

Mean run p50
Mean run p95
Mean run p99

p95 stddev

Pooled p50
Pooled p95
Pooled p99

Median TPS
Median words/sec
```

Then:

```text
NATIVE VS CHROME

p50 wins: X/6
p95 wins: X/6
p99 wins: X/6

median p50 ratio:
median p95 ratio:
median p99 ratio:
```

Then bucket results.

Then all six individual runs:

```text
Round 1
Chrome p95:
WASM p95:
Native p95:

Round 2
...
```

---

# 26. Remove misleading cold-start comparison from the winner table

The previous report showed:

```text
Mozilla 71 ms
Native 84 ms
Chrome 240 ms
```

Those were not timing equivalent initialization stages.

After the fixes, report:

```text
engineSetupMs
firstTranslationMs
```

under a separate:

```text
STARTUP — INFORMATIONAL
```

section.

Do not declare a startup winner unless the lifecycle is genuinely comparable.

Warm subtitle performance is the architecture gate.

---

# 27. Native binary rebuild

Because `native/native-bench.cpp` must change for:

* proper engine setup timing
* first-translation timing

rebuild `native-bench.exe`.

Use exactly the existing working build configuration.

Do **not**:

```text
upgrade Bergamot
upgrade Marian
switch to MKL
switch to OpenBLAS
change worker count
enable translation cache
change model
change quantization
```

This is a benchmark-validation pass, not an optimization pass.

---

# 28. Verify native and WASM still use identical Mozilla model data

Before every full benchmark, assert SHA-256 of:

```text
model.esen.intgemm.alphas.bin
vocab.esen.spm
lex.50.50.esen.s2t.bin
```

matches the manifest.

Native and WASM must consume those same files.

If hashes differ:

```text
ABORT
```

---

# 29. Keep translation caches disabled

Mozilla WASM:

```javascript
new bergamot.BlockingService({
    cacheSize: 0
})
```

Native:

```cpp
serviceConfig.cacheSize = 0;
```

Do not enable caching.

Chrome's internal implementation is outside our control, which is another reason the warmup set must never overlap the measured corpus.

---

# 30. Machine setup before the benchmark

Before running:

```text
Plug machine into power
Use normal high-performance Windows power mode
Close IDEs if not needed
Close games
Close streaming video
Close browsers except benchmark-controlled Chrome
No RDP
No remote desktop software
No builds running
No Windows Update
No large downloads
No antivirus full scan
```

Do not set:

```text
Realtime process priority
CPU affinity hacks
GPU overrides
```

We want realistic desktop performance.

Record machine information once in:

```text
results/machine.json
```

---

# 31. Exact execution order

After all fixes:

```powershell
# 1. Verify source/tests
npm test

# 2. Verify/freeze Mozilla artifacts
# Do NOT refetch them.
# Validate existing hashes only.

# 3. Verify native repo revision
git -C native/bergamot-translator rev-parse HEAD

# Must be:
# 9271618ebbdc5d21ac4dc4df9e72beb7ce644774

# 4. Rebuild native-bench with the corrected timing instrumentation

# 5. Prepare Chrome translation model/profile
node scripts/prepare-chrome-benchmark.cjs

# 6. Generate six deterministic round corpora
node scripts/generate-round-corpora.mjs

# 7. Execute all six balanced rounds
powershell -ExecutionPolicy Bypass -File scripts/run-translation-rounds.ps1

# 8. Aggregate
node scripts/aggregate-results.mjs

# 9. Generate final report
node scripts/generate-benchmark-report.mjs

# 10. Run tests again
npm test
```

---

# 32. Required files to hand back

Return all of:

```text
results/FINAL_BENCHMARK_REPORT.md

results/aggregate/translation-comparison.json

results/runs/
  round-01-chrome.json
  round-01-wasm.json
  round-01-native.json
  ...
  round-06-chrome.json
  round-06-wasm.json
  round-06-native.json

results/corpora/
  round-01.json
  ...
  round-06.json

results/chrome-preflight.json
results/machine.json
```

Also return:

```text
git diff
```

or a summary of every benchmark-related file changed.

---

# 33. Required final Grok summary

End with exactly this style of result:

```text
BENCHMARK VALIDATION COMPLETE

Machine:
<CPU>
<RAM>
<Windows>

Measured rounds:
6

Samples / engine:
3,000

Warmup contamination:
FIXED — ZERO OVERLAP


CHROME

median p50:
median p95:
median p99:
p95 stddev:
median TPS:


MOZILLA WASM

median p50:
median p95:
median p99:
p95 stddev:
median TPS:


NATIVE BERGAMOT

median p50:
median p95:
median p99:
p95 stddev:
median TPS:


NATIVE VS CHROME

p50 wins:
X / 6

p95 wins:
X / 6

p99 wins:
X / 6

median p95 ratio:
X


ABSOLUTE SUBTITLE GATE

Native p95 <= 150ms:
PASS / FAIL

Native p99 <= 250ms:
PASS / FAIL

Native >= 10 translations/sec:
PASS / FAIL


DECISION

NATIVE BERGAMOT:
FASTER THAN CHROME /
EQUIVALENT TO CHROME /
SLOWER BUT VIABLE /
NOT VIABLE

MOZILLA WASM:
VIABLE /
NOT VIABLE


KOTLIN INTEGRATION:

DO NOT START automatically.

Return these results for architectural review first.
```

---

# 34. Hard stop

After generating the report:

**STOP.**

Do not implement:

```text
JNI
JNA
Kotlin
KMP
C ABI
production native library
subtitle pipeline
```

I want the corrected result files reviewed first.

The benchmark architecture decision must be closed before we introduce another language boundary and another source of latency.

