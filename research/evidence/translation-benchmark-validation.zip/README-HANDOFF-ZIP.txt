Minified performance-test zip for GPT-Pro.
Excluded: node_modules, Electron binaries, Bergamot clone/build, WASM, model .bin/.spm, Chrome profile, native-bench.exe.
Included: source, tests, scripts, corpus, results/runs, results/corpora, aggregate, FINAL_BENCHMARK_REPORT.md, chrome-preflight.json, machine.json, HANDOFF.md, harness-fix.md.
Start at results/FINAL_BENCHMARK_REPORT.md and HANDOFF.md.
