# HANDOFF: Windows ECS + Mozilla Bergamot architecture spike

**For:** GPT-Pro review and assessment  
**Date:** 2026-08-20  
**Repo path:** `D:\Users\steve\performance-test`  
**Git branch:** `spike/ecs-mozilla-translation` (commit `24c82b9` plus later native-bench files; results JSON are gitignored)  
**Package name:** `language-os-desktop-architecture-spike`  
**Original spec:** `PLAN.md`

This document is the full context dump. It includes what was built, what was measured, what is still blocked, and the intended next product step: a **Kotlin Multiplatform native library** that interops with **native C++ Bergamot** on Windows and macOS.

---

## 1. Product intent (why this spike exists)

A desktop “language OS” app needs two hard capabilities:

1. Play **Netflix, Prime Video, and Max** with official DRM (Widevine) on a normal Windows 11 desktop session.
2. Translate **subtitle-sized text** locally, in real time, without a cloud API.

The intended production shape is **not** “run translation inside Chromium.” It is:

```
CastLabs ECS (Chromium + Widevine)
  └── streaming renderer (Netflix / Prime / Max)
          │
          │ subtitle text events (future: site plugins)
          ▼
Native translation process
  └── Bergamot C++ / Marian / intgemm
  └── Mozilla Firefox released models (MPL 2.0)
          │
          ▼
translated subtitle
```

The spike was only allowed to prove capability. Explicit non-goals in `PLAN.md`: real subtitle extraction, Netflix/Prime/Max plugins, dual caption UI, AI tutor, vocabulary storage, **Kotlin/KMP**, production UI, authentication, cloud hosting, browser tabs, password import, auto updater.

The owner’s **next** intent after this spike: a KMP library that is the official Windows/macOS binding to the native Bergamot engine.

---

## 2. Questions the spike was supposed to answer

### Question A — DRM / browser

Can official CastLabs ECS play Netflix, Prime Video, and Max on a local Windows 11 session with **no** RDP, UA spoof, browser flags, request rewriting, custom Chromium, or DRM workarounds?

### Question B — translation latency

Can Mozilla Firefox Translations / Bergamot translate subtitle-sized Spanish→English locally at latency comparable to Chrome’s on-device `Translator` API?

Absolute gates from the plan:

- Mozilla warm p95 ≤ 150 ms
- Mozilla warm p99 ≤ 250 ms
- Throughput ≥ 10 short subtitle lines / second
- Relative: Mozilla p50 ≤ Chrome p50 × 1.05 and p95 ≤ Chrome p95 × 1.10, **or** classify as slower-but-viable if p95 still ≤ 150 ms

### Question C — coexistence

Can translation run while DRM video plays without material video/audio/DRM damage (translation p95 under video ≤ 200 ms; dropped-frame impact ≲ 1 percentage point)?

---

## 3. Machine and session

Collected in `results/machine.json`.

| Item | Value |
| --- | --- |
| OS | Windows 11 Pro `10.0.26100` |
| Session | `SESSIONNAME=Console` — physical local, **RDP disconnected** |
| CPU | AMD Ryzen 9 5900X, 24 logical processors |
| RAM | 127.93 GB |
| GPU used for reporting | NVIDIA GeForce RTX 3070, driver `32.0.16.1088`, 2560×1440 @ 59 Hz |
| Also installed | **Parsec Virtual Display Adapter**, **Meta Virtual Monitor** |
| Node | 23.8.0 |
| Chrome | Installed at `C:\Program Files\Google\Chrome\Application\chrome.exe` (Translator API worked; pack status was `downloadable` then created) |
| Toolchain used for native | Visual Studio 2022 Community, MSVC 14.44, CMake 4.0.2, Ninja |

**Reviewer note:** PLAN.md forbids Parsec/virtual displays for the DRM acceptance run. The NVIDIA panel is present. DRM tests must use the physical display, not Parsec.

---

## 4. What exists in the repo

### 4.1 ECS harness (Question A infrastructure)

Pinned: **CastLabs Electron 43.2.0+wvcus** via

```text
https://github.com/castlabs/electron-releases#v43.2.0+wvcus
```

Entry: `src/ecs/main.cjs`

Secure defaults (as specified):

- `nodeIntegration: false`
- `contextIsolation: true`
- `sandbox: true`
- `webSecurity: true`
- no `--disable-web-security`, `--no-sandbox`, UA spoof, request rewriting, or copied Chrome Widevine

Modes:

- `--mode=harness` — operator UI
- `--mode=mozilla-bench` — WASM Bergamot inside ECS
- `--mode=youtube-control` — YouTube probe (no login)
- `--mode=streaming --service=netflix|prime|max|youtube`

Services and checklist: `src/ecs/services.cjs`  
Local static server: `src/ecs/static-server.cjs` on `127.0.0.1:8765`

### 4.2 Mozilla WASM path (Question B, Chromium)

Firefox-equivalent stack **inside ECS**:

- Worker: `src/translation/mozilla/translation-worker.js`
- Adapter: `src/translation/mozilla/bergamot-adapter.js` (mirrors Firefox `BergamotUtils` / `BlockingService`, `cacheSize: 0`)
- JS glue: Firefox in-tree `bergamot-translator.js`
- WASM: Firefox CI `tr8ns.inference` v4.0 (`bergamot-translator.wasm`, 4 960 506 bytes, sha256 `f38ef807…`)
- Models: Firefox Remote Settings **released** `es-en` (v2.0) and `en-es` (v2.1)

Important: Firefox’s fast path imports **native `mozIntGemm`**. Chromium/ECS does not provide that. WASM in ECS uses the embedded GEMM fallback. That is why WASM lost to Chrome even though it cleared the 150 ms gate.

### 4.3 Chrome baseline

Must run in **installed Google Chrome**, not ECS. Chrome `Translator` API is a Chrome built-in, not a generic Chromium/Electron API.

- `src/translation/chrome/index.html`
- `scripts/run-chrome-bench.cjs` serves `http://127.0.0.1:8766`

### 4.4 Native C++ Bergamot (the production-shaped engine)

Source clone (gitignored, large):

```text
D:\Users\steve\performance-test\native\bergamot-translator
```

Upstream: `https://github.com/browsermt/bergamot-translator` at `v0.4.5+9271618`  
Marian: `v1.9.56+2781d735`  
Bench harness we wrote: `native/native-bench.cpp`  
Binary: `native/bergamot-translator/build-native/app/native-bench.exe`  
Runner: `scripts/run-native-bench.cjs`

**Same model files as WASM.** No conversion.

Build that actually ran (Windows):

- Generator: Ninja + MSVC x64 Release
- `BUILD_ARCH=native` → `/arch:AVX2`
- `USE_INTGEMM=ON` (native kpu/intgemm)
- `COMPILE_CUDA=OFF`, `USE_MKL=OFF` (no MKL/OpenBLAS on this machine)
- `USE_WASM_COMPATIBLE_SOURCE=ON` **only** so leftover **float32 SGEMM** uses onnxjs instead of crashing (`Marian must be compiled with a BLAS library`)
- `SSPLIT_USE_INTERNAL_PCRE2=ON`, PCRE2 built `/MT` static
- `BlockingService` **crashed** on first translate on this MSVC build
- **`AsyncService` with `numWorkers=1`, `cacheSize=0` worked** and is what was benchmarked
- Linker `/STACK:16777216` on the bench exe

macOS was **not** built in this spike. The Bergamot tree already contains `patches/01-marian-fstream-for-macos.patch`. macOS should use Apple Accelerate for the remaining SGEMM rather than onnxjs.

### 4.5 Corpus and tests

- `src/translation/common/corpus.json`: 500 unique Spanish strings  
  100 tiny (1–4 words), 200 short (5–10), 150 medium (11–20), 50 long (21–35)
- Warmup: 20 throwaway sentences, discarded
- Unit tests: `npm test` → **27/27 pass** (`node --test test/*.test.js`)

### 4.6 Licenses

- Models: MPL 2.0 (`licenses/mozilla-translations-MPL-2.0.txt`)
- Bergamot: MPL 2.0 (`licenses/bergamot-MPL-2.0.txt`)
- Spike did not modify Bergamot engine sources except local Windows build glue (ssplit PCRE2 static, cmake policy, bench executable). Prefer **not** forking Marian for production.

---

## 5. Measured results (Question B)

All sequential, same 500 strings, same order, warmup discarded.

| Metric | Mozilla WASM in ECS | **Native C++ Bergamot** | Chrome Translator API |
| --- | ---: | ---: | ---: |
| Warm p50 | 21.90 ms | **9.63 ms** | 14.60 ms |
| Warm p95 | 61.92 ms | **27.63 ms** | 40.72 ms |
| Warm p99 | 66.30 ms | **29.58 ms** | 44.20 ms |
| translations/sec | 35.73 | **80.96** | 53.04 |
| words/sec | 410 | **929** | 609 |
| cold init | 71 ms | 84 ms | 240 ms |

Ratios:

- WASM vs Chrome p95: **1.52** (Chrome faster; WASM still viable under 150 ms)
- Native vs Chrome p95: **0.68** (native faster)
- Native vs WASM p95: **0.45** (~2.2×)

Quality sanity (not a COMET eval): `Sí.` → WASM `Yes.` / native `Yes.` / Chrome `yes.`

### Gate classification

| Gate | WASM | Native C++ |
| --- | --- | --- |
| p95 ≤ 150 ms | PASS (62 ms) | PASS (28 ms) |
| p99 ≤ 250 ms | PASS | PASS |
| ≥ 10 lines/s | PASS (36/s) | PASS (81/s) |
| Within 5–10% of Chrome | FAIL (50% slower) | **BEATS Chrome** |
| Plan class if WASM-only | VIABLE, Chrome faster | — |
| Recommended production engine | fallback only | **primary** |

Chrome Translator API must **not** be the production engine: it is not available in CastLabs ECS.

---

## 6. Question A and C status — BLOCKED ON OPERATOR LOGIN

Per operator instruction, work stopped when authentication was required.

| Service | Status |
| --- | --- |
| Netflix | **Not run — login required** |
| Prime Video | **Not run — login required** |
| Max | **Not run — login required** |
| YouTube control | Page loaded in ECS; `<video>` existed; `paused=true`, `readyState=0`, `videoWidth=0`. Needs a user gesture to play, not a login. Not a DRM proof. |

Widevine `components.whenReady()` is wired for harness/streaming modes and skipped for mozilla-bench.

**Question A is NOT answered.** Do not declare CastLabs ECS viable for Netflix/Prime/Max until the physical-console checklist in `PLAN.md` is filled.

**Question C is NOT answered.** Playback+translation harness exists (`src/translation/mozilla/playback.html`) but was not run against DRM titles.

Resume command after the operator is at the physical PC:

```powershell
pwsh -File D:\Users\steve\performance-test\scripts\run-streaming-tests.ps1
```

Then log in, play ~2 minutes per service, save the harness checklist to `results/streaming.json`, then run playback+translation (synthetic subtitles, do not scrape site captions yet).

---

## 7. Architecture decision from *completed* work

### Translation architecture: VALIDATED, with a constraint

Use **native Bergamot C++ as a separate process** (or native library loaded by a process that is not the streaming renderer).

Do not put inference on the Netflix/Prime/Max renderer thread. WASM-in-ECS is a useful fallback and was the Firefox-shaped prototype, but it is the slow path on Chromium because `mozIntGemm` does not exist there.

Models: **keep Firefox Remote Settings released models.** Native and WASM load the identical files:

```text
artifacts/mozilla/models/es-en/
  model.esen.intgemm.alphas.bin
  vocab.esen.spm
  lex.50.50.esen.s2t.bin
```

Config that matches Firefox:

- `gemm-precision: int8shiftAlphaAll` for `*.intgemm.alphas.bin`
- `beam-size: 1`
- `skip-cost: true`
- `cacheSize: 0` for live subtitles (or a small cache if product wants it; the spike disabled cache to avoid distorting latency)

Lifecycle: load only the active pair (`es→en` while watching Spanish). Unload on language switch. Do not keep every model resident.

### Browser / DRM architecture: UNPROVEN

ECS is correctly pinned and the harness is honest (no DRM hacks). Proof of Netflix/Prime/Max still requires the operator.

Until A is green, do **not** spend time on CEF/Tauri/WebView2. That was the plan’s stop condition in the other direction as well.

---

## 8. Windows native build landmines (reviewer should not relearn these)

1. CMake 4.x rejects old `cmake_minimum_required(< 3.5)` in sentencepiece/pcre2. Workaround: `-DCMAKE_POLICY_VERSION_MINIMUM=3.5`.
2. Internal PCRE2 ExternalProject on MSVC defaulted to **Debug `/MD`** while Bergamot is **Release `/MT`**. That produced `pcre2-8-staticd.lib` and CRT mismatch. Rebuild PCRE2 with Ninja, `CMAKE_BUILD_TYPE=Release`, `CMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded`. Ninja install name is `pcre2-8-static.lib`; the ssplit link line expects `lib/pcre2-8.lib`.
3. ssplit must be compiled with `PCRE2_STATIC` or you get `__imp_pcre2_*` unresolveds.
4. Without MKL/OpenBLAS, native Marian **aborts** at first translate: `Marian must be compiled with a BLAS library` in `prod_blas.h`. The spike enabled `USE_ONNX_SGEMM` via `USE_WASM_COMPATIBLE_SOURCE=ON` so leftover float32 GEMM has an implementation. **intgemm remains native AVX2.** Production Windows should prefer OpenBLAS or oneMKL for that leftover SGEMM; macOS should use Accelerate. This may beat the already-winning 28 ms p95 slightly. It is not required to beat Chrome.
5. `BlockingService` crashed on first `translateMultiple` in this MSVC build. `AsyncService` (same API as `app/bergamot.cpp`) is the working native API. The KMP/C wrapper should use **AsyncService** (or a mutexed single worker) until BlockingService is proven on both OS toolchains.
6. Official CLI flag is `--model-config-paths`, not `--model`.

---

## 9. How to reproduce

From `D:\Users\steve\performance-test`:

```powershell
npm test
npm run mozilla-bench          # WASM inside ECS
npm run chrome-bench           # installed Chrome
npm run native-bench           # C++ process, same models
npm run summarize
```

Native rebuild (already compiled on this machine):

```powershell
# VS 2022 x64 + Ninja
# native/bergamot-translator/build-native
# target: native-bench
```

Models are **not** in git. Re-fetch:

```powershell
node scripts/fetch-mozilla-models.cjs
```

---

## 10. Intended next project: KMP native library

### 10.1 Goal (owner)

Write a **Kotlin Multiplatform** library that exposes **exact bindings / interop** to native Bergamot for **Windows and macOS**, so the desktop app can call translation from Kotlin rather than from a WASM worker in Chromium.

This matches the measured winner (native C++) and the process isolation diagram.

### 10.2 What “exact binding” should mean

Do **not** cinterop/JNI Bergamot C++ types (`AsyncService`, `TranslationModel`, `std::shared_ptr`, exceptions, STL strings) directly.

Bergamot is C++. Kotlin/Native cinterop and JNI both want a **stable C ABI**.

Recommended layers:

```
Kotlin common API
  expect class Translator
        │
        ▼
actual (windows / macos)
  Kotlin/Native cinterop  OR  JVM JNI/JNA
        │
        ▼
liblanguageos_bergamot_c   (thin extern "C" wrapper YOU own)
        │
        ▼
bergamot-translator C++    (upstream, unmodified if possible)
  AsyncService + TranslationModel
  Firefox intgemm models
```

### 10.3 Suggested C ABI (keep it small)

This is the protocol the WASM worker already used, minus WASM:

```c
typedef struct LoTranslator LoTranslator;

typedef struct LoTranslateResult {
  char* text;          /* UTF-8, malloc'd; caller frees with lo_string_free */
  double inference_ms;
  int32_t error;       /* 0 ok */
} LoTranslateResult;

LoTranslator* lo_translator_create(
    const char* source_lang,   /* "es" */
    const char* target_lang,   /* "en" */
    const char* model_path,
    const char* vocab_path,
    const char* shortlist_path,
    double* initialization_ms,
    char** error_message);

int32_t lo_translator_translate(
    LoTranslator* t,
    const char* utf8_text,
    LoTranslateResult* out);

void lo_translator_unload(LoTranslator* t);
void lo_string_free(char* s);
```

Optional later, not in v1: batch translate, pivot (`es→en→fr`), HTML mode, quality scores, multiple loaded pairs.

v1 rules:

- One loaded pair per translator instance
- `cacheSize = 0` (or explicit opt-in)
- `numWorkers = 1` unless a benchmark shows a win **and** does not add tail latency
- UTF-8 only
- No exceptions across the ABI
- Caller owns paths; library does not download models
- Hash verification stays in Kotlin or a provisioner, not inside Marian

### 10.4 KMP module shape

Suggested Gradle:

```text
:bergamot-c          // CMake / prefab / native build of the C wrapper + Bergamot
:bergamot-kmp
    commonMain       // Translator, LanguagePair, ModelFiles, TranslateResult
    mingwX64Main     // Windows Kotlin/Native
    macosArm64Main   // Apple Silicon
    macosX64Main     // Intel Mac if required
    jvmMain          // optional JNI, if ECS/Compose JVM host is used
```

**Critical product decision for the reviewer:** this desktop app currently uses **CastLabs ECS (Chromium)** for DRM. Kotlin/Native `.klib`/`.dll` cannot be loaded inside the Netflix renderer, and should not be.

So the KMP library is the **translation core**, consumed by:

1. A small **native helper process** spawned from ECS (stdin/stdout or named pipe JSON), **or**
2. A future Compose Multiplatform / non-Electron shell, **or**
3. Later Android (same models; Bergamot already has Android precedent)

If ECS remains the DRM shell, **do not** design the Kotlin API as “call translate() on the UI/renderer thread.” Design it as:

```kotlin
interface SubtitleTranslator {
    suspend fun translate(text: String): TranslateResult
    fun unload()
}
```

with the actual implementation talking to the native engine on a dedicated thread/process.

### 10.5 Windows vs macOS actuals

| | Windows | macOS |
| --- | --- | --- |
| Compiler | MSVC 2022 x64, `/arch:AVX2`, `/MT` | Apple Clang, arm64 (and x64 if needed) |
| intgemm | native AVX2 (Ryzen/Intel) | NEON / Apple Silicon path in Marian (`USE_RUY` / ARM defs) |
| leftover SGEMM | OpenBLAS or oneMKL preferred; onnxjs is the proven fallback from this spike | **Accelerate** |
| PCRE2 | static, `PCRE2_STATIC`, `/MT` | static or system |
| Artifact | `languageos_bergamot.dll` + models | `liblanguageos_bergamot.dylib` + models |
| Kotlin/Native target | `mingwX64` | `macosArm64` |

Kotlin/Native `mingwX64` + MSVC-built C++ is a known pain (LLVM vs MSVC CRT, exception personality, `/MT` vs ucrt). **Safer host for Windows desktop KMP is JVM + JNI** if the rest of the Kotlin code is already JVM. **Safer for a pure native sidecar** is: keep the helper 100% C++, and have Kotlin talk over IPC. That still gives a KMP API (`expect` IPC client) without linking MSVC C++ into the Kotlin/Native compiler.

This is the most important design fork. See §11.

### 10.6 Models in the KMP library

The library should **not** embed 35 MB models.

API:

```kotlin
data class BergamotModelPack(
    val pair: LanguagePair,          // es-en
    val model: Path,
    val vocab: Path,
    val shortlist: Path,
    val gemmPrecision: GemmPrecision // Int8ShiftAlphaAll vs Int8ShiftAll
)
```

Provisioning (download, sha256, cache) can be a second KMP module that already matches `scripts/fetch-mozilla-models.cjs` / Remote Settings. Firefox Remote Settings is the source of truth for “released to Firefox.”

### 10.7 Tests the KMP library must copy from this spike

Reuse `src/translation/common/corpus.json`.

Must-have:

- Load es-en, warmup 20, sequential 500
- p95 on this class of hardware should stay in the same ballpark as **28 ms**, not regress to WASM 62 ms (that would mean you accidentally shipped the WASM GEMM or a debug/non-AVX build)
- Round-trip sanity: non-empty, not identical to Spanish for obvious sentences
- Unload then load `en-es` without leaking the previous model
- Two threads must not share one `LoTranslator` unless the C layer documents a lock
- Windows and macOS CI on Release, not Debug

Do not block on COMET/BLEU. Latency + “not gibberish” was the spike rule.

### 10.8 Licensing for a shipped KMP wrapper

MPL 2.0 on Bergamot and on the model files. Shipping a closed-source Kotlin app that **dynamically links** unmodified Bergamot is a normal MPL larger-work pattern, but:

- Record exact Bergamot git revision
- Ship license files and third-party notices
- If you patch Marian/Bergamot, those patched files remain MPL and source must be available
- Prefer the C wrapper and Kotlin to stay **outside** Bergamot’s source tree so they can be Apache-2.0 / company license

---

## 11. Assessment of the Kotlin library (author of this spike)

This is an opinion for GPT-Pro to stress-test, not a mandate.

### 11.1 The library is the right next step — with a narrow job

Native Bergamot is the performance winner and uses the models we already trust. A KMP façade is justified **if** Kotlin is the language of the rest of the desktop app (or will be). It is not justified as a way to get Kotlin into the ECS renderer.

The hard piece is **not** Kotlin `expect/actual`. The hard piece is a **boring C ABI + two native builds (MSVC and Apple Clang)** that stay fast.

### 11.2 Do not bind C++ from Kotlin/Native

cinterop of `translator/service.h` will fail in practice (templates, `std::shared_ptr`, exceptions, `std::string`, operator overloading, MSVC vs LLVM). Every successful Bergamot embed (Python pybind, Firefox WASM bindings, this spike’s `native-bench.cpp`) uses a **dedicated glue layer**. For KMP, that glue must be C, not C++.

### 11.3 Prefer a process boundary on Windows if ECS stays

If DRM remains CastLabs ECS:

**Best:** `electron/ecs` spawns `languageos-translate.exe` (C++ or a tiny K/N binary) and speaks newline JSON. Kotlin KMP can still own the client protocol and later the non-Electron UI.

**Acceptable:** Kotlin/JVM JNI into `languageos_bergamot.dll` inside a **utility process**, not in the streaming `BrowserWindow`.

**Avoid:** loading the DLL into the Netflix renderer, or Kotlin/Native `mingwX64` linking MSVC Bergamot in v1. That combination is where weeks disappear.

macOS Kotlin/Native `macosArm64` + Clang-built dylib is much more conventional if the Mac shell is Compose Multiplatform / K/N.

### 11.4 One API, two runtimes, same models

Keep WASM **out** of the KMP library. One engine: native Bergamot. WASM was a spike to mimic Firefox-in-Chromium. Production on desktop should not carry two inference stacks.

### 11.5 Match Firefox’s operational model, not Firefox’s process internals

Firefox uses WASM + `mozIntGemm` inside Gecko. You are not Gecko. You should copy:

- released model files and hashes
- `int8shiftAlphaAll`
- beam 1
- isolate inference from the page
- one pair loaded at a time

You should **not** copy:

- Remote Settings inside Firefox
- `mozIntGemm`
- Bergamot on the streaming renderer

### 11.6 Performance budget for the Kotlin layer

Native p95 is 28 ms. The Kotlin/IPC layer must not add tens of milliseconds.

Budget:

- C++ inference: ~10–30 ms (already measured)
- ABI / JNI / pipe: **< 2 ms** for subtitle-sized strings
- Total warm p95 still **< 50 ms** so it stays faster than Chrome’s 41 ms

If IPC serialization of a 40-character subtitle costs more than 1–2 ms, the design is wrong (you are probably launching a new process per line). **Keep a warm process.**

### 11.7 Suggested implementation order for the KMP repo

1. Freeze a C ABI and a golden `es-en` fixture from this spike’s model files.
2. Implement `lo_translator_*` in C++ against `AsyncService` on Windows; repeat the 500-line bench; **must match ~10/28 ms class**.
3. Repeat on macOS arm64.
4. Kotlin common API + one actual (start with the easier host: JVM JNI on Windows **or** K/N on macOS, not both at once).
5. Only then expect/actual the second OS.
6. ECS integration is a **client** of that library/process, after Question A is green.

### 11.8 Risks GPT-Pro should explicitly accept or reject

| Risk | Why it matters |
| --- | --- |
| Kotlin/Native + MSVC C++ | High. Many KMP desktop apps dodge this with JVM or a C helper. |
| BlockingService vs AsyncService | This spike: only AsyncService worked on MSVC. Bind that. |
| No BLAS on Windows | Native aborted until onnxjs SGEMM. Production should pick OpenBLAS/MKL vs onnxjs deliberately. |
| Model/engine version skew | Bind a **pinned Bergamot git SHA** to Firefox-released model schema. |
| ECS still unproven | Do not build Kotlin DRM integration. Translation lib can proceed in parallel. |
| Over-wrapping | Do not expose Marian graphs, HTML alignment, pivoting, or quality models in v1. |
| Cache | Translation cache can lie in benchmarks and can return stale lines if language switches. Default off. |

### 11.9 What I would not do

- Wrap the WASM module in Kotlin/JS “because Firefox does that.”
- Depend on Chrome `Translator` in the KMP library.
- Train or convert models to ONNX/GGUF/CTranslate2 before native Bergamot is in-process and green on Mac.
- Put the 500-string bench only in JS. Port it to the C/KMP layer so regressions cannot hide behind Electron.

---

## 12. File index for the reviewer

| Path | Why |
| --- | --- |
| `PLAN.md` | Original acceptance spec |
| `README.md` | Operator instructions |
| `results/FINAL_REPORT.md` | Generated scoreboard |
| `results/mozilla-translation.json` | WASM bench (large; samples included) |
| `results/chrome-translation.json` | Chrome bench |
| `results/native-bergamot-translation.json` | Native C++ bench |
| `results/machine.json` | Host inventory |
| `results/streaming.json` | DRM checklist (incomplete) |
| `src/ecs/` | CastLabs harness |
| `src/translation/` | WASM + Chrome benches, corpus |
| `native/native-bench.cpp` | Native sequential bench source |
| `native/bergamot-translator/` | Upstream clone + Windows build (gitignored) |
| `artifacts/mozilla/` | WASM, JS, models (gitignored binaries) |
| `test/` | 27 unit tests |

---

## 13. One-paragraph verdict

Mozilla **native** Bergamot, running as C++ on the same Firefox models, is fast enough for dual subtitles and **faster than Chrome’s on-device Translator** on this PC (p95 28 ms vs 41 ms vs WASM 62 ms). The desktop app should treat translation as a **native library/process**, not as WASM inside ECS. A KMP library is a good product wrapper **if it is a thin C ABI + Kotlin API**, not a direct C++ cinterop, and **if it never runs inside the DRM renderer**. CastLabs ECS still has to prove Netflix/Prime/Max on a physical console after login; that work is orthogonal and currently blocked on the operator.

---

## 14. Direct asks for GPT-Pro

Please review this handoff and return:

1. Agreement or dissent that **native Bergamot + Firefox models** is the translation architecture.
2. A recommended KMP interop strategy for **Windows and macOS** (JNI vs cinterop vs IPC sidecar), with a single primary recommendation.
3. A C ABI sketch no larger than v1 in §10.3, or a justified alternative.
4. Build matrix (MSVC/Clang, BLAS/Accelerate, intgemm) that will not regress the 28 ms p95 class.
5. What must wait until ECS DRM login is green, vs what can be built now.
6. Red flags if the owner starts generating Kotlin `external` bindings against `service.h`.
