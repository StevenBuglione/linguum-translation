CURRENT FIREFOX NATIVE vs FIREFOX WASM — first 50 differences

exact matches: 480 / 500 (96%)
different: 20 / 500

Do not treat non-100% equality as an automatic failure. AsyncService and BlockingService may differ.

## 1

source:
Escúchame bien, Daniel: si no salimos de Sevilla después del almuerzo, no vamos a contar esto mañana.

WASM:
Listen to me, Daniel: if we don’t leave Seville after lunch, we won’t tell this tomorrow.

native:
Listen to me, Daniel: if we don’t leave Seville after lunch, we’re not going to tell this tomorrow.

## 2

source:
No voy a repetirlo otra vez, María: tenemos que esperar antes de llegar a Madrid, porque en cinco minutos ya va a ser demasiado tarde para deshacer lo que hicimos anoche.

WASM:
I will not repeat it again, Maria: we have to wait before we arrive in Madrid, because in five minutes it will be too late to undo what we did last night.

native:
I will not repeat it again, Maria: we have to wait before arriving in Madrid, because in five minutes it will be too late to undo what we did last night.

## 3

source:
Escúchame bien, María: si no salimos de el hospital el 12 de junio, no vamos a contar esto mañana.

WASM:
Listen to me, Maria: if we don't leave the hospital on June 12, we're not going to tell this tomorrow.

native:
Listen to me, Maria: If we don't leave the hospital on June 12, we're not going to tell this tomorrow.

## 4

source:
Escúchame bien, Daniel: si no salimos de Valencia mañana temprano, no vamos a contar esto mañana.

WASM:
Listen to me, Daniel: if we don't leave Valencia tomorrow morning, we're not going to tell this tomorrow.

native:
Listen to me, Daniel: if we don't leave Valencia early tomorrow, we're not going to tell this tomorrow.

## 5

source:
Escúchame bien, María: si no salimos de el aeropuerto en 2019, no vamos a contar esto mañana.

WASM:
Listen to me, Maria: if we don’t leave the airport in 2019, we’re not going to tell this tomorrow.

native:
Listen to me, Maria: if we don’t leave the airport in 2019, we won’t tell this tomorrow.

## 6

source:
Escúchame bien, María: si no salimos de Valencia en 2019, no vamos a contar esto mañana.

WASM:
Listen to me, Maria: if we don’t leave Valencia in 2019, we won’t tell this tomorrow.

native:
Listen to me, Maria: if we don’t leave Valencia in 2019, we’re not going to tell this tomorrow.

## 7

source:
Escúchame bien, María: si no salimos de Sevilla ahora mismo, no vamos a contar esto mañana.

WASM:
Listen to me, Maria: if we don’t leave Seville right now, we’re not going to tell this tomorrow.

native:
Listen to me, Maria: if we don't leave Seville right now, we're not going to tell this tomorrow.

## 8

source:
Escúchame bien, Daniel: si no salimos de Sevilla ahora mismo, no vamos a contar esto mañana.

WASM:
Listen to me, Daniel: if we don't leave Seville right now, we're not going to tell this tomorrow.

native:
Listen to me, Daniel: if we don’t leave Seville right now, we’re not going to tell this tomorrow.

## 9

source:
Escúchame bien, Daniel: si no salimos de Bilbao el viernes, no vamos a contar esto mañana.

WASM:
Listen to me, Daniel: if we don’t leave Bilbao on Friday, we’re not going to tell this tomorrow.

native:
Listen to me, Daniel: if we don't leave Bilbao on Friday, we're not going to tell this tomorrow.

## 10

source:
Escúchame bien, María: si no salimos de Valencia mañana temprano, no vamos a contar esto mañana.

WASM:
Listen to me, Maria: if we don't leave Valencia early tomorrow, we're not going to tell this tomorrow.

native:
Listen to me, Maria: if we don't leave Valencia tomorrow morning, we're not going to tell this tomorrow.

## 11

source:
No voy a repetirlo otra vez, María: tenemos que confiar en mí antes de llegar a Madrid, porque mañana temprano ya va a ser demasiado tarde para deshacer lo que hicimos anoche.

WASM:
I’m not going to repeat it again, Maria: we have to trust me before we get to Madrid, because tomorrow morning it’s going to be too late to undo what we did last night.

native:
I’m not going to repeat it again, Maria: we have to trust me before we arrive in Madrid, because tomorrow morning it’s going to be too late to undo what we did last night.

## 12

source:
Escúchame bien, María: si no salimos de Barcelona a las tres, no vamos a contar esto mañana.

WASM:
Listen to me, Maria: if we don't leave Barcelona at three, we're not going to tell this tomorrow.

native:
Listen to me, Maria: if we don’t leave Barcelona at three, we’re not going to tell this tomorrow.

## 13

source:
Escúchame bien, María: si no salimos de Valencia el viernes, no vamos a contar esto mañana.

WASM:
Listen to me, Maria: if we don't leave Valencia on Friday, we're not going to tell this tomorrow.

native:
Listen to me, Maria: if we don’t leave Valencia on Friday, we’re not going to tell this tomorrow.

## 14

source:
Escúchame bien, María: si no salimos de el aeropuerto ahora mismo, no vamos a contar esto mañana.

WASM:
Listen to me, Maria: if we don't leave the airport right now, we're not going to tell this tomorrow.

native:
Listen to me, Maria: if we don't leave the airport right now, we're not going to count this tomorrow.

## 15

source:
Escúchame bien, María: si no salimos de la estación mañana temprano, no vamos a contar esto mañana.

WASM:
Listen to me, Maria: if we don't leave the station early morning, we're not going to tell this tomorrow.

native:
Listen to me, Maria: if we don't leave the season early, we won't tell this tomorrow.

## 16

source:
Escúchame bien, María: si no salimos de Bilbao mañana temprano, no vamos a contar esto mañana.

WASM:
Listen to me, Maria: if we don't leave Bilbao early tomorrow, we're not going to tell this tomorrow.

native:
Listen to me, Maria: if we don’t leave Bilbao early tomorrow, we’re not going to tell this tomorrow.

## 17

source:
Escúchame bien, María: si no salimos de Barcelona después del almuerzo, no vamos a contar esto mañana.

WASM:
Listen to me, Maria: if we don’t leave Barcelona after lunch, we won’t tell this tomorrow.

native:
Listen to me, Maria: if we don’t leave Barcelona after lunch, we’re not going to tell this tomorrow.

## 18

source:
No voy a repetirlo otra vez, María: tenemos que esperar antes de llegar a Madrid, porque el viernes ya va a ser demasiado tarde para deshacer lo que hicimos anoche.

WASM:
I will not repeat it again, Maria: we have to wait before we arrive in Madrid, because Friday is already going to be too late to undo what we did last night.

native:
I will not repeat it again, Maria: we have to wait before arriving in Madrid, because Friday is already going to be too late to undo what we did last night.

## 19

source:
Escúchame bien, María: si no salimos de Sevilla el 12 de junio, no vamos a contar esto mañana.

WASM:
Listen to me, Maria: if we don’t leave Seville on June 12, we’re not going to tell this tomorrow.

native:
Listen to me, Maria: if we don't leave Seville on June 12, we're not going to tell this tomorrow.

## 20

source:
Escúchame bien, María: si no salimos de Valencia en cinco minutos, no vamos a contar esto mañana.

WASM:
Listen to me, Maria: if we don't leave Valencia in five minutes, we're not going to count this tomorrow.

native:
Listen to me, Maria: if we don't leave Valencia in five minutes, we're not going to tell this tomorrow.

