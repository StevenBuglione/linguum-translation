TRANSLATION PERFORMANCE VALIDATION

Rounds completed: 6 / 6
Samples per engine per round: 500
Total measured samples per engine: 3000
Warmup per engine per run: 20
Warmup overlap with corpus: 0
Corpus order: deterministic and paired per round
Chrome model pre-downloaded: YES
Caches:
  WASM Bergamot: 0
  Native Bergamot: 0

Machine
──────────────────────────
CPU: AMD Ryzen 9 5900X 12-Core Processor
RAM: 127.93 GB
Windows: Windows 11 Pro (10.0.26100)
GPU: NVIDIA GeForce RTX 3070
Chrome version: Google Chrome 151


                         Chrome       WASM       Native

Median run p50              15.80      21.65      10.13
Median run p95              44.31      64.73      28.07
Median run p99              48.05      69.05      30.35

Mean run p50                15.78      21.57      10.12
Mean run p95                44.40      64.82      28.20
Mean run p99                48.00      69.24      30.40

p95 stddev                   0.77       0.58       0.55

Pooled p50                  15.80      21.60      10.12
Pooled p95                  44.60      65.30      28.13
Pooled p99                  48.20      69.20      30.36

Median TPS                  49.35      34.83      79.91
Median words/sec           566.59     399.82     917.41


NATIVE VS CHROME

p50 wins: 6/6
p95 wins: 6/6
p99 wins: 6/6

median p50 ratio: 0.64
median p95 ratio: 0.64
median p99 ratio: 0.63
mean p95 ratio: 0.64
min p95 ratio: 0.62
max p95 ratio: 0.65


WASM VS CHROME

p50 wins: 0/6
p95 wins: 0/6
p99 wins: 0/6
median p95 ratio: 1.45


BUCKET p95 (median across rounds)

| Bucket | Chrome p95 | WASM p95 | Native p95 |
| ------ | ---------: | -------: | ---------: |
| Tiny   | 9.25 | 10.60 | 5.13 |
| Short  | 17.51 | 23.75 | 11.12 |
| Medium | 34.69 | 45.75 | 19.75 |
| Long   | 48.83 | 70.17 | 30.81 |


INDIVIDUAL ROUNDS

Round 1
Chrome p50/p95/p99/TPS: 16.05 / 45.11 / 48.80 / 48.20
WASM   p50/p95/p99/TPS: 21.65 / 65.51 / 69.20 / 34.83
Native p50/p95/p99/TPS: 10.09 / 29.19 / 31.40 / 78.99
native/Chrome p95 ratio: 0.65

Round 2
Chrome p50/p95/p99/TPS: 15.95 / 45.43 / 49.20 / 48.17
WASM   p50/p95/p99/TPS: 21.35 / 64.42 / 68.80 / 35.13
Native p50/p95/p99/TPS: 10.01 / 28.15 / 30.65 / 80.45
native/Chrome p95 ratio: 0.62

Round 3
Chrome p50/p95/p99/TPS: 15.60 / 44.12 / 47.50 / 49.57
WASM   p50/p95/p99/TPS: 21.30 / 64.31 / 68.40 / 35.14
Native p50/p95/p99/TPS: 10.21 / 27.98 / 29.70 / 79.61
native/Chrome p95 ratio: 0.63

Round 4
Chrome p50/p95/p99/TPS: 15.50 / 43.50 / 46.90 / 49.74
WASM   p50/p95/p99/TPS: 21.65 / 65.41 / 68.91 / 34.82
Native p50/p95/p99/TPS: 10.11 / 28.40 / 30.81 / 78.93
native/Chrome p95 ratio: 0.65

Round 5
Chrome p50/p95/p99/TPS: 15.90 / 44.50 / 48.60 / 49.14
WASM   p50/p95/p99/TPS: 21.80 / 64.22 / 70.00 / 34.77
Native p50/p95/p99/TPS: 10.14 / 27.65 / 30.06 / 80.22
native/Chrome p95 ratio: 0.62

Round 6
Chrome p50/p95/p99/TPS: 15.70 / 43.71 / 47.00 / 49.58
WASM   p50/p95/p99/TPS: 21.65 / 65.04 / 70.10 / 34.66
Native p50/p95/p99/TPS: 10.15 / 27.80 / 29.79 / 80.23
native/Chrome p95 ratio: 0.64


STARTUP — INFORMATIONAL

Do not use these values to pick the architecture winner. Warm subtitle latency is the gate.

                         Chrome       WASM       Native
Median engineSetupMs        81.95     364.80      61.64
Median firstTranslation     32.70     170.60      99.84

Memory figures (JS heap / native working set) are informational only and are not compared across engines.


ABSOLUTE SUBTITLE GATE

Native p95 <= 150ms: PASS
Native p99 <= 250ms: PASS
Native >= 10 translations/sec: PASS

WASM p95 <= 150ms: PASS
WASM p99 <= 250ms: PASS


DECISION

NATIVE BERGAMOT: FASTER THAN CHROME
MOZILLA WASM: VIABLE

KOTLIN INTEGRATION: DO NOT START automatically. Return these results for architectural review first.
