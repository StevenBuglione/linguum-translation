# FINAL_REPORT

WINDOWS ARCHITECTURE SPIKE

Host
──────────────────────────
Windows 11: PASS
Physical local session: YES
RDP: DISCONNECTED
CPU: AMD Ryzen 9 5900X 12-Core Processor
RAM: 127.93 GB
GPU: NVIDIA GeForce RTX 3070
GPU driver: 32.0.16.1088
Display: 2560x1440 @ 59 Hz


CastLabs ECS
──────────────────────────
Version: 43.2.0+wvcus (pinned)
Chromium: 
Node: 23.8.0
Widevine: see ECS run

Netflix: NOT RUN (login required)
Prime:   NOT RUN (login required)
Max:     NOT RUN (login required)
YouTube control: INCOMPLETE (waiting for login or user gesture)

UA spoof:             NO
Browser flags:        NO
DRM workaround:       NO
Custom codecs:        NO
Custom Chromium:      NO


Translation
──────────────────────────
Pair: Spanish → English

Chrome Translator API

p50: 14.60
p95: 40.72
p99: 44.20
translations/sec: 53.04


Mozilla Firefox Translations / Bergamot WASM

p50: 21.90
p95: 61.92
p99: 66.30
translations/sec: 35.73


Mozilla Bergamot native C++

p50: 9.63
p95: 27.63
p99: 29.58
translations/sec: 80.96


Mozilla vs Chrome
──────────────────────────
WASM p50 ratio vs Chrome: 1.50
WASM p95 ratio vs Chrome: 1.52
Native p50 ratio vs Chrome: 0.66
Native p95 ratio vs Chrome: 0.68
Native vs WASM p95: 0.45

Winner (WASM vs Chrome):
CHROME

Winner including native C++:
NATIVE MOZILLA BERGAMOT

STRICT_WIN: NO
Throughput >= 10/sec: YES


Streaming + Mozilla
──────────────────────────
Netflix: NOT RUN (login required)
Prime: NOT RUN (login required)
Max: NOT RUN (login required)

Translation p95 while playing: 
Dropped-frame impact: 
Audio impact: 
DRM impact: 


FINAL DECISION
──────────────────────────

CASTLABS ECS:
SEE SERVICE LINES ABOVE

MOZILLA TRANSLATION:
VIABLE

OVERALL DESKTOP ARCHITECTURE:
PENDING STREAMING GATES

## Comparison table

| Metric              | WASM Bergamot | Native C++ Bergamot | Chrome Translator |
| ------------------- | ------------: | ------------------: | ----------------: |
| Warm p50            | 21.90 ms | 9.63 ms | 14.60 ms |
| Warm p95            | 61.92 ms | 27.63 ms | 40.72 ms |
| Warm p99            | 66.30 ms | 29.58 ms | 44.20 ms |
| translations/sec    | 35.73 | 80.96 | 53.04 |
| words/sec           | 410.13 | 929.37 | 608.86 |
| cold initialization | 70.70 | 84.25 | 240.30 |

## Playback table

| Mozilla under video  | Netflix | Prime | Max |
| -------------------- | ------: | ----: | --: |
| p50                  |  |  |  |
| p95                  |  |  |  |
| p99                  |  |  |  |
| Video remains smooth |  |  |  |
| Audio remains smooth |  |  |  |
| DRM remains active   |  |  |  |
