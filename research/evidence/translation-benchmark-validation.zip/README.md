# Windows ECS + Firefox Translation Architecture Spike

This repository answers only the architecture questions in `PLAN.md`:

- **Question A:** Can official CastLabs ECS play Netflix, Prime Video, and Max on a local Windows 11 session with no RDP, UA spoof, flags, or DRM hacks?
- **Question B:** Can Mozilla Firefox Translations / Bergamot translate subtitle-sized text locally at latency comparable to Chrome's on-device Translator API?
- **Question C:** Can Mozilla translation run concurrently with DRM video without materially harming playback or translation latency?

Package name: `language-os-desktop-architecture-spike`.

## Hard non-goals

This spike does **not** implement subtitle extraction, site plugins, dual-caption UI, an AI tutor, Kotlin/KMP, password import, or production auth.

## Environment

Run acceptance tests on the physical Windows PC:

- Windows 11 x64, GPU drivers current, hardware acceleration on
- Local console session (`SESSIONNAME=Console`)
- No RDP / Parsec / AnyDesk / VM / virtual display

Pinned ECS: **CastLabs Electron 43.2.0+wvcus**.

## Setup

```powershell
pwsh -File scripts/prepare-ecs.ps1
pwsh -File scripts/fetch-mozilla-models.ps1
npm test
```

`fetch-mozilla-models` queries Mozilla Remote Settings for the **released Firefox** `es→en` and `en→es` models, verifies SHA-256, and downloads:

- Current Firefox in-tree `bergamot-translator.js`
- Firefox CI Bergamot WASM v4.0 (matches that JS glue; SIMD/intgemm)

Model download time is a provisioning metric, not inference latency.

## Tests

```powershell
npm test
```

Unit tests cover statistics, corpus shape, result schema, model registry selection, ECS service matrix, and benchmark orchestration.

## Translation benches

Mozilla runs **inside ECS** (the production candidate). Chrome runs in **installed Google Chrome**, not ECS.

```powershell
pwsh -File scripts/run-mozilla-bench.ps1
pwsh -File scripts/run-chrome-bench.ps1
pwsh -File scripts/summarize-results.ps1
```

Interleaved rounds (Mozilla, Chrome, Chrome, Mozilla, Mozilla, Chrome):

```powershell
pwsh -File scripts/run-translation-rounds.ps1
```

Gates for subtitle-sized inputs:

- Mozilla p95 ≤ 150 ms, p99 ≤ 250 ms
- Mozilla p50 ≤ Chrome p50 × 1.05 and p95 ≤ Chrome p95 × 1.10, or faster
- Throughput ≥ 10 short subtitles / second

## Streaming (requires your login)

```powershell
pwsh -File scripts/run-streaming-tests.ps1
```

This opens official ECS with:

1. Netflix
2. Prime Video
3. Max
4. YouTube as control

No user-agent spoof, no `--disable-web-security`, no custom Widevine. Log in yourself, play a title, and fill the checklist in the harness. Playback + synthetic Mozilla subtitles is a separate window from the streaming renderer.

Stop here if a service asks you to authenticate; that is intentional.

## Results

| File | Contents |
| --- | --- |
| `results/machine.json` | Windows/CPU/RAM/GPU/session inventory |
| `results/streaming.json` | Manual DRM checklist |
| `results/mozilla-translation.json` | Bergamot benches |
| `results/chrome-translation.json` | Chrome Translator API benches |
| `results/playback-translation.json` | Translation while video plays |
| `results/FINAL_REPORT.md` | Architecture decision summary |

## Architecture isolation

```
ECS streaming renderer (Netflix / Prime / Max)
        │
        │ synthetic subtitle text (this spike)
        ↓
Translation worker (Bergamot WASM + Mozilla model)
        │
        ↓
translated text
```

Bergamot is not run on the streaming page's main thread.

## Licensing

Mozilla translation models and Bergamot are **MPL 2.0**. See `licenses/`. This spike does not modify Bergamot; it uses upstream Firefox artifacts.

Source availability for eventual distribution:

- Engine JS: Firefox `toolkit/components/translations/bergamot-translator/bergamot-translator.js`
- Engine WASM: Firefox CI `tr8ns.inference` / Remote Settings `translations-wasm`
- Models: Firefox Remote Settings `translations-models` records marked released to Firefox
