. I would now turn the spike into a **Windows architecture-validation repo** with exactly two hard gates:

1. **CastLabs ECS:** Prime Video, Netflix, and Max must all play protected video/audio correctly on the physical Windows PC with no RDP.
2. **Mozilla/Firefox Translations:** the Mozilla translation engine must be fast enough for real-time subtitles and operationally as fast as, or faster than, Chrome's on-device `Translator` API on the same PC.

If both pass, I would consider the two biggest architecture risks resolved.

A useful detail from the repo you linked: `mozilla/translations` is the training/model infrastructure behind Firefox Translations; Mozilla says its released models are public, compatible with Bergamot, and power Firefox's translation feature.  Current Firefox runs those models locally using **Bergamot compiled to WASM, powered by Marian**. ([Firefox Source Docs][1])

Below is the complete handoff I would give Grok.

---

# Windows ECS + Firefox Translation Architecture Spike

## 0. Purpose

Create a dedicated POC repository:

```text
language-os-desktop-architecture-spike
```

The repository answers only:

```text
QUESTION A

Can official CastLabs ECS reliably play:
- Netflix
- Prime Video
- Max

on a normal local Windows 11 desktop session
without:
- RDP
- DRM workarounds
- UA spoofing
- browser flags
- custom Chromium
- custom codecs?


QUESTION B

Can Mozilla Firefox Translations / Bergamot
translate subtitle-sized text locally
at latency comparable to or better than
Chrome's built-in on-device Translator API?


QUESTION C

Can Mozilla translation run concurrently with
DRM video playback without materially harming
video playback or translation latency?
```

If all three are GREEN:

```text
BROWSER / DRM ARCHITECTURE = VIABLE
TRANSLATION ARCHITECTURE   = VIABLE
```

At that point stop framework research and move on to the actual application.

---

# 1. Hard non-goals

Do **not** implement yet:

```text
real subtitle extraction
Netflix plugin
Prime plugin
Max plugin
dual caption styling
AI tutor
vocabulary storage
Kotlin integration
KMP service
production UI
authentication
cloud hosting
browser tabs
password import
auto updater
```

The spike proves underlying capability only.

---

# 2. Required environment

Run all acceptance tests physically on the Windows machine.

Requirements:

```text
Windows 11
x64
current GPU driver
hardware acceleration enabled
local physical session

NO RDP
NO Windows Remote Desktop
NO Parsec
NO AnyDesk
NO screen sharing
NO VM
NO virtual display driver
```

If an external monitor is used, use a normal direct HDMI/DisplayPort connection.

Record:

```text
Windows version/build
CPU model
RAM
GPU model
GPU driver
display connection
display resolution
refresh rate

Chrome version
ECS version
Electron version
Chromium version
Widevine CDM version
Node version
```

For ECS, pin the current stable line you're already testing. CastLabs released `43.2.0+wvcus` on August 4, 2026, based on Electron 43.2.0 with Widevine support. ([GitHub][2])

---

# 3. Repository structure

Use:

```text
language-os-desktop-architecture-spike/
│
├── package.json
├── package-lock.json
├── README.md
│
├── src/
│   ├── ecs/
│   │   ├── main.cjs
│   │   ├── preload.cjs
│   │   ├── services.cjs
│   │   └── diagnostics.cjs
│   │
│   └── translation/
│       ├── common/
│       │   ├── corpus.json
│       │   ├── benchmark.js
│       │   ├── statistics.js
│       │   └── result-schema.json
│       │
│       ├── mozilla/
│       │   ├── index.html
│       │   ├── translation-worker.js
│       │   ├── model-loader.js
│       │   └── bergamot-adapter.js
│       │
│       └── chrome/
│           ├── index.html
│           └── chrome-translator-benchmark.js
│
├── artifacts/
│   └── mozilla/
│       ├── engine/
│       └── models/
│
├── scripts/
│   ├── prepare-ecs.ps1
│   ├── fetch-mozilla-models.ps1
│   ├── run-streaming-tests.ps1
│   ├── run-mozilla-bench.ps1
│   ├── run-chrome-bench.ps1
│   └── summarize-results.ps1
│
├── results/
│   ├── machine.json
│   ├── streaming.json
│   ├── chrome-translation.json
│   ├── mozilla-translation.json
│   ├── playback-translation.json
│   └── FINAL_REPORT.md
│
└── licenses/
    ├── mozilla-translations-MPL-2.0.txt
    └── bergamot-MPL-2.0.txt
```

---

# 4. Phase A — prove CastLabs ECS on Windows

Do this first.

If ECS cannot satisfy the three streaming services locally, don't waste time benchmarking translation.

CastLabs describes ECS as a drop-in Electron build with Widevine installed through its component updater; production VMP signing is handled through EVS. ([GitHub][3])

Use:

```javascript
const {
    app,
    BrowserWindow,
    components
} = require("electron");
```

Startup:

```javascript
app.whenReady().then(async () => {
    await components.whenReady([
        components.WIDEVINE_CDM_ID
    ]);

    createWindow();
});
```

Keep:

```javascript
nodeIntegration: false
contextIsolation: true
sandbox: true
webSecurity: true
```

Do not use:

```text
--disable-web-security
--no-sandbox
--ignore-certificate-errors
custom UA
custom Chrome flags
request rewriting
custom Widevine
Chrome Widevine copied into ECS
```

## Streaming test order

Run:

```text
1. Netflix
2. Prime Video
3. Max
4. YouTube as control
```

For each service manually verify:

```text
login
catalog
title page
player initialization
video
audio
2 minutes continuous playback
pause/resume
seek forward
seek backward
subtitles
audio-track switching where available
fullscreen
exit fullscreen
close ECS
restart ECS
session still authenticated
```

### Important

Your previous Mac testing was contaminated by remote-screen conditions.

For this Windows acceptance run:

```text
RDP disconnected
↓
physically use PC
↓
start ECS fresh
↓
run entire matrix
```

---

# 5. ECS streaming acceptance threshold

GREEN requires:

```text
Netflix:
video ✅
audio ✅
fullscreen ✅
subtitles ✅

Prime:
video ✅
audio ✅
fullscreen ✅
subtitles ✅

Max:
video ✅
audio ✅
fullscreen ✅
subtitles ✅
```

And:

```text
Widevine READY
no UA spoof
no browser flags
no request modification
no DRM bypass
no custom codec
no custom ECS
```

If that happens:

# Browser gate = PASS

Do not continue researching CEF/Tauri/WebView2.

---

# 6. Phase B — establish the Mozilla translation implementation

This part should **not use Firefox as an external browser process**.

We want to prove the engine we could actually put behind the desktop app.

The production candidate should be:

```text
Mozilla released models
        +
Bergamot
        +
Marian
        +
WASM
        +
Web Worker
```

running inside ECS/Chromium.

That is close to Firefox's own architecture: Firefox uses Bergamot WASM locally and runs inference separately from normal page content. ([Firefox Source Docs][1])

This is particularly attractive because our future architecture becomes:

```text
Streaming renderer
        │
        │ subtitle event
        ↓
Translation worker
        │
        ├── Bergamot WASM
        └── Mozilla model
        │
        ↓
translated text
```

The streaming renderer never performs inference itself.

---

# 7. Do NOT use the old archived Mozilla Bergamot mirror as source of truth

`mozilla/bergamot-translator` itself is archived.

Mozilla's current Firefox implementation is maintained **inside Firefox's source tree**, and Firefox's documentation points to:

```text
toolkit/components/translations/bergamot-translator
```

with:

```text
build-bergamot.py
```

as the current way Firefox builds its WASM engine. ([Firefox Source Docs][4])

Therefore Grok should use this priority:

```text
1. Current Firefox Release Bergamot artifact
   + current released Mozilla model

preferred

2. Build current Firefox in-tree Bergamot WASM

fallback

3. browsermt/bergamot-translator

only as development reference
```

The BrowserMT repo is still useful because its WASM example documents the actual low-level model-loading and `BlockingService.translate()` API.

---

# 8. Get the current Mozilla models dynamically

Do **not** hard-code some old `firefox-translations-models` release.

The repository you provided says current trained models are hosted publicly and distributed under MPL 2.0.

Grok should query Mozilla's current model registry and select the model marked as **released to Firefox**.

Start with:

```text
es → en
```

because that's the most important initial dual-subtitle use case.

Then:

```text
en → es
```

After the initial architecture gate, optionally add:

```text
fr → en
de → en
it → en
pt → en
```

Don't make the first spike bigger than necessary.

---

# 9. Mozilla model integrity

When downloading:

```text
model
shortlist
vocabulary
configuration
```

record:

```json
{
  "languagePair": "es-en",
  "modelVersion": "...",
  "source": "Mozilla released Firefox model",
  "sha256": "...",
  "modelBytes": 0,
  "downloadedAt": "..."
}
```

Verify hashes before loading.

Cache them locally.

Model download time **must not be included in inference benchmarks**.

Model download is a one-time provisioning metric, not subtitle latency.

---

# 10. Build the Mozilla translation worker

Run Bergamot in a dedicated Web Worker.

Conceptually:

```javascript
const worker = new Worker(
    "./translation-worker.js",
    { type: "module" }
);
```

Protocol:

```javascript
worker.postMessage({
    type: "initialize",
    sourceLanguage: "es",
    targetLanguage: "en"
});
```

Response:

```javascript
{
    type: "ready",
    initializationMs: 842
}
```

Translate:

```javascript
worker.postMessage({
    type: "translate",
    id: 123,
    text: "¿Qué estás haciendo?"
});
```

Response:

```javascript
{
    type: "translated",
    id: 123,
    source: "¿Qué estás haciendo?",
    translation: "What are you doing?",
    queueMs: 0.4,
    inferenceMs: 26.8,
    totalMs: 27.2
}
```

Those three latency values are important.

---

# 11. Bergamot configuration

Use Mozilla-compatible quantized models.

The upstream Bergamot WASM sample uses settings including:

```yaml
beam-size: 1
normalize: 1.0
word-penalty: 0
max-length-break: 128
mini-batch-words: 1024
workspace: 128
max-length-factor: 2.0
skip-cost: true
gemm-precision: int8shiftAll
```

The upstream example specifically notes that `int8shiftAll` is needed for speed/compatibility with Mozilla models.

However:

> Prefer the configuration metadata shipped with the current Mozilla model over blindly copying this old example.

We want Firefox-equivalent inference.

---

# 12. Translation benchmark corpus

Do not benchmark:

```text
"Hello world"
```

500 times.

Subtitle translation has very different characteristics.

Create exactly four length buckets.

### Tiny

1–4 words:

```text
Sí.
Vamos.
¿Qué pasó?
No lo sé.
Ven conmigo.
```

### Short subtitle

5–10 words:

```text
No puedo creer que hayas hecho eso.
Tenemos que salir de aquí ahora mismo.
¿Quieres venir conmigo esta noche?
```

### Medium subtitle

11–20 words.

### Long subtitle

21–35 words.

Generate at least:

```text
100 tiny
200 short
150 medium
50 long
```

Total:

```text
500 unique strings
```

Primary:

```text
Spanish → English
```

Do not benchmark duplicate strings because translation caches could distort results.

---

# 13. Include realistic subtitle punctuation

Corpus should contain:

```text
questions
exclamations
contractions
names
numbers
dates
slang-like phrasing
ellipsis
hyphens
multiple clauses
```

Examples:

```text
¿Qué demonios estás haciendo?
Bueno... no estoy seguro.
Son las ocho y media.
María, espera un segundo.
No, no, no. Escúchame.
¿En serio quieres hacer esto ahora?
```

This is much more representative than prose paragraphs.

---

# 14. Mozilla warmup

Before recording numbers:

```text
initialize WASM
load model
translate 20 throwaway sentences
```

Discard these numbers.

Then begin measurement.

This eliminates JIT/WASM initialization noise.

---

# 15. Mozilla benchmark modes

Run three modes.

## M1 — sequential subtitle translation

Exactly:

```text
input
↓
await result
↓
next input
```

500 translations.

This is the most important comparison.

## M2 — burst

Submit:

```text
2 subtitles simultaneously
4 subtitles simultaneously
8 subtitles simultaneously
```

Measure:

```text
queue time
total time
throughput
```

## M3 — micro batch

Batch:

```text
2 lines
4 lines
8 lines
```

Bergamot's own example notes that larger batches can improve words/second at the cost of waiting longer for the complete batch.

We probably won't batch normal live subtitles, but we need to understand the tradeoff.

---

# 16. Metrics for Mozilla

Record each translation:

```json
{
  "engine": "mozilla-bergamot",
  "pair": "es-en",
  "id": 17,
  "characters": 42,
  "words": 8,
  "queueMs": 0.31,
  "inferenceMs": 24.84,
  "totalMs": 25.15
}
```

Calculate:

```text
mean
median / p50
p75
p90
p95
p99
minimum
maximum

translations/sec
words/sec
characters/sec
```

Also record:

```text
WASM initialization
model load time
model memory
worker memory
total process memory
CPU utilization
```

---

# 17. Phase C — Chrome baseline

Use **real current Google Chrome**, not ECS.

Chrome's `Translator` API is the proper quantitative comparison because it is Chrome's built-in, on-device translation API. It has been stable since Chrome 138 and uses browser-managed language packs downloaded on demand. ([Chrome for Developers][5])

Create:

```text
src/translation/chrome/index.html
```

Serve from:

```text
http://127.0.0.1:<port>
```

Do not use:

```text
Google Translate REST API
translate.google.com HTTP requests
cloud translation
```

We're comparing:

```text
LOCAL MOZILLA
vs
LOCAL CHROME
```

---

# 18. Chrome benchmark initialization

Feature check:

```javascript
if (!("Translator" in self)) {
    throw new Error(
        "Chrome Translator API unavailable"
    );
}
```

Then:

```javascript
const availability =
    await Translator.availability({
        sourceLanguage: "es",
        targetLanguage: "en"
    });
```

Record:

```text
available
downloadable
unavailable
```

If downloadable, allow Chrome to download the language pack.

Do not include download in latency.

Chrome's documentation explicitly separates availability/model downloading from `translate()` inference. ([Chrome for Developers][6])

---

# 19. Chrome benchmark

Create:

```javascript
const translator =
    await Translator.create({
        sourceLanguage: "es",
        targetLanguage: "en"
    });
```

Warm up with the same 20 throwaway inputs.

Then:

```javascript
const started =
    performance.now();

const result =
    await translator.translate(text);

const elapsed =
    performance.now() - started;
```

Run the **exact same corpus in the exact same order**.

Do not run Mozilla simultaneously during this baseline.

---

# 20. Important Chrome behavior

Chrome currently documents that translations are processed **sequentially**, meaning a large translation can block subsequent requests. ([Chrome for Developers][6])

That matters tremendously for subtitles.

Therefore test:

```text
single sequential
2-request burst
4-request burst
8-request burst
```

for Chrome too.

This may actually be an area where our dedicated Bergamot worker performs better operationally.

---

# 21. Randomize benchmark order

Run:

```text
Mozilla
Chrome
Chrome
Mozilla
Mozilla
Chrome
```

rather than always Mozilla first.

Do 5 complete benchmark rounds.

Reason:

```text
CPU temperature
background activity
JIT warmup
Windows scheduling
power state
```

can bias results.

Aggregate across all five.

---

# 22. Power configuration

Windows:

```text
plugged in
Best Performance power mode
no Windows Update running
no game downloading
no build running
no antivirus full scan
```

Do not artificially set process priority to realtime/high.

We want realistic desktop performance.

---

# 23. Translation performance gates

For **subtitle-sized inputs**, use:

### Absolute requirement

```text
Mozilla p95 <= 150 ms
Mozilla p99 <= 250 ms
```

A 150 ms p95 means the translated subtitle appears effectively immediately relative to normal subtitle display durations.

### Relative requirement

Operationally equivalent to Chrome:

```text
Mozilla p50 <= Chrome p50 * 1.05

AND

Mozilla p95 <= Chrome p95 * 1.10
```

That 5–10% tolerance is there because benchmarking local runtimes has noise.

Classification:

```text
Mozilla faster:
p50 AND p95 < Chrome

Equivalent:
within thresholds above

Slower but still viable:
Mozilla p95 <= 150ms
but >10% slower than Chrome

FAIL:
Mozilla p95 > 150ms
or severe queue buildup
```

If you want a literal "must equal or beat Chrome" gate, Grok should additionally report:

```text
STRICT_WIN =
Mozilla p50 <= Chrome p50
AND
Mozilla p95 <= Chrome p95
```

But I would not reject the architecture because Mozilla takes 55 ms and Chrome takes 50 ms.

For real subtitles, both are functionally instantaneous.

---

# 24. Throughput gate

Mozilla must sustain at least:

```text
10 short subtitle translations / second
```

on your target Windows PC.

Our actual workload is usually nowhere near that.

A show might present roughly:

```text
0.5–2 subtitle updates / second
```

with occasional bursts.

10/sec gives plenty of headroom.

---

# 25. Phase D — translate while DRM video is playing

This is crucial.

Fast translation while sitting on a blank benchmark page isn't enough.

Run:

```text
ECS
  │
  ├── Netflix DRM playback
  │
  └── Mozilla Bergamot worker
```

Start a known-working Netflix title.

Let it play for:

```text
5 minutes baseline
```

Record:

```text
CPU
memory
GPU
dropped frames if obtainable
```

Then run a simulated subtitle workload for:

```text
10 minutes
```

Schedule lines according to realistic subtitle timestamps:

```text
0ms
1400ms
3300ms
4500ms
7100ms
...
```

Translation worker translates each line when its timestamp arrives.

---

# 26. Playback stress workload

Test:

```text
NORMAL

1 subtitle roughly every 1.5 seconds
```

Then:

```text
BURST

3 lines arriving within 500 ms
```

Then:

```text
HEAVY

2 translations per second
for 2 minutes
```

The heavy case is deliberately beyond normal viewing.

---

# 27. Playback + translation gates

While DRM video runs:

```text
translation p95 <= 200 ms
translation p99 <= 300 ms
```

and:

```text
no audio breakup
no video freezing
no DRM failure
no player crash
no renderer crash
no meaningful visual stutter
```

If `HTMLVideoElement.getVideoPlaybackQuality()` is accessible, record:

```javascript
video.getVideoPlaybackQuality()
```

before and during translation.

Measure:

```text
totalVideoFrames
droppedVideoFrames
```

The translation workload should not increase dropped-frame percentage by more than approximately:

```text
1 percentage point
```

over the baseline run.

---

# 28. Run concurrency test on all three services

Once Mozilla translation works with Netflix:

```text
Netflix + Mozilla translation
Prime   + Mozilla translation
Max     + Mozilla translation
```

Don't yet extract the site's real subtitles.

Just play the video while feeding the translation worker synthetic subtitles.

That isolates:

```text
translation CPU pressure
```

from:

```text
site plugin correctness
```

which is exactly what we want.

---

# 29. Architecture isolation

Do **not** run Bergamot in the streaming page's main renderer thread.

Production model:

```text
              ECS

┌─────────────────────────────┐
│ Streaming renderer          │
│                             │
│ Netflix / Prime / Max       │
│ DRM                         │
│ video                       │
└──────────────┬──────────────┘
               │
         subtitle text
               │
               ↓
┌─────────────────────────────┐
│ Translation process/worker  │
│                             │
│ Bergamot WASM               │
│ Mozilla model               │
└──────────────┬──────────────┘
               │
       translated text
               ↓
       streaming renderer
```

Firefox itself similarly isolates Bergamot inference from normal web content in a dedicated inference process, which is a good architectural precedent. ([Firefox Source Docs][7])

---

# 30. Model-memory lifecycle

Only load translation models that are actively needed.

Example:

```text
user watches Spanish video
        ↓
load es → en
        ↓
keep warm
        ↓
user switches source language
        ↓
release es → en
        ↓
load fr → en
```

Do not keep every language model resident.

Measure memory after:

```text
engine init
model init
100 translations
1000 translations
model unload
```

Ensure memory returns close to baseline after release.

Look specifically for WASM heap growth/leaks.

---

# 31. Cold versus warm latency

Report these separately.

### Cold

```text
process starts
↓
WASM initializes
↓
model loaded from disk
↓
first translation
```

### Warm

```text
model already loaded
↓
subtitle arrives
↓
translated subtitle
```

The product-critical metric is **warm**.

Cold initialization can happen when playback starts.

Suggested cold target:

```text
cached model → ready <= 2 seconds
```

But do not reject Mozilla purely because Chrome initializes faster if warm inference is excellent.

---

# 32. Model download benchmark

Record:

```text
download bytes
download duration
disk size
```

but don't compare this directly to inference.

Mozilla downloads models on demand in Firefox too; Firefox's translation models and WASM artifacts are downloaded/cached as needed. ([Firefox Source Docs][8])

Production later should implement:

```text
download
verify hash
cache
reuse
background update
```

That is normal engineering after the spike.

---

# 33. Translation-quality sanity gate

Performance is the primary objective, but don't accept gibberish because it is fast.

For 100 randomly selected corpus entries manually compare:

```text
source
Mozilla translation
Chrome translation
```

Classify:

```text
good
acceptable
bad
meaning-changing
```

We don't need a full academic quality evaluation in this spike.

Mozilla already evaluates released models against translation systems and says models ready for Firefox generally target being within roughly **5% of Google Translate's COMET score**, though that is a model-release criterion rather than a guarantee for every subtitle sentence. ([Mozilla GitHub Pages][9])

So our task is mainly verifying that:

```text
the current released model
+
our integration
```

behaves sensibly.

---

# 34. Optional quality automation

If Grok has extra time, add:

```text
COMET
chrF
BLEU
```

against a small reference dataset.

But:

# Do not block the architecture decision on this.

Latency and streaming coexistence are the important things now.

---

# 35. Licensing verification

Mozilla's translations repository is **MPL 2.0**, and its README says the distributed translation model files are also MPL 2.0.

Bergamot is likewise MPL 2.0.

That means this is not:

```text
per translation fee
per user fee
cloud API fee
```

But MPL is not "no obligations."

For eventual distribution Grok should record:

```text
exact source revision
license file
model license
modifications if any
source availability requirement
third-party notices
```

Do **not** modify Bergamot during this spike.

Use upstream artifacts.

---

# 36. Result JSON schema

Every benchmark run should produce:

```json
{
  "engine": "mozilla-bergamot",
  "version": "...",
  "languagePair": "es-en",
  "run": 1,
  "mode": "sequential",
  "environment": {
    "cpu": "...",
    "ramGb": 0,
    "gpu": "...",
    "windows": "...",
    "playbackActive": false
  },
  "model": {
    "name": "...",
    "version": "...",
    "bytes": 0
  },
  "initializationMs": 0,
  "translations": 500,
  "p50Ms": 0,
  "p90Ms": 0,
  "p95Ms": 0,
  "p99Ms": 0,
  "meanMs": 0,
  "translationsPerSecond": 0,
  "wordsPerSecond": 0,
  "peakMemoryMb": 0
}
```

Chrome uses the same schema:

```json
{
  "engine": "chrome-translator-api"
}
```

This makes the comparison deterministic.

---

# 37. Generate comparison table

Final report must include:

| Metric              | Mozilla Bergamot | Chrome Translator | Winner |
| ------------------- | ---------------: | ----------------: | ------ |
| Warm p50            |             X ms |              Y ms |        |
| Warm p95            |             X ms |              Y ms |        |
| Warm p99            |             X ms |              Y ms |        |
| Short subtitle p95  |                X |                 Y |        |
| Long subtitle p95   |                X |                 Y |        |
| translations/sec    |                X |                 Y |        |
| words/sec           |                X |                 Y |        |
| cold initialization |                X |                 Y |        |
| memory              |             X MB |              Y MB |        |

Then another:

| Mozilla under video  | Netflix | Prime | Max |
| -------------------- | ------: | ----: | --: |
| p50                  |         |       |     |
| p95                  |         |       |     |
| p99                  |         |       |     |
| Video remains smooth |         |       |     |
| Audio remains smooth |         |       |     |
| DRM remains active   |         |       |     |

---

# 38. Final architecture decision rules

## GREEN — proceed

Require:

```text
STREAMING
─────────
Netflix ECS Windows       PASS
Prime ECS Windows         PASS
Max ECS Windows           PASS

No RDP
No UA spoof
No DRM hacks
No browser flags
Official ECS


TRANSLATION
───────────
Mozilla es→en p95        <= 150 ms

Mozilla vs Chrome:
<= 10% p95 regression
OR faster

Throughput:
>= 10 subtitle lines/sec


SIMULTANEOUS
────────────
Netflix + Mozilla        PASS
Prime + Mozilla          PASS
Max + Mozilla            PASS

Mozilla p95 under video  <= 200 ms

No meaningful video impact
No DRM impact
```

Then report:

```text
ARCHITECTURE VALIDATED
```

---

# 39. If Mozilla is much faster

If results look like:

```text
                  p50        p95

Chrome            65 ms      105 ms
Mozilla           28 ms       48 ms
```

then:

```text
FIREFOX TRANSLATION ENGINE:
STRONGLY VALIDATED
```

The production application should use Mozilla/Bergamot locally.

---

# 40. If Mozilla is roughly equal

Example:

```text
Chrome          p95 70 ms
Mozilla         p95 74 ms
```

That is effectively equal for our use case.

Do not waste engineering time trying to win an artificial benchmark by 4 ms.

Result:

```text
VALIDATED
```

---

# 41. If Mozilla is moderately slower

Example:

```text
Chrome          45 ms
Mozilla         85 ms
```

but Mozilla:

```text
p95 < 150 ms
```

Then classify:

```text
TRANSLATION:
VIABLE

PERFORMANCE:
CHROME FASTER
```

At that point I would still probably use Mozilla because:

```text
85ms is effectively instant for subtitles
+
we control it
+
local inference
+
open models/engine
+
no dependency on Chrome's proprietary browser API
```

But report the result accurately.

---

# 42. If Mozilla misses 150 ms

Example:

```text
p95 280ms
bursts 500ms+
```

Then run exactly one optimization investigation:

```text
check SIMD
check optimized release WASM
check correct quantized model
check worker isolation
check beam size/config
```

Firefox requires SIMD-capable hardware for its WASM translation implementation, so accidentally running an unoptimized/non-SIMD build would make the benchmark misleading. ([Firefox Source Docs][1])

If properly optimized Mozilla still misses:

```text
p95 <= 150ms
```

then:

```text
FAIL
```

and evaluate another local translation engine.

Do not spend a week tuning the benchmark.

---

# 43. Absolutely do not compare cloud Google Translate

The benchmark is:

```text
Mozilla local inference
        VS
Chrome local Translator API
```

Chrome says its Translator API uses browser-provided models and performs translation client-side rather than sending the content to a hosted translation service. ([Chrome for Developers][10])

That's the fair comparison.

---

# 44. One subtle but important point

Don't assume the Chrome `Translator` API will exist inside CastLabs ECS.

It is a **Chrome built-in API**, not something we should rely on being available in generic Chromium/Electron. The benchmark therefore intentionally runs in installed Google Chrome. Chrome documents the API as its browser-managed built-in translation feature. ([Chrome for Developers][6])

Our production candidate remains:

```text
ECS
+
Mozilla/Bergamot
```

not:

```text
ECS
+
Chrome Translator API
```

---

# 45. Exact test order I would give Grok

For speed, run in this order:

```text
PHASE 1
Physical Windows PC
No RDP

Netflix ECS
Prime ECS
Max ECS

ALL PASS?
    NO → stop/report
    YES ↓


PHASE 2

Get current Mozilla
es→en model

Get current Firefox
Bergamot WASM

Run 500 subtitle benchmark

p95 <= 150ms?
    NO → verify optimized build once
    YES ↓


PHASE 3

Run same corpus through
Chrome Translator API

5 benchmark rounds

Compute:
p50
p95
p99
throughput


PHASE 4

Play Netflix in ECS

Run simulated subtitle stream
through Mozilla engine

Then Prime

Then Max


PHASE 5

Generate FINAL_REPORT.md
```

---

# 46. The final report should end with exactly this type of summary

```text
WINDOWS ARCHITECTURE SPIKE

Host
──────────────────────────
Windows 11: PASS
Physical local session: YES
RDP: DISCONNECTED


CastLabs ECS
──────────────────────────
Version: 43.2.0+wvcus

Netflix: PASS
Prime:   PASS
Max:     PASS

Widevine: PASS
VMP:      PASS
GPU:      PASS

UA spoof:             NO
Browser flags:        NO
DRM workaround:       NO
Custom codecs:        NO
Custom Chromium:      NO


Translation
──────────────────────────
Pair: Spanish → English

Chrome Translator API

p50:
p95:
p99:
translations/sec:


Mozilla Firefox Translations / Bergamot

p50:
p95:
p99:
translations/sec:


Mozilla vs Chrome
──────────────────────────
p50 ratio:
p95 ratio:

Winner:
MOZILLA / CHROME / EQUIVALENT


Streaming + Mozilla
──────────────────────────
Netflix: PASS
Prime:   PASS
Max:     PASS

Translation p95 while playing:
Dropped-frame impact:
Audio impact:
DRM impact:


FINAL DECISION
──────────────────────────

CASTLABS ECS:
VIABLE / NOT VIABLE

MOZILLA TRANSLATION:
VIABLE / NOT VIABLE

OVERALL DESKTOP ARCHITECTURE:
VALIDATED / REJECTED
```

## What I would consider a successful result

Something like:

```text
Netflix             PASS
Prime               PASS
Max                 PASS

Mozilla p50          35ms
Mozilla p95          62ms

Chrome p50           40ms
Chrome p95           70ms

Mozilla during DRM:
p95                  78ms

Playback impact      NONE
```

At that point **stop doing browser-framework research**.

The architecture would have proved the hard pieces:

```text
CastLabs ECS
        │
        ├── reliable commercial streaming
        │
        └── Chromium rendering
                 │
                 ↓
         future site plugins
                 │
                 ↓
          subtitle text
                 │
                 ↓
     Mozilla/Bergamot worker
                 │
                 ↓
       translated subtitle
```

Then the next project phase is much more ordinary engineering: **extract captions reliably, build the provider plugin interface, send caption events to the translation worker, and inject the translated line back into the page.**

[1]: https://firefox-source-docs.mozilla.org/toolkit/components/translations/resources/01_overview.html "Overview of Translations — Firefox Source Docs documentation"
[2]: https://github.com/castlabs/electron-releases/releases?after=v10.3.2-wvvmp&utm_source=chatgpt.com "Releases · castlabs/electron-releases · GitHub"
[3]: https://github.com/castlabs/electron-releases?utm_source=chatgpt.com "GitHub - castlabs/electron-releases: Castlabs Electron for Content Security · GitHub"
[4]: https://firefox-source-docs.mozilla.org/toolkit/components/translations/resources/03_bergamot.html "The Bergamot Translator — Firefox Source Docs documentation"
[5]: https://developer.chrome.com/docs/ai/built-in-apis?authuser=9&utm_source=chatgpt.com "Built-in AI APIs  |  AI on Chrome  |  Chrome for Developers"
[6]: https://developer.chrome.com/docs/ai/translator-api?hl=en "Translation with built-in AI  |  AI on Chrome  |  Chrome for Developers"
[7]: https://firefox-source-docs.mozilla.org/dom/ipc/process_model.html?utm_source=chatgpt.com "Process Model — Firefox Source Docs documentation"
[8]: https://firefox-source-docs.mozilla.org/toolkit/components/translations/resources/02_contributing.html?utm_source=chatgpt.com "Contributing to Translations — Firefox Source Docs documentation"
[9]: https://mozilla.github.io/translations/firefox-models/?utm_source=chatgpt.com "Firefox Translations Models"
[10]: https://developer.chrome.com/docs/ai/translator-api?hl=en&utm_source=chatgpt.com "Translation with built-in AI  |  AI on Chrome  |  Chrome for Developers"

