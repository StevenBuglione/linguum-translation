/* global BergamotAdapter */

"use strict";

importScripts("/src/translation/mozilla/bergamot-adapter.js");
importScripts("/artifacts/mozilla/engine/bergamot-translator.js");

let engine = null;
let ready = false;
const pending = [];

function postError(id, error) {
  self.postMessage({
    type: "error",
    id,
    error: {
      message: error?.message || String(error),
      stack: error?.stack || null
    }
  });
}

async function handleInitialize(message) {
  const started = performance.now();
  const { sourceLanguage, targetLanguage, wasm, files, modelConfig } = message;
  if (!sourceLanguage || !targetLanguage) {
    throw new Error("initialize requires sourceLanguage and targetLanguage");
  }
  if (!wasm) {
    throw new Error("initialize requires wasm ArrayBuffer");
  }
  if (!files?.model) {
    throw new Error("initialize requires model files");
  }

  if (engine) {
    engine.unload();
    engine = null;
  }

  engine = await BergamotAdapter.createEngine({
    sourceLanguage,
    targetLanguage,
    wasmBinary: wasm,
    languageModelFiles: files,
    modelConfig
  });
  ready = true;
  const initializationMs = performance.now() - started;
  self.postMessage({
    type: "ready",
    initializationMs,
    sourceLanguage,
    targetLanguage
  });
}

function handleTranslate(message) {
  if (!engine || !ready) {
    throw new Error("Worker is not initialized");
  }
  const queuedAt = performance.now();
  const { id, text, html } = message;
  const { translation, inferenceMs } = engine.translate(text, html);
  const totalMs = performance.now() - queuedAt;
  self.postMessage({
    type: "translated",
    id,
    source: text,
    translation,
    queueMs: Math.max(0, totalMs - inferenceMs),
    inferenceMs,
    totalMs
  });
}

function handleTranslateBatch(message) {
  if (!engine || !ready) {
    throw new Error("Worker is not initialized");
  }
  const queuedAt = performance.now();
  const { id, texts, html } = message;
  const { translations, inferenceMs } = engine.translateMany(texts, html);
  const totalMs = performance.now() - queuedAt;
  self.postMessage({
    type: "translated-batch",
    id,
    sources: texts,
    translations,
    queueMs: 0,
    inferenceMs,
    totalMs
  });
}

function handleUnload() {
  if (engine) {
    engine.unload();
  }
  engine = null;
  ready = false;
  self.postMessage({ type: "unloaded" });
}

self.addEventListener("message", async (event) => {
  const message = event.data;
  try {
    switch (message.type) {
      case "initialize":
        await handleInitialize(message);
        break;
      case "translate":
        handleTranslate(message);
        break;
      case "translate-batch":
        handleTranslateBatch(message);
        break;
      case "unload":
        handleUnload();
        break;
      default:
        throw new Error(`Unknown worker message type: ${message.type}`);
    }
  } catch (error) {
    postError(message.id, error);
  }
});
