/* global loadBergamot */

const MODEL_FILE_ALIGNMENTS = {
  model: 256,
  lex: 64,
  vocab: 64,
  srcvocab: 64,
  trgvocab: 64
};

function generateTextConfig(config) {
  const indent = "            ";
  let result = "\n";
  for (const [key, value] of Object.entries(config)) {
    result += `${indent}${key}: ${value}\n`;
  }
  return result + indent;
}

function gemmPrecisionForModelName(name) {
  if (String(name).endsWith("intgemm8.bin")) {
    return "int8shiftAll";
  }
  return "int8shiftAlphaAll";
}

function allocateModelMemory(bergamot, languageModelFiles) {
  const results = {};
  for (const [fileType, file] of Object.entries(languageModelFiles)) {
    const alignment = MODEL_FILE_ALIGNMENTS[fileType];
    if (!alignment) {
      continue;
    }
    const alignedMemory = new bergamot.AlignedMemory(
      file.buffer.byteLength,
      alignment
    );
    alignedMemory.getByteArrayView().set(new Uint8Array(file.buffer));
    results[fileType] = alignedMemory;
  }
  return results;
}

function constructSingleTranslationModel(bergamot, payload) {
  const { sourceLanguage, targetLanguage, languageModelFiles, modelConfig } = payload;
  const { model, lex, vocab, srcvocab, trgvocab } = allocateModelMemory(
    bergamot,
    languageModelFiles
  );

  const vocabList = new bergamot.AlignedMemoryList();
  if (vocab) {
    vocabList.push_back(vocab);
  } else if (srcvocab && trgvocab) {
    vocabList.push_back(srcvocab);
    vocabList.push_back(trgvocab);
  } else {
    throw new Error("Vocabulary key is not found.");
  }

  const config = generateTextConfig({
    "beam-size": "1",
    normalize: "1.0",
    "word-penalty": "0",
    "max-length-break": "128",
    "mini-batch-words": "1024",
    workspace: "128",
    "max-length-factor": "2.0",
    "skip-cost": "true",
    "cpu-threads": "0",
    quiet: "true",
    "quiet-translation": "true",
    "gemm-precision": gemmPrecisionForModelName(
      languageModelFiles.model.name || languageModelFiles.model.filename || ""
    ),
    alignment: "soft",
    ...(modelConfig || {})
  });

  return new bergamot.TranslationModel(
    sourceLanguage,
    targetLanguage,
    config,
    model,
    lex ?? null,
    vocabList,
    null
  );
}

function initializeWasm(wasmBinary) {
  return new Promise((resolve, reject) => {
    if (typeof loadBergamot !== "function") {
      reject(new Error("loadBergamot is not available. bergamot-translator.js was not loaded."));
      return;
    }
    const bergamot = loadBergamot({
      INITIAL_MEMORY: 41_943_040,
      print: (...args) => console.log("Bergamot:", ...args),
      onAbort() {
        reject(new Error("Error loading Bergamot wasm module."));
      },
      onRuntimeInitialized: async () => {
        await Promise.resolve();
        resolve(bergamot);
      },
      wasmBinary
    });
  });
}

function getTranslationArgs(bergamot, texts, isHTML) {
  const messages = new bergamot.VectorString();
  const options = new bergamot.VectorResponseOptions();
  for (const text of texts) {
    if (!text) {
      continue;
    }
    messages.push_back(text);
    options.push_back({
      qualityScores: false,
      alignment: false,
      html: Boolean(isHTML)
    });
  }
  return { messages, options };
}

class BergamotEngine {
  constructor(sourceLanguage, targetLanguage, bergamot, models) {
    this.sourceLanguage = sourceLanguage;
    this.targetLanguage = targetLanguage;
    this.bergamot = bergamot;
    this.models = models;
    this.translationService = new bergamot.BlockingService({ cacheSize: 0 });
  }

  translateMany(texts, isHTML = false) {
    const started = performance.now();
    const { messages, options } = getTranslationArgs(this.bergamot, texts, isHTML);
    try {
      if (messages.size() === 0) {
        return { translations: [], inferenceMs: 0 };
      }
      let responses;
      if (this.models.length === 1) {
        responses = this.translationService.translate(
          this.models[0],
          messages,
          options
        );
      } else if (this.models.length === 2) {
        responses = this.translationService.translateViaPivoting(
          this.models[0],
          this.models[1],
          messages,
          options
        );
      } else {
        throw new Error("Too many models were provided to the translation worker.");
      }
      const translations = [];
      for (let i = 0; i < responses.size(); i += 1) {
        translations.push(responses.get(i).getTranslatedText());
      }
      responses.delete();
      return {
        translations,
        inferenceMs: performance.now() - started
      };
    } finally {
      messages.delete();
      options.delete();
    }
  }

  translate(text, isHTML = false) {
    const { translations, inferenceMs } = this.translateMany([text], isHTML);
    return {
      translation: translations[0] ?? "",
      inferenceMs
    };
  }

  unload() {
    for (const model of this.models) {
      try {
        model.delete();
      } catch {
        // ignore double-free
      }
    }
    this.models = [];
    try {
      this.translationService.delete();
    } catch {
      // ignore
    }
  }
}

async function createEngine({
  sourceLanguage,
  targetLanguage,
  wasmBinary,
  languageModelFiles,
  modelConfig
}) {
  const bergamot = await initializeWasm(wasmBinary);
  const model = constructSingleTranslationModel(bergamot, {
    sourceLanguage,
    targetLanguage,
    languageModelFiles,
    modelConfig
  });
  return new BergamotEngine(sourceLanguage, targetLanguage, bergamot, [model]);
}

if (typeof self !== "undefined") {
  self.BergamotAdapter = {
    createEngine,
    initializeWasm,
    constructSingleTranslationModel,
    gemmPrecisionForModelName
  };
}
