export const REMOTE_SETTINGS_MODELS =
  "https://firefox.settings.services.mozilla.com/v1/buckets/main/collections/translations-models/records";
export const REMOTE_SETTINGS_WASM =
  "https://firefox.settings.services.mozilla.com/v1/buckets/main/collections/translations-wasm/records";
export const ATTACHMENT_ROOT =
  "https://firefox-settings-attachments.cdn.mozilla.net/";
export const FIREFOX_JS_URL =
  "https://raw.githubusercontent.com/mozilla-firefox/firefox/main/toolkit/components/translations/bergamot-translator/bergamot-translator.js";
export const FIREFOX_CI_WASM_ZST =
  "https://storage.googleapis.com/moz-fx-translations-data--303e-prod-translations-data/firefox-ci/wasm/bergamot-translator.wasm.zst";

export function attachmentUrl(location) {
  return `${ATTACHMENT_ROOT}${location}`;
}

export function hexFromBuffer(buffer) {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function sha256Hex(buffer) {
  const digest = await crypto.subtle.digest("SHA-256", buffer);
  return hexFromBuffer(digest);
}

export function buffersEqualHex(actual, expected) {
  return String(actual).toLowerCase() === String(expected).toLowerCase();
}

export function selectLatestPair(records, fromLang, toLang) {
  const matches = records.filter(
    (record) => record.fromLang === fromLang && record.toLang === toLang
  );
  if (!matches.length) {
    throw new Error(`No Remote Settings records for ${fromLang}-${toLang}`);
  }
  matches.sort((a, b) => {
    const version = String(b.version).localeCompare(String(a.version), undefined, {
      numeric: true
    });
    if (version !== 0) {
      return version;
    }
    return (b.last_modified || 0) - (a.last_modified || 0);
  });
  const latestVersion = matches[0].version;
  return matches.filter((record) => record.version === latestVersion);
}

export function filesFromPairRecords(records) {
  const files = {};
  for (const record of records) {
    files[record.fileType] = {
      name: record.name,
      fileType: record.fileType,
      version: record.version,
      fromLang: record.fromLang,
      toLang: record.toLang,
      sha256: record.hash || record.attachment?.hash,
      bytes: record.attachment?.size || 0,
      url: attachmentUrl(record.attachment.location),
      filename: record.attachment.filename
    };
  }
  if (!files.model) {
    throw new Error("Pair is missing model file");
  }
  if (!files.vocab && !(files.srcvocab && files.trgvocab)) {
    throw new Error("Pair is missing vocab file(s)");
  }
  return files;
}

export function selectBergamotWasm(records) {
  const wasmRecords = records.filter((record) => record.name === "bergamot-translator");
  if (!wasmRecords.length) {
    throw new Error("No bergamot-translator WASM records in Remote Settings");
  }
  wasmRecords.sort((a, b) => {
    const version = String(b.version).localeCompare(String(a.version), undefined, {
      numeric: true
    });
    if (version !== 0) {
      return version;
    }
    return (b.last_modified || 0) - (a.last_modified || 0);
  });
  const record = wasmRecords[0];
  return {
    name: record.name,
    version: record.version,
    release: record.release,
    revision: record.revision,
    fxRelease: record.fx_release,
    license: record.license,
    sha256: record.hash || record.attachment?.hash,
    bytes: record.attachment?.size || 0,
    url: attachmentUrl(record.attachment.location),
    filename: record.attachment.filename
  };
}

export async function verifyBuffer(buffer, expectedSha256, label) {
  const actual = await sha256Hex(buffer);
  if (expectedSha256 && !buffersEqualHex(actual, expectedSha256)) {
    throw new Error(
      `Hash mismatch for ${label}: expected ${expectedSha256}, got ${actual}`
    );
  }
  return actual;
}

export function gemmPrecisionForModelName(name) {
  if (String(name).endsWith("intgemm8.bin")) {
    return "int8shiftAll";
  }
  return "int8shiftAlphaAll";
}

export function pairId(fromLang, toLang) {
  return `${fromLang}-${toLang}`;
}

export async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`GET ${url} failed: ${response.status}`);
  }
  return response.json();
}

export async function fetchArrayBuffer(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`GET ${url} failed: ${response.status}`);
  }
  return response.arrayBuffer();
}

export async function loadLocalManifest(origin = "") {
  return fetchJson(`${origin}/artifacts/mozilla/manifest.json`);
}

export async function loadPairBuffers(manifest, fromLang, toLang, origin = "") {
  const id = pairId(fromLang, toLang);
  const pair = manifest.pairs[id];
  if (!pair) {
    throw new Error(`Manifest has no pair ${id}. Run fetch-mozilla-models first.`);
  }

  const files = {};
  for (const [fileType, meta] of Object.entries(pair.files)) {
    const buffer = await fetchArrayBuffer(`${origin}/${meta.relativePath.replaceAll("\\", "/")}`);
    const sha = await verifyBuffer(buffer, meta.sha256, `${id} ${fileType}`);
    files[fileType] = {
      ...meta,
      sha256: sha,
      buffer
    };
  }

  const wasm = await fetchArrayBuffer(
    `${origin}/${manifest.engine.wasmRelativePath.replaceAll("\\", "/")}`
  );
  const wasmSha = await verifyBuffer(wasm, manifest.engine.sha256, "bergamot wasm");

  return {
    pair: id,
    version: pair.modelVersion || pair.version,
    source: pair.source,
    files,
    wasm: {
      buffer: wasm,
      sha256: wasmSha,
      version: manifest.engine.version,
      source: manifest.engine.source,
      bytes: wasm.byteLength
    }
  };
}
