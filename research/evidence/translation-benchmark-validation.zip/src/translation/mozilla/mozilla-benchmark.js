import { loadLocalManifest, loadPairBuffers } from "./model-loader.js";
import {
  BURST_SIZES,
  BATCH_SIZES,
  firstTranslationProbe,
  runBurst,
  runMicroBatch,
  runSequential,
  summarizeRun,
  warmupSentences
} from "../common/benchmark.js";

export function createMozillaWorker() {
  return new Worker("/src/translation/mozilla/translation-worker.js");
}

export function workerRpc(worker) {
  let nextId = 1;
  const pending = new Map();

  worker.addEventListener("message", (event) => {
    const message = event.data;
    if (message.type === "ready") {
      pending.get("init")?.resolve(message);
      pending.delete("init");
      return;
    }
    if (message.type === "unloaded") {
      pending.get("unload")?.resolve(message);
      pending.delete("unload");
      return;
    }
    if (message.type === "error") {
      const waiter = pending.get(message.id) || pending.get("init");
      waiter?.reject(new Error(message.error?.message || "Worker error"));
      pending.delete(message.id);
      pending.delete("init");
      return;
    }
    if (message.type === "translated" || message.type === "translated-batch") {
      pending.get(message.id)?.resolve(message);
      pending.delete(message.id);
    }
  });

  function request(payload, transfer = []) {
    return new Promise((resolve, reject) => {
      if (payload.type === "initialize") {
        pending.set("init", { resolve, reject });
        worker.postMessage(payload, transfer);
        return;
      }
      if (payload.type === "unload") {
        pending.set("unload", { resolve, reject });
        worker.postMessage(payload);
        return;
      }
      const id = payload.id ?? nextId++;
      payload.id = id;
      pending.set(id, { resolve, reject });
      worker.postMessage(payload, transfer);
    });
  }

  return {
    initialize(payload, transfer) {
      return request({ type: "initialize", ...payload }, transfer);
    },
    translate(text) {
      const queuedAt = performance.now();
      return request({ type: "translate", text }).then((message) => ({
        translation: message.translation,
        inferenceMs: message.inferenceMs,
        queueMs: message.queueMs,
        totalMs: message.totalMs,
        clientTotalMs: performance.now() - queuedAt
      }));
    },
    translateBatch(texts) {
      return request({ type: "translate-batch", texts }).then((message) =>
        texts.map((text, index) => ({
          translation: message.translations[index],
          inferenceMs: message.inferenceMs,
          source: text
        }))
      );
    },
    unload() {
      return request({ type: "unload" });
    }
  };
}

function memoryInfo() {
  const mem = performance.memory;
  const jsHeapUsedMb = mem
    ? Number((mem.usedJSHeapSize / 1024 / 1024).toFixed(2))
    : null;
  return {
    jsHeapUsedMb,
    memory: {
      type: "js-heap",
      jsHeapUsedMb,
      informational: true
    }
  };
}

export async function runMozillaBenchmark({
  corpus,
  environment,
  run = 1,
  round = null,
  seed = null,
  corpusSha256 = null,
  sequentialOnly = true,
  origin = "",
  sourceLanguage = "es",
  targetLanguage = "en",
  onLog = () => {},
  onProgress = () => {}
}) {
  const pair = `${sourceLanguage}-${targetLanguage}`;
  const meta = { round: round ?? run, seed, corpusSha256 };
  const items = corpus.items;
  const heap = memoryInfo();

  onLog("Loading Mozilla artifacts and initializing WASM engine…");
  const engineSetupStarted = performance.now();
  const worker = createMozillaWorker();
  const rpc = workerRpc(worker);
  const manifest = await loadLocalManifest(origin);
  const loaded = await loadPairBuffers(manifest, sourceLanguage, targetLanguage, origin);
  await rpc.initialize(
    {
      sourceLanguage,
      targetLanguage,
      wasm: loaded.wasm.buffer,
      files: Object.fromEntries(
        Object.entries(loaded.files).map(([type, file]) => [
          type,
          {
            name: file.name,
            filename: file.filename,
            buffer: file.buffer
          }
        ])
      )
    },
    [
      loaded.wasm.buffer,
      ...Object.values(loaded.files).map((file) => file.buffer)
    ]
  );
  const engineSetupMs = performance.now() - engineSetupStarted;
  onLog(`Engine ready in ${engineSetupMs.toFixed(1)} ms (setup includes load + worker + WASM + model)`);

  const probe = firstTranslationProbe(corpus);
  const firstStarted = performance.now();
  await rpc.translate(probe);
  const firstTranslationMs = performance.now() - firstStarted;
  onLog(`firstTranslation=${firstTranslationMs.toFixed(1)} ms`);

  onLog("Warmup: 20 canonical sentences (discarded, no overlap with measured corpus)");
  for (const sentence of warmupSentences(corpus)) {
    await rpc.translate(sentence);
  }

  const modelMeta = {
    name: loaded.files.model.name,
    version: loaded.version || loaded.files.model.version || "2.0",
    bytes: Object.values(loaded.files).reduce((sum, file) => sum + (file.bytes || file.buffer.byteLength), 0)
  };

  const results = [];
  onLog("M1 sequential: 500 unique strings");
  const sequential = await runSequential({
    items,
    engine: "mozilla-bergamot",
    pair,
    translate: (text) => rpc.translate(text),
    onProgress: (done, total) => onProgress("sequential", done, total)
  });
  const sequentialSummary = summarizeRun({
    engine: "mozilla-bergamot",
    version: loaded.wasm.version,
    languagePair: pair,
    run,
    ...meta,
    mode: "sequential",
    environment,
    model: modelMeta,
    engineSetupMs,
    firstTranslationMs,
    wallClockMs: sequential.wallClockMs,
    records: sequential.records,
    ...heap
  });
  sequentialSummary.cacheSize = 0;
  sequentialSummary.service = "BlockingService";
  results.push(sequentialSummary);

  if (!sequentialOnly) {
    for (const concurrency of BURST_SIZES) {
      onLog(`M2 burst concurrency=${concurrency}`);
      const burst = await runBurst({
        items,
        engine: "mozilla-bergamot",
        pair,
        concurrency,
        translate: (text) => rpc.translate(text),
        onProgress: (done, total) => onProgress(`burst-${concurrency}`, done, total)
      });
      results.push(
        summarizeRun({
          engine: "mozilla-bergamot",
          version: loaded.wasm.version,
          languagePair: pair,
          run,
          ...meta,
          mode: `burst-${concurrency}`,
          environment,
          model: modelMeta,
          engineSetupMs,
          firstTranslationMs,
          wallClockMs: burst.wallClockMs,
          records: burst.records,
          ...heap
        })
      );
    }

    for (const batchSize of BATCH_SIZES) {
      onLog(`M3 micro-batch size=${batchSize}`);
      const batched = await runMicroBatch({
        items,
        engine: "mozilla-bergamot",
        pair,
        batchSize,
        translateBatch: (texts) => rpc.translateBatch(texts),
        onProgress: (done, total) => onProgress(`batch-${batchSize}`, done, total)
      });
      results.push(
        summarizeRun({
          engine: "mozilla-bergamot",
          version: loaded.wasm.version,
          languagePair: pair,
          run,
          ...meta,
          mode: `batch-${batchSize}`,
          environment,
          model: modelMeta,
          engineSetupMs,
          firstTranslationMs,
          wallClockMs: batched.wallClockMs,
          records: batched.records,
          ...heap
        })
      );
    }
  }

  await rpc.unload();
  worker.terminate();

  return {
    engine: "mozilla-bergamot",
    run,
    round: meta.round,
    seed: meta.seed,
    corpusSha256: meta.corpusSha256,
    engineSetupMs,
    firstTranslationMs,
    wallClockMs: sequential.wallClockMs,
    model: modelMeta,
    wasm: {
      version: loaded.wasm.version,
      sha256: loaded.wasm.sha256,
      bytes: loaded.wasm.bytes,
      source: loaded.wasm.source
    },
    cacheSize: 0,
    results
  };
}
