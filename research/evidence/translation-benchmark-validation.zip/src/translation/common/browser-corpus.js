export async function loadRoundCorpus(params) {
  const base = await (await fetch("/src/translation/common/corpus.json")).json();
  const corpusParam = params.get("corpus");
  if (!corpusParam) {
    return {
      corpus: base,
      round: Number(params.get("round") || params.get("run") || "1"),
      seed: params.get("seed") ? Number(params.get("seed")) : null,
      corpusSha256: params.get("corpusSha256") || null
    };
  }

  const normalized = corpusParam.replaceAll("\\", "/");
  const url = /^https?:\/\//i.test(normalized)
    ? normalized
    : normalized.startsWith("/")
      ? normalized
      : `/${normalized}`;
  const roundCorpus = await (await fetch(url)).json();
  if (!Array.isArray(roundCorpus.items) || roundCorpus.items.length !== 500) {
    throw new Error(`round corpus at ${url} does not contain 500 items`);
  }

  return {
    corpus: {
      ...base,
      items: roundCorpus.items
    },
    round: roundCorpus.round,
    seed: roundCorpus.seed,
    corpusSha256: roundCorpus.roundCorpusSha256,
    sourceCorpusSha256: roundCorpus.sourceCorpusSha256
  };
}

export async function loadMachine() {
  try {
    return await (await fetch("/results/machine.json")).json();
  } catch {
    return {};
  }
}

export function chromeVersionFromNavigator() {
  const brands = navigator.userAgentData?.brands || [];
  const chromeBrand =
    brands.find((brand) => /Google Chrome/i.test(brand.brand)) ||
    brands.find((brand) => /Chrome/i.test(brand.brand) && !/Chromium/i.test(brand.brand));
  if (chromeBrand) {
    return `${chromeBrand.brand} ${chromeBrand.version}`;
  }
  const match = navigator.userAgent.match(/Chrome\/([\d.]+)/);
  return match ? match[1] : navigator.userAgent;
}
