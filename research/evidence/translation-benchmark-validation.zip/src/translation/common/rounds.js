import { createHash } from "node:crypto";

export const ROUND_COUNT = 6;
export const MEASURED_COUNT = 500;
export const WARMUP_COUNT = 20;

export const ROUND_SEEDS = [42001, 42002, 42003, 42004, 42005, 42006];

export const ROUND_ORDERS = {
  1: ["native", "chrome", "wasm"],
  2: ["chrome", "wasm", "native"],
  3: ["wasm", "native", "chrome"],
  4: ["native", "wasm", "chrome"],
  5: ["wasm", "chrome", "native"],
  6: ["chrome", "native", "wasm"]
};

export const ENGINE_FILES = {
  chrome: "chrome",
  wasm: "wasm",
  native: "native"
};

export const ENGINE_IDS = {
  chrome: "chrome-translator-api",
  wasm: "mozilla-bergamot",
  native: "mozilla-bergamot-native"
};

export function padRound(round) {
  return String(round).padStart(2, "0");
}

export function mulberry32(seed) {
  let t = seed >>> 0;
  return function next() {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

export function fisherYates(items, rng) {
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rng() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export function hashItems(items) {
  return createHash("sha256").update(JSON.stringify(items), "utf8").digest("hex");
}

export function buildRoundCorpus(baseItems, round, seed) {
  if (!Array.isArray(baseItems) || baseItems.length !== MEASURED_COUNT) {
    throw new Error(`base corpus must have ${MEASURED_COUNT} items`);
  }
  const items = fisherYates(baseItems, mulberry32(seed));
  return {
    round,
    seed,
    items,
    sourceCorpusSha256: hashItems(baseItems),
    roundCorpusSha256: hashItems(items)
  };
}

export function roundFileName(round) {
  return `round-${padRound(round)}.json`;
}

export function runFileName(round, engineKey) {
  return `round-${padRound(round)}-${ENGINE_FILES[engineKey]}.json`;
}

export function mergeRoundCorpus(base, roundCorpus) {
  if (!roundCorpus?.items) {
    throw new Error("round corpus is missing items");
  }
  if (roundCorpus.items.length !== MEASURED_COUNT) {
    throw new Error(`round corpus must have ${MEASURED_COUNT} items`);
  }
  return {
    ...base,
    items: roundCorpus.items,
    round: roundCorpus.round,
    seed: roundCorpus.seed,
    sourceCorpusSha256: roundCorpus.sourceCorpusSha256,
    corpusSha256: roundCorpus.roundCorpusSha256
  };
}

export function expectedRunFiles() {
  const files = [];
  for (let round = 1; round <= ROUND_COUNT; round += 1) {
    for (const engineKey of Object.keys(ENGINE_FILES)) {
      files.push(runFileName(round, engineKey));
    }
  }
  return files;
}
