import { median, standardDeviation, mean, summarizeLatencies } from "./statistics.js";
import {
  ENGINE_IDS,
  ENGINE_FILES,
  ROUND_COUNT,
  ROUND_SEEDS,
  expectedRunFiles,
  padRound,
  runFileName
} from "./rounds.js";
import { sequentialResult, validateMeasuredRun } from "./validate-result.js";

export const SUBTITLE_P95_MS = 150;
export const SUBTITLE_P99_MS = 250;
export const SUBTITLE_TPS = 10;
export const EQUIVALENCE_P95_RATIO = 1.1;

function engineKeyFromId(engineId) {
  return Object.entries(ENGINE_IDS).find(([, id]) => id === engineId)?.[0] || null;
}

export function requireSequential(payload) {
  const sequential = sequentialResult(payload);
  if (!sequential) {
    throw new Error("payload is missing a sequential result");
  }
  return sequential;
}

export function sampleSources(payload) {
  return requireSequential(payload).samples.map((sample) => sample.source);
}

export function validatePairedRound(round, payloads, expected) {
  const errors = [];
  const engines = ["chrome", "wasm", "native"];
  for (const engineKey of engines) {
    const payload = payloads[engineKey];
    if (!payload) {
      errors.push(`round ${round}: missing ${engineKey} result`);
      continue;
    }
    const check = validateMeasuredRun(payload, {
      engine: ENGINE_IDS[engineKey],
      run: round,
      round,
      seed: expected.seed,
      corpusSha256: expected.corpusSha256,
      sequentialCount: 500,
      items: expected.items
    });
    if (!check.valid) {
      errors.push(`round ${round} ${engineKey}: ${check.errors.join("; ")}`);
    }
  }

  const present = engines.filter((engineKey) => payloads[engineKey]);
  if (present.length === 3) {
    const hashes = present.map((engineKey) => payloads[engineKey].corpusSha256);
    if (new Set(hashes).size !== 1) {
      errors.push(
        `round ${round}: corpus hashes differ: chrome=${hashes[0]} wasm=${hashes[1]} native=${hashes[2]}`
      );
    }
    const sources = present.map((engineKey) => sampleSources(payloads[engineKey]));
    for (let i = 0; i < 500; i += 1) {
      if (sources[0][i] !== sources[1][i] || sources[0][i] !== sources[2][i]) {
        errors.push(
          `round ${round}: sample ${i} source differs across engines (chrome=${JSON.stringify(sources[0][i])} wasm=${JSON.stringify(sources[1][i])} native=${JSON.stringify(sources[2][i])})`
        );
        break;
      }
    }
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

export function validateCompleteSet(payloadsByFile, corporaByRound = {}) {
  const errors = [];
  const expectedFiles = expectedRunFiles();
  for (const name of expectedFiles) {
    if (!payloadsByFile[name]) {
      errors.push(`missing run file ${name}`);
    }
  }
  const extra = Object.keys(payloadsByFile).filter((name) => !expectedFiles.includes(name));
  if (extra.length) {
    errors.push(`unexpected run files: ${extra.join(", ")}`);
  }

  const byRound = {};
  for (let round = 1; round <= ROUND_COUNT; round += 1) {
    byRound[round] = {};
    for (const engineKey of Object.keys(ENGINE_FILES)) {
      const name = runFileName(round, engineKey);
      const payload = payloadsByFile[name];
      if (!payload) {
        continue;
      }
      byRound[round][engineKey] = payload;
      if (payload.engine !== ENGINE_IDS[engineKey]) {
        errors.push(`${name}: engine ${payload.engine} does not match ${ENGINE_IDS[engineKey]}`);
      }
      if (payload.round !== round || payload.run !== round) {
        errors.push(`${name}: expected run/round ${round}, got run=${payload.run} round=${payload.round}`);
      }
    }
    const expected = corporaByRound[round] || {
      seed: ROUND_SEEDS[round - 1],
      corpusSha256: byRound[round].chrome?.corpusSha256,
      items: byRound[round].chrome ? sampleSources(byRound[round].chrome) : null
    };
    const paired = validatePairedRound(round, byRound[round], expected);
    if (!paired.valid) {
      errors.push(...paired.errors);
    }
  }

  for (const engineKey of Object.keys(ENGINE_FILES)) {
    const count = Object.values(byRound).filter((row) => row[engineKey]).length;
    if (count !== ROUND_COUNT) {
      errors.push(`${engineKey}: expected ${ROUND_COUNT} sequential runs, got ${count}`);
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    byRound
  };
}

function runMetrics(sequential) {
  return {
    p50Ms: sequential.p50Ms,
    p95Ms: sequential.p95Ms,
    p99Ms: sequential.p99Ms,
    meanMs: sequential.meanMs,
    translationsPerSecond: sequential.translationsPerSecond,
    wordsPerSecond: sequential.wordsPerSecond,
    wallClockMs: sequential.wallClockMs,
    engineSetupMs: sequential.engineSetupMs,
    firstTranslationMs: sequential.firstTranslationMs,
    buckets: sequential.buckets || null
  };
}

function summarizeAcrossRuns(values) {
  return {
    mean: mean(values),
    median: median(values),
    stddev: standardDeviation(values),
    min: values.length ? Math.min(...values) : 0,
    max: values.length ? Math.max(...values) : 0
  };
}

function ratios(numerators, denominators) {
  return numerators.map((value, index) => {
    const denom = denominators[index];
    return denom > 0 ? value / denom : Infinity;
  });
}

function wins(left, right) {
  return left.filter((value, index) => value < right[index]).length;
}

export function classifyNative(nativeRuns, chromeRuns) {
  const nativeP50 = nativeRuns.map((run) => run.p50Ms);
  const nativeP95 = nativeRuns.map((run) => run.p95Ms);
  const nativeP99 = nativeRuns.map((run) => run.p99Ms);
  const nativeTps = nativeRuns.map((run) => run.translationsPerSecond);
  const chromeP50 = chromeRuns.map((run) => run.p50Ms);
  const chromeP95 = chromeRuns.map((run) => run.p95Ms);
  const chromeP99 = chromeRuns.map((run) => run.p99Ms);

  const p95Pass = nativeP95.every((value) => value <= SUBTITLE_P95_MS);
  const p99Pass = nativeP99.every((value) => value <= SUBTITLE_P99_MS);
  const tpsPass = nativeTps.every((value) => value >= SUBTITLE_TPS);
  const absolutePass = p95Pass && p99Pass && tpsPass;

  const medianNativeP50 = median(nativeP50);
  const medianChromeP50 = median(chromeP50);
  const medianNativeP95 = median(nativeP95);
  const medianChromeP95 = median(chromeP95);

  const p50Wins = wins(nativeP50, chromeP50);
  const p95Wins = wins(nativeP95, chromeP95);
  const p99Wins = wins(nativeP99, chromeP99);

  const strictWin =
    medianNativeP50 <= medianChromeP50 &&
    medianNativeP95 <= medianChromeP95 &&
    p95Wins >= 5;

  const equivalent = absolutePass && medianNativeP95 <= medianChromeP95 * EQUIVALENCE_P95_RATIO;

  let decision = "NOT VIABLE";
  if (absolutePass && strictWin) {
    decision = "FASTER THAN CHROME";
  } else if (equivalent) {
    decision = "EQUIVALENT TO CHROME";
  } else if (absolutePass) {
    decision = "SLOWER BUT VIABLE";
  }

  return {
    absolutePass,
    p95Pass,
    p99Pass,
    tpsPass,
    strictWin,
    equivalent,
    p50Wins,
    p95Wins,
    p99Wins,
    medianP50Ratio: median(ratios(nativeP50, chromeP50)),
    medianP95Ratio: median(ratios(nativeP95, chromeP95)),
    medianP99Ratio: median(ratios(nativeP99, chromeP99)),
    meanP50Ratio: mean(ratios(nativeP50, chromeP50)),
    meanP95Ratio: mean(ratios(nativeP95, chromeP95)),
    meanP99Ratio: mean(ratios(nativeP99, chromeP99)),
    minP95Ratio: Math.min(...ratios(nativeP95, chromeP95)),
    maxP95Ratio: Math.max(...ratios(nativeP95, chromeP95)),
    roundRatios: nativeRuns.map((run, index) => ({
      round: index + 1,
      p50: chromeP50[index] > 0 ? nativeP50[index] / chromeP50[index] : Infinity,
      p95: chromeP95[index] > 0 ? nativeP95[index] / chromeP95[index] : Infinity,
      p99: chromeP99[index] > 0 ? nativeP99[index] / chromeP99[index] : Infinity
    })),
    decision
  };
}

export function classifyWasm(wasmRuns) {
  const viable = wasmRuns.every(
    (run) => run.p95Ms <= SUBTITLE_P95_MS && run.p99Ms <= SUBTITLE_P99_MS
  );
  return {
    viable,
    decision: viable ? "VIABLE" : "NOT VIABLE",
    p95Pass: wasmRuns.every((run) => run.p95Ms <= SUBTITLE_P95_MS),
    p99Pass: wasmRuns.every((run) => run.p99Ms <= SUBTITLE_P99_MS)
  };
}

function pooledStats(payloads) {
  const samples = payloads.flatMap((payload) => requireSequential(payload).samples);
  const wallClockMs = payloads.reduce(
    (sum, payload) => sum + requireSequential(payload).wallClockMs,
    0
  );
  return summarizeLatencies(samples, wallClockMs);
}

function bucketMedianP95(runs, bucket) {
  const values = runs
    .map((run) => run.buckets?.[bucket]?.p95)
    .filter((value) => typeof value === "number");
  return median(values);
}

function engineAggregate(payloads) {
  const sequentials = payloads.map(requireSequential);
  const metricNames = [
    "p50Ms",
    "p95Ms",
    "p99Ms",
    "meanMs",
    "translationsPerSecond",
    "wordsPerSecond",
    "engineSetupMs",
    "firstTranslationMs",
    "wallClockMs"
  ];
  const acrossRuns = {};
  for (const name of metricNames) {
    acrossRuns[name] = summarizeAcrossRuns(sequentials.map((run) => run[name]));
  }
  return {
    runs: sequentials.map((sequential, index) => ({
      round: sequential.round ?? index + 1,
      ...runMetrics(sequential)
    })),
    acrossRuns,
    pooled: pooledStats(payloads),
    buckets: {
      tiny: { p95: bucketMedianP95(sequentials, "tiny") },
      short: { p95: bucketMedianP95(sequentials, "short") },
      medium: { p95: bucketMedianP95(sequentials, "medium") },
      long: { p95: bucketMedianP95(sequentials, "long") }
    }
  };
}

export function aggregateValidatedSet(payloadsByFile, corporaByRound = {}) {
  const complete = validateCompleteSet(payloadsByFile, corporaByRound);
  if (!complete.valid) {
    const error = new Error(`Invalid six-round set:\n${complete.errors.join("\n")}`);
    error.details = complete.errors;
    throw error;
  }

  const byEngine = {
    chrome: [],
    wasm: [],
    native: []
  };
  for (let round = 1; round <= ROUND_COUNT; round += 1) {
    for (const engineKey of Object.keys(byEngine)) {
      byEngine[engineKey].push(complete.byRound[round][engineKey]);
    }
  }

  const engines = {
    chrome: engineAggregate(byEngine.chrome),
    wasm: engineAggregate(byEngine.wasm),
    native: engineAggregate(byEngine.native)
  };

  const nativeVsChrome = classifyNative(engines.native.runs, engines.chrome.runs);
  const wasmVsChrome = {
    p50Wins: wins(
      engines.wasm.runs.map((run) => run.p50Ms),
      engines.chrome.runs.map((run) => run.p50Ms)
    ),
    p95Wins: wins(
      engines.wasm.runs.map((run) => run.p95Ms),
      engines.chrome.runs.map((run) => run.p95Ms)
    ),
    p99Wins: wins(
      engines.wasm.runs.map((run) => run.p99Ms),
      engines.chrome.runs.map((run) => run.p99Ms)
    ),
    medianP50Ratio: median(
      ratios(
        engines.wasm.runs.map((run) => run.p50Ms),
        engines.chrome.runs.map((run) => run.p50Ms)
      )
    ),
    medianP95Ratio: median(
      ratios(
        engines.wasm.runs.map((run) => run.p95Ms),
        engines.chrome.runs.map((run) => run.p95Ms)
      )
    ),
    medianP99Ratio: median(
      ratios(
        engines.wasm.runs.map((run) => run.p99Ms),
        engines.chrome.runs.map((run) => run.p99Ms)
      )
    ),
    roundRatios: engines.wasm.runs.map((run, index) => ({
      round: index + 1,
      p50: engines.chrome.runs[index].p50Ms > 0 ? run.p50Ms / engines.chrome.runs[index].p50Ms : Infinity,
      p95: engines.chrome.runs[index].p95Ms > 0 ? run.p95Ms / engines.chrome.runs[index].p95Ms : Infinity,
      p99: engines.chrome.runs[index].p99Ms > 0 ? run.p99Ms / engines.chrome.runs[index].p99Ms : Infinity
    }))
  };

  return {
    roundsCompleted: ROUND_COUNT,
    samplesPerEnginePerRound: 500,
    totalMeasuredSamplesPerEngine: ROUND_COUNT * 500,
    engines,
    nativeVsChrome,
    wasmVsChrome,
    wasm: classifyWasm(engines.wasm.runs)
  };
}

export { ENGINE_IDS, ENGINE_FILES, ROUND_COUNT, expectedRunFiles, padRound, runFileName, engineKeyFromId };
