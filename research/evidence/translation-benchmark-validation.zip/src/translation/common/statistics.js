/**
 * Latency / throughput statistics for the architecture spike.
 * Pure functions so Node tests and browser benches share the same math.
 */

export function percentile(sorted, p) {
  if (!sorted.length) {
    return 0;
  }
  if (sorted.length === 1) {
    return sorted[0];
  }
  const index = (p / 100) * (sorted.length - 1);
  const lower = Math.floor(index);
  const upper = Math.ceil(index);
  if (lower === upper) {
    return sorted[lower];
  }
  const weight = index - lower;
  return sorted[lower] * (1 - weight) + sorted[upper] * weight;
}

export function mean(values) {
  if (!values.length) {
    return 0;
  }
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

export function median(values) {
  if (!values.length) {
    return 0;
  }
  const sorted = [...values].sort((a, b) => a - b);
  return percentile(sorted, 50);
}

export function standardDeviation(values) {
  if (values.length < 2) {
    return 0;
  }
  const avg = mean(values);
  const variance =
    values.reduce((sum, value) => sum + (value - avg) ** 2, 0) / (values.length - 1);
  return Math.sqrt(variance);
}

export function summarizeNumeric(values) {
  const sorted = [...values].sort((a, b) => a - b);
  return {
    mean: mean(sorted),
    median: percentile(sorted, 50),
    stddev: standardDeviation(sorted),
    min: sorted[0] ?? 0,
    max: sorted.at(-1) ?? 0
  };
}

export function wordCount(text) {
  if (!text || typeof text !== "string") {
    return 0;
  }
  return text.trim().split(/\s+/).filter(Boolean).length;
}

export function characterCount(text) {
  if (!text || typeof text !== "string") {
    return 0;
  }
  return Array.from(text).length;
}

export function summarizeLatencies(samples, wallClockMs) {
  if (typeof wallClockMs !== "number" || !Number.isFinite(wallClockMs) || wallClockMs < 0) {
    throw new Error("summarizeLatencies requires a finite wallClockMs; do not sum per-item totalMs");
  }

  const totalMs = samples.map((sample) => sample.totalMs);
  const inferenceMs = samples.map((sample) => sample.inferenceMs);
  const queueMs = samples.map((sample) => sample.queueMs);
  const sortedTotal = [...totalMs].sort((a, b) => a - b);
  const sortedInference = [...inferenceMs].sort((a, b) => a - b);
  const sortedQueue = [...queueMs].sort((a, b) => a - b);

  const words = samples.reduce((sum, sample) => sum + (sample.words || 0), 0);
  const characters = samples.reduce(
    (sum, sample) => sum + (sample.characters || 0),
    0
  );
  const elapsedSeconds = wallClockMs / 1000;

  return {
    count: samples.length,
    wallClockMs,
    meanMs: mean(totalMs),
    p50Ms: percentile(sortedTotal, 50),
    p75Ms: percentile(sortedTotal, 75),
    p90Ms: percentile(sortedTotal, 90),
    p95Ms: percentile(sortedTotal, 95),
    p99Ms: percentile(sortedTotal, 99),
    minMs: sortedTotal[0] ?? 0,
    maxMs: sortedTotal.at(-1) ?? 0,
    meanInferenceMs: mean(inferenceMs),
    p50InferenceMs: percentile(sortedInference, 50),
    p95InferenceMs: percentile(sortedInference, 95),
    meanQueueMs: mean(queueMs),
    p50QueueMs: percentile(sortedQueue, 50),
    p95QueueMs: percentile(sortedQueue, 95),
    translationsPerSecond: elapsedSeconds > 0 ? samples.length / elapsedSeconds : 0,
    wordsPerSecond: elapsedSeconds > 0 ? words / elapsedSeconds : 0,
    charactersPerSecond: elapsedSeconds > 0 ? characters / elapsedSeconds : 0,
    totalWords: words,
    totalCharacters: characters,
    elapsedMs: wallClockMs
  };
}

export function summarizeBuckets(records) {
  const names = ["tiny", "short", "medium", "long"];
  const out = {};
  for (const name of names) {
    const subset = records.filter((record) => record.bucket === name);
    const totals = subset.map((record) => record.totalMs).sort((a, b) => a - b);
    out[name] = {
      count: subset.length,
      mean: mean(totals),
      p50: percentile(totals, 50),
      p90: percentile(totals, 90),
      p95: percentile(totals, 95),
      p99: percentile(totals, 99),
      min: totals[0] ?? 0,
      max: totals.at(-1) ?? 0
    };
  }
  return out;
}

export function classifyMozillaVsChrome(mozilla, chrome) {
  const p50Ratio = chrome.p50Ms > 0 ? mozilla.p50Ms / chrome.p50Ms : Infinity;
  const p95Ratio = chrome.p95Ms > 0 ? mozilla.p95Ms / chrome.p95Ms : Infinity;

  const absolutePass = mozilla.p95Ms <= 150 && mozilla.p99Ms <= 250;
  const equivalent =
    mozilla.p50Ms <= chrome.p50Ms * 1.05 && mozilla.p95Ms <= chrome.p95Ms * 1.1;
  const mozillaFaster = mozilla.p50Ms < chrome.p50Ms && mozilla.p95Ms < chrome.p95Ms;
  const strictWin = mozilla.p50Ms <= chrome.p50Ms && mozilla.p95Ms <= chrome.p95Ms;
  const throughputPass = mozilla.translationsPerSecond >= 10;

  let winner = "EQUIVALENT";
  let translationClass = "VIABLE";

  if (!absolutePass) {
    winner = "FAIL";
    translationClass = "NOT VIABLE";
  } else if (mozillaFaster) {
    winner = "MOZILLA";
    translationClass = "VIABLE";
  } else if (equivalent) {
    winner = "EQUIVALENT";
    translationClass = "VIABLE";
  } else if (mozilla.p95Ms <= 150) {
    winner = "CHROME";
    translationClass = "VIABLE";
  } else {
    winner = "FAIL";
    translationClass = "NOT VIABLE";
  }

  return {
    p50Ratio,
    p95Ratio,
    absolutePass,
    equivalent,
    mozillaFaster,
    strictWin,
    throughputPass,
    winner,
    translationClass
  };
}

export function classifyBucket(text) {
  const words = wordCount(text);
  if (words >= 1 && words <= 4) {
    return "tiny";
  }
  if (words >= 5 && words <= 10) {
    return "short";
  }
  if (words >= 11 && words <= 20) {
    return "medium";
  }
  if (words >= 21 && words <= 35) {
    return "long";
  }
  return "out-of-range";
}
