import {
  characterCount,
  classifyBucket,
  summarizeBuckets,
  summarizeLatencies,
  wordCount
} from "./statistics.js";

export const WARMUP_COUNT = 20;
export const SEQUENTIAL_COUNT = 500;

export const BURST_SIZES = [2, 4, 8];
export const BATCH_SIZES = [2, 4, 8];

export function warmupSentences(corpus) {
  if (!corpus || !Array.isArray(corpus.warmup)) {
    throw new Error("corpus.warmup is required");
  }
  if (corpus.warmup.length !== WARMUP_COUNT) {
    throw new Error(`corpus.warmup must have exactly ${WARMUP_COUNT} sentences`);
  }
  return corpus.warmup;
}

export function firstTranslationProbe(corpus) {
  if (!corpus?.firstTranslationProbe) {
    throw new Error("corpus.firstTranslationProbe is required");
  }
  return corpus.firstTranslationProbe;
}

export function countUnits(text) {
  return {
    words: wordCount(text),
    characters: characterCount(text),
    bucket: classifyBucket(text)
  };
}

export function buildTranslationRecord({
  engine,
  pair,
  id,
  text,
  translation,
  queueMs,
  inferenceMs,
  totalMs
}) {
  const units = countUnits(text);
  return {
    engine,
    pair,
    id,
    source: text,
    translation,
    characters: units.characters,
    words: units.words,
    bucket: units.bucket,
    queueMs,
    inferenceMs,
    totalMs
  };
}

export async function runSequential({
  items,
  translate,
  engine,
  pair,
  onProgress
}) {
  const records = [];
  const runStartedAt = performance.now();
  for (let i = 0; i < items.length; i += 1) {
    const text = items[i];
    const queuedAt = performance.now();
    const startedAt = performance.now();
    const result = await translate(text);
    const finishedAt = performance.now();
    const inferenceMs =
      typeof result?.inferenceMs === "number"
        ? result.inferenceMs
        : finishedAt - startedAt;
    const totalMs = finishedAt - queuedAt;
    const queueMs = Math.max(0, totalMs - inferenceMs);
    const record = buildTranslationRecord({
      engine,
      pair,
      id: i,
      text,
      translation: result?.translation ?? "",
      queueMs,
      inferenceMs,
      totalMs
    });
    records.push(record);
    onProgress?.(i + 1, items.length, record);
  }
  return {
    records,
    wallClockMs: performance.now() - runStartedAt
  };
}

export async function runBurst({
  items,
  translate,
  engine,
  pair,
  concurrency,
  onProgress
}) {
  const records = [];
  let nextIndex = 0;
  const runStartedAt = performance.now();

  async function worker() {
    while (nextIndex < items.length) {
      const id = nextIndex;
      nextIndex += 1;
      const text = items[id];
      const queuedAt = performance.now();
      const result = await translate(text);
      const finishedAt = performance.now();
      const inferenceMs =
        typeof result?.inferenceMs === "number"
          ? result.inferenceMs
          : finishedAt - queuedAt;
      const totalMs = finishedAt - queuedAt;
      const queueMs = Math.max(0, totalMs - inferenceMs);
      const record = buildTranslationRecord({
        engine,
        pair,
        id,
        text,
        translation: result?.translation ?? "",
        queueMs,
        inferenceMs,
        totalMs
      });
      records.push(record);
      onProgress?.(records.length, items.length, record);
    }
  }

  await Promise.all(
    Array.from({ length: Math.min(concurrency, items.length) }, () => worker())
  );
  records.sort((a, b) => a.id - b.id);
  return {
    records,
    wallClockMs: performance.now() - runStartedAt
  };
}

export async function runMicroBatch({
  items,
  translateBatch,
  engine,
  pair,
  batchSize,
  onProgress
}) {
  const records = [];
  const runStartedAt = performance.now();
  for (let start = 0; start < items.length; start += batchSize) {
    const slice = items.slice(start, start + batchSize);
    const queuedAt = performance.now();
    const results = await translateBatch(slice);
    const finishedAt = performance.now();
    const batchTotalMs = finishedAt - queuedAt;
    slice.forEach((text, offset) => {
      const result = results[offset] ?? {};
      const inferenceMs =
        typeof result.inferenceMs === "number"
          ? result.inferenceMs
          : batchTotalMs;
      const record = buildTranslationRecord({
        engine,
        pair,
        id: start + offset,
        text,
        translation: result.translation ?? "",
        queueMs: 0,
        inferenceMs,
        totalMs: batchTotalMs
      });
      records.push(record);
    });
    onProgress?.(records.length, items.length);
  }
  return {
    records,
    wallClockMs: performance.now() - runStartedAt
  };
}

export function summarizeRun({
  engine,
  version,
  languagePair,
  run,
  round = null,
  seed = null,
  corpusSha256 = null,
  mode,
  environment,
  model,
  engineSetupMs,
  firstTranslationMs,
  wallClockMs,
  records,
  jsHeapUsedMb = null,
  memory = null
}) {
  if (typeof wallClockMs !== "number" || !Number.isFinite(wallClockMs)) {
    throw new Error("summarizeRun requires wallClockMs");
  }
  const stats = summarizeLatencies(records, wallClockMs);
  const buckets = mode === "sequential" ? summarizeBuckets(records) : null;
  return {
    engine,
    version,
    languagePair,
    run,
    round,
    seed,
    corpusSha256,
    mode,
    environment,
    model,
    engineSetupMs,
    firstTranslationMs,
    wallClockMs,
    initializationMs: engineSetupMs,
    translations: records.length,
    p50Ms: stats.p50Ms,
    p90Ms: stats.p90Ms,
    p95Ms: stats.p95Ms,
    p99Ms: stats.p99Ms,
    meanMs: stats.meanMs,
    minMs: stats.minMs,
    maxMs: stats.maxMs,
    translationsPerSecond: stats.translationsPerSecond,
    wordsPerSecond: stats.wordsPerSecond,
    charactersPerSecond: stats.charactersPerSecond,
    peakMemoryMb: null,
    jsHeapUsedMb,
    memory,
    buckets,
    stats,
    samples: records
  };
}

export function filterByBucket(records, bucket) {
  return records.filter((record) => record.bucket === bucket);
}

export function realisticSubtitleSchedule(count) {
  const timestamps = [];
  let t = 0;
  for (let i = 0; i < count; i += 1) {
    timestamps.push(Math.round(t));
    t += 1400 + (i % 5) * 300 + ((i * 97) % 400);
  }
  return timestamps;
}

export function playbackWorkload(corpus) {
  const short = corpus.short ?? corpus.items?.filter((item) => classifyBucket(item) === "short") ?? [];
  const all = corpus.items ?? [...(corpus.tiny || []), ...(corpus.short || []), ...(corpus.medium || []), ...(corpus.long || [])];

  const normal = [];
  let t = 0;
  for (let i = 0; i < 400; i += 1) {
    normal.push({
      atMs: t,
      text: short[i % short.length] || all[i % all.length]
    });
    t += 1500;
  }

  const burst = [];
  let burstT = 0;
  for (let i = 0; i < 90; i += 1) {
    burst.push({
      atMs: burstT,
      text: short[(i * 3) % short.length] || all[i % all.length]
    });
    burst.push({
      atMs: burstT + 160,
      text: short[(i * 3 + 1) % short.length] || all[i % all.length]
    });
    burst.push({
      atMs: burstT + 330,
      text: short[(i * 3 + 2) % short.length] || all[i % all.length]
    });
    burstT += 4000;
  }

  const heavy = [];
  let heavyT = 0;
  for (let i = 0; i < 240; i += 1) {
    heavy.push({
      atMs: heavyT,
      text: short[i % short.length] || all[i % all.length]
    });
    heavyT += 500;
  }

  return { normal, burst, heavy };
}
