import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const schemaPath = join(
  dirname(fileURLToPath(import.meta.url)),
  "result-schema.json"
);

export function loadResultSchema() {
  return JSON.parse(readFileSync(schemaPath, "utf8"));
}

function typeOf(value) {
  if (value === null) {
    return "null";
  }
  if (Array.isArray(value)) {
    return "array";
  }
  return typeof value;
}

function matchesType(value, schemaType) {
  const types = Array.isArray(schemaType) ? schemaType : [schemaType];
  return types.some((type) => {
    if (type === "integer") {
      return Number.isInteger(value);
    }
    if (type === "number") {
      return typeof value === "number" && Number.isFinite(value);
    }
    return typeOf(value) === type;
  });
}

function validateAgainst(schema, value, path, errors) {
  if (schema.enum && !schema.enum.includes(value)) {
    errors.push(`${path}: expected one of ${schema.enum.join(", ")}, got ${JSON.stringify(value)}`);
    return;
  }

  if (schema.type && !matchesType(value, schema.type)) {
    errors.push(`${path}: expected ${schema.type}, got ${typeOf(value)}`);
    return;
  }

  if (schema.minLength && typeof value === "string" && value.length < schema.minLength) {
    errors.push(`${path}: length ${value.length} is below minLength ${schema.minLength}`);
  }
  if (schema.maxLength && typeof value === "string" && value.length > schema.maxLength) {
    errors.push(`${path}: length ${value.length} is above maxLength ${schema.maxLength}`);
  }

  if (schema.type === "integer" || schema.type === "number") {
    if (typeof schema.minimum === "number" && value < schema.minimum) {
      errors.push(`${path}: ${value} is below minimum ${schema.minimum}`);
    }
  }

  if (schema.type === "object" && value && typeof value === "object") {
    for (const key of schema.required || []) {
      if (!(key in value)) {
        errors.push(`${path}: missing required property "${key}"`);
      }
    }
    for (const [key, child] of Object.entries(schema.properties || {})) {
      if (key in value) {
        validateAgainst(child, value[key], `${path}.${key}`, errors);
      }
    }
  }
}

export function sequentialResult(payload) {
  if (!payload) {
    return null;
  }
  if (Array.isArray(payload.results)) {
    return payload.results.find((result) => result.mode === "sequential") || payload.results[0];
  }
  if (payload.mode === "sequential" || Array.isArray(payload.samples)) {
    return payload;
  }
  return null;
}

export function validateBenchmarkResult(result) {
  const schema = loadResultSchema();
  const errors = [];
  validateAgainst(schema, result, "$", errors);
  return {
    valid: errors.length === 0,
    errors
  };
}

export function assertValidBenchmarkResult(result) {
  const { valid, errors } = validateBenchmarkResult(result);
  if (!valid) {
    throw new Error(`Invalid benchmark result:\n${errors.join("\n")}`);
  }
  return true;
}

export function validateMeasuredRun(payload, expected) {
  const errors = [];
  if (!payload || typeof payload !== "object") {
    return { valid: false, errors: ["payload is missing"] };
  }

  if (payload.engine !== expected.engine) {
    errors.push(`engine: expected ${expected.engine}, got ${JSON.stringify(payload.engine)}`);
  }
  if (payload.run !== expected.run) {
    errors.push(`run: expected ${expected.run}, got ${JSON.stringify(payload.run)}`);
  }
  if (payload.round !== expected.round) {
    errors.push(`round: expected ${expected.round}, got ${JSON.stringify(payload.round)}`);
  }
  if (expected.seed != null && payload.seed !== expected.seed) {
    errors.push(`seed: expected ${expected.seed}, got ${JSON.stringify(payload.seed)}`);
  }
  if (payload.corpusSha256 !== expected.corpusSha256) {
    errors.push(
      `corpusSha256: expected ${expected.corpusSha256}, got ${JSON.stringify(payload.corpusSha256)}`
    );
  }

  const sequential = sequentialResult(payload);
  if (!sequential) {
    errors.push("missing sequential result");
    return { valid: false, errors };
  }

  const schemaCheck = validateBenchmarkResult(sequential);
  if (!schemaCheck.valid) {
    errors.push(...schemaCheck.errors.map((error) => `sequential ${error}`));
  }

  const samples = sequential.samples || [];
  const expectedCount = expected.sequentialCount ?? 500;
  if (samples.length !== expectedCount) {
    errors.push(`sequential sample count: expected ${expectedCount}, got ${samples.length}`);
  }
  for (let i = 0; i < Math.min(samples.length, expectedCount); i += 1) {
    if (samples[i].id !== i) {
      errors.push(`sample ${i}: id is ${samples[i].id}`);
      break;
    }
    if (typeof samples[i].source !== "string" || samples[i].source.length === 0) {
      errors.push(`sample ${i}: missing source`);
      break;
    }
  }

  if (expected.items) {
    for (let i = 0; i < Math.min(samples.length, expected.items.length); i += 1) {
      if (samples[i].source !== expected.items[i]) {
        errors.push(
          `sample ${i} source mismatch: expected ${JSON.stringify(expected.items[i])}, got ${JSON.stringify(samples[i].source)}`
        );
        break;
      }
    }
  }

  if (typeof sequential.wallClockMs !== "number") {
    errors.push("sequential wallClockMs missing");
  }
  if (typeof sequential.engineSetupMs !== "number") {
    errors.push("sequential engineSetupMs missing");
  }
  if (typeof sequential.firstTranslationMs !== "number") {
    errors.push("sequential firstTranslationMs missing");
  }

  return {
    valid: errors.length === 0,
    errors,
    sequential
  };
}

export function assertMeasuredRun(payload, expected) {
  const { valid, errors } = validateMeasuredRun(payload, expected);
  if (!valid) {
    throw new Error(`Invalid measured run:\n${errors.join("\n")}`);
  }
  return true;
}
