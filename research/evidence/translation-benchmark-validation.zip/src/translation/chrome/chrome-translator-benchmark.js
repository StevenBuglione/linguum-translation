import {
  BURST_SIZES,
  firstTranslationProbe,
  runBurst,
  runSequential,
  summarizeRun,
  warmupSentences
} from "../common/benchmark.js";

export async function assertChromeTranslatorAvailable() {
  if (!("Translator" in self)) {
    throw new Error("Chrome Translator API unavailable");
  }
}

export async function createChromeTranslator(
  sourceLanguage,
  targetLanguage,
  { requireAvailable = false, abortOnDownload = false } = {}
) {
  await assertChromeTranslatorAvailable();
  let availability = await Translator.availability({
    sourceLanguage,
    targetLanguage
  });
  if (requireAvailable) {
    for (let i = 0; i < 40 && availability !== "available" && availability !== "unavailable"; i += 1) {
      await new Promise((resolve) => setTimeout(resolve, 250));
      availability = await Translator.availability({ sourceLanguage, targetLanguage });
    }
  }
  if (availability === "unavailable") {
    throw new Error("Chrome Translator language pack unavailable for es→en");
  }
  if (requireAvailable && availability !== "available") {
    throw new Error(
      `Chrome language pack is not locally available (availability=${availability}). Redo preflight.`
    );
  }

  let downloadStarted = false;
  const translator = await Translator.create({
    sourceLanguage,
    targetLanguage,
    monitor(monitor) {
      monitor.addEventListener("downloadprogress", (event) => {
        const loaded = Number(event.loaded);
        // Chrome 151 fires downloadprogress at 1.0 for an already-cached pack.
        const downloading = Number.isFinite(loaded) && loaded > 0 && loaded < 1;
        console.log("Chrome language pack downloadprogress", loaded);
        if (downloading) {
          downloadStarted = true;
          if (abortOnDownload) {
            throw new Error("Chrome began downloading a language pack during a measured round");
          }
        }
      });
    }
  });

  if (abortOnDownload && downloadStarted) {
    throw new Error("Chrome began downloading a language pack during a measured round");
  }

  return { translator, availability, downloadStarted };
}

function memoryInfo() {
  const mem = performance.memory;
  const jsHeapUsedMb = mem
    ? Number((mem.usedJSHeapSize / 1024 / 1024).toFixed(2))
    : null;
  return {
    jsHeapUsedMb,
    memory: {
      type: "js-heap",
      jsHeapUsedMb,
      informational: true
    }
  };
}

export async function runChromePreflight({
  sourceLanguage = "es",
  targetLanguage = "en",
  onLog = () => {}
} = {}) {
  onLog("Checking Chrome Translator API availability…");
  const before = await Translator.availability({ sourceLanguage, targetLanguage });
  onLog(`availability before create: ${before}`);
  if (before === "unavailable") {
    throw new Error("Chrome Translator language pack unavailable for es→en");
  }

  const { translator, availability, downloadStarted } = await createChromeTranslator(
    sourceLanguage,
    targetLanguage,
    { requireAvailable: false, abortOnDownload: false }
  );
  const probe = "Esta oración se usa únicamente para medir la primera traducción.";
  const translation = await translator.translate(probe);
  const after = await Translator.availability({ sourceLanguage, targetLanguage });
  if (typeof translator.destroy === "function") {
    translator.destroy();
  }
  if (after !== "available") {
    throw new Error(`Chrome pack still not available after preflight (availability=${after})`);
  }
  return {
    ok: true,
    availabilityBefore: before,
    availabilityAfter: after,
    availability,
    downloadStarted,
    probe,
    translation,
    userAgent: navigator.userAgent,
    chromeVersion: navigator.userAgentData?.brands?.map((b) => `${b.brand} ${b.version}`).join(", ") || navigator.userAgent,
    preparedAt: new Date().toISOString()
  };
}

export async function runChromeBenchmark({
  corpus,
  environment,
  run = 1,
  round = null,
  seed = null,
  corpusSha256 = null,
  sequentialOnly = true,
  sourceLanguage = "es",
  targetLanguage = "en",
  onLog = () => {},
  onProgress = () => {}
}) {
  const pair = `${sourceLanguage}-${targetLanguage}`;
  const meta = { round: round ?? run, seed, corpusSha256 };
  onLog("Waiting briefly for Translator API to initialize in this profile…");
  await new Promise((resolve) => setTimeout(resolve, 1500));
  onLog("Waiting for Translator API to initialize in this profile…");
  await new Promise((resolve) => setTimeout(resolve, 1500));
  onLog("Checking Chrome Translator API…");
  const started = performance.now();
  const { translator, availability } = await createChromeTranslator(
    sourceLanguage,
    targetLanguage,
    { requireAvailable: true, abortOnDownload: true }
  );
  const engineSetupMs = performance.now() - started;
  onLog(`availability=${availability}; engineSetup=${engineSetupMs.toFixed(1)} ms`);

  const probe = firstTranslationProbe(corpus);
  const firstStarted = performance.now();
  await translator.translate(probe);
  const firstTranslationMs = performance.now() - firstStarted;
  onLog(`firstTranslation=${firstTranslationMs.toFixed(1)} ms`);

  onLog("Warmup: 20 canonical sentences (discarded, no overlap with measured corpus)");
  for (const sentence of warmupSentences(corpus)) {
    await translator.translate(sentence);
  }

  const translate = async (text) => {
    const startedAt = performance.now();
    const translation = await translator.translate(text);
    return {
      translation,
      inferenceMs: performance.now() - startedAt
    };
  };

  const model = {
    name: "chrome-translator-language-pack",
    version: availability,
    bytes: 0
  };
  const heap = memoryInfo();
  const results = [];

  onLog("Sequential: 500 unique strings");
  const sequential = await runSequential({
    items: corpus.items,
    engine: "chrome-translator-api",
    pair,
    translate,
    onProgress: (done, total) => onProgress("sequential", done, total)
  });
  results.push(
    summarizeRun({
      engine: "chrome-translator-api",
      version: navigator.userAgent,
      languagePair: pair,
      run,
      ...meta,
      mode: "sequential",
      environment,
      model,
      engineSetupMs,
      firstTranslationMs,
      wallClockMs: sequential.wallClockMs,
      records: sequential.records,
      ...heap
    })
  );

  if (!sequentialOnly) {
    for (const concurrency of BURST_SIZES) {
      onLog(`Burst concurrency=${concurrency}`);
      const burst = await runBurst({
        items: corpus.items,
        engine: "chrome-translator-api",
        pair,
        concurrency,
        translate,
        onProgress: (done, total) => onProgress(`burst-${concurrency}`, done, total)
      });
      results.push(
        summarizeRun({
          engine: "chrome-translator-api",
          version: navigator.userAgent,
          languagePair: pair,
          run,
          ...meta,
          mode: `burst-${concurrency}`,
          environment,
          model,
          engineSetupMs,
          firstTranslationMs,
          wallClockMs: burst.wallClockMs,
          records: burst.records,
          ...heap
        })
      );
    }
  }

  if (typeof translator.destroy === "function") {
    translator.destroy();
  }

  return {
    engine: "chrome-translator-api",
    run,
    round: meta.round,
    seed: meta.seed,
    corpusSha256: meta.corpusSha256,
    availability,
    engineSetupMs,
    firstTranslationMs,
    wallClockMs: sequential.wallClockMs,
    model,
    results
  };
}
