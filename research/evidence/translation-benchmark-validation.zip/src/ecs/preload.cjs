"use strict";

const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("spike", {
  mode: () => ipcRenderer.invoke("spike:mode"),
  diagnostics: () => ipcRenderer.invoke("spike:diagnostics"),
  services: () => ipcRenderer.invoke("spike:services"),
  openService: (id) => ipcRenderer.invoke("spike:open-service", id),
  closeService: () => ipcRenderer.invoke("spike:close-service"),
  saveStreamingResult: (payload) => ipcRenderer.invoke("spike:save-streaming", payload),
  saveResult: (fileName, payload) => ipcRenderer.invoke("spike:save-result", fileName, payload),
  playbackQuality: () => ipcRenderer.invoke("spike:playback-quality"),
  startPlaybackTranslation: (serviceId, workload) =>
    ipcRenderer.invoke("spike:playback-translation", { serviceId, workload }),
  stopPlaybackTranslation: () => ipcRenderer.invoke("spike:stop-playback-translation"),
  origin: () => ipcRenderer.invoke("spike:origin"),
  onLog: (callback) => {
    const listener = (_event, message) => callback(message);
    ipcRenderer.on("spike:log", listener);
    return () => ipcRenderer.removeListener("spike:log", listener);
  }
});
