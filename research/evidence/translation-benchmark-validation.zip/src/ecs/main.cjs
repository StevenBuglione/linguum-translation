"use strict";

const { app, BrowserWindow, ipcMain, components, session } = require("electron");
const path = require("node:path");
const fs = require("node:fs");
const {
  parseArg,
  hasFlag,
  collectMachine,
  componentsStatus,
  writeJson,
  repoRoot,
  sessionKind,
  safeResultsFile
} = require("./diagnostics.cjs");
const { createStaticServer } = require("./static-server.cjs");
const { listServices, getService, emptyChecklist } = require("./services.cjs");

const MODE = parseArg("mode", "harness");
const SERVICE_ID = parseArg("service", null);
const RUN = Number(parseArg("run", "1"));
const ROUND = Number(parseArg("round", String(RUN)));
const SEED = parseArg("seed", null);
const CORPUS = parseArg("corpus", null);
const OUTPUT = parseArg("output", "runs/round-01-wasm.json");
const CORPUS_SHA = parseArg("corpusSha256", null);
const SEQUENTIAL_ONLY = parseArg("sequentialOnly", "1");

function toUrlPath(value) {
  const normalized = String(value).replaceAll("\\", "/");
  if (/^https?:\/\//i.test(normalized)) {
    return normalized;
  }
  return normalized.startsWith("/") ? normalized : `/${normalized}`;
}

let mainWindow = null;
let streamingWindow = null;
let origin = null;
let machine = null;
let widevine = null;
let playbackTimer = null;

const WINDOW_PREFS = {
  nodeIntegration: false,
  contextIsolation: true,
  sandbox: true,
  webSecurity: true
};

function logToHarness(message) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send("spike:log", message);
  }
  console.log(message);
}

function resultsPath(name) {
  const root = path.join(repoRoot(), "results");
  const relative = String(name).replace(/^[/\\]+/, "");
  const resolved = path.resolve(root, relative);
  const rel = path.relative(root, resolved);
  if (!rel || rel.startsWith("..") || path.isAbsolute(rel)) {
    throw new Error(`refusing to write outside results/: ${name}`);
  }
  return resolved;
}

async function waitForWidevine() {
  if (!components || typeof components.whenReady !== "function") {
    throw new Error("ECS components API is missing. Is this CastLabs Electron?");
  }
  if (components.WIDEVINE_CDM_ID) {
    await components.whenReady([components.WIDEVINE_CDM_ID]);
  } else {
    await components.whenReady();
  }
  return componentsStatus(components);
}

function createHarnessWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 900,
    autoHideMenuBar: true,
    webPreferences: {
      ...WINDOW_PREFS,
      preload: path.join(__dirname, "preload.cjs")
    }
  });
  mainWindow.loadURL(`${origin}/src/ecs/harness.html?mode=${encodeURIComponent(MODE)}&run=${RUN}`);
}

function streamingSession() {
  return session.fromPartition("persist:streaming-spike");
}

function createStreamingWindow(service) {
  if (streamingWindow && !streamingWindow.isDestroyed()) {
    streamingWindow.loadURL(service.url);
    streamingWindow.focus();
    return streamingWindow;
  }

  streamingWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    autoHideMenuBar: true,
    webPreferences: {
      ...WINDOW_PREFS,
      session: streamingSession()
    }
  });

  streamingWindow.loadURL(service.url);
  streamingWindow.on("closed", () => {
    streamingWindow = null;
  });
  return streamingWindow;
}

async function readPlaybackQuality() {
  if (!streamingWindow || streamingWindow.isDestroyed()) {
    return null;
  }
  try {
    return await streamingWindow.webContents.executeJavaScript(`
      (() => {
        const video = document.querySelector("video");
        if (!video || typeof video.getVideoPlaybackQuality !== "function") {
          return { available: false, href: location.href };
        }
        const q = video.getVideoPlaybackQuality();
        return {
          available: true,
          href: location.href,
          currentTime: video.currentTime,
          paused: video.paused,
          readyState: video.readyState,
          videoWidth: video.videoWidth,
          videoHeight: video.videoHeight,
          totalVideoFrames: q.totalVideoFrames,
          droppedVideoFrames: q.droppedVideoFrames,
          corruptedVideoFrames: q.corruptedVideoFrames
        };
      })()
    `);
  } catch (error) {
    return { available: false, error: error.message };
  }
}

function registerIpc() {
  ipcMain.handle("spike:mode", () => MODE);
  ipcMain.handle("spike:origin", () => origin);
  ipcMain.handle("spike:services", () => listServices());
  ipcMain.handle("spike:diagnostics", async () => ({
    machine,
    widevine,
    electron: process.versions,
    session: sessionKind(),
    userAgentSpoof: false,
    browserFlags: [],
    drmWorkaround: false,
    customCodecs: false,
    customChromium: false
  }));
  ipcMain.handle("spike:open-service", (_event, id) => {
    const service = getService(id);
    createStreamingWindow(service);
    return { ok: true, service };
  });
  ipcMain.handle("spike:close-service", () => {
    if (streamingWindow && !streamingWindow.isDestroyed()) {
      streamingWindow.close();
    }
    return { ok: true };
  });
  ipcMain.handle("spike:save-streaming", (_event, payload) => {
    const file = resultsPath("streaming.json");
    const existing = fs.existsSync(file)
      ? JSON.parse(fs.readFileSync(file, "utf8"))
      : { services: {} };
    existing.updatedAt = new Date().toISOString();
    existing.environment = machine;
    existing.widevine = widevine;
    existing.services = existing.services || {};
    existing.services[payload.id] = payload;
    writeJson(file, existing);
    return { ok: true, file };
  });
  ipcMain.handle("spike:save-result", (_event, fileName, payload) => {
    const file = safeResultsFile(fileName);
    writeJson(file, payload);
    return { ok: true, file };
  });
  ipcMain.handle("spike:playback-quality", () => readPlaybackQuality());
  ipcMain.handle("spike:playback-translation", async (_event, { serviceId }) => {
    const service = getService(serviceId);
    createStreamingWindow(service);
    return { ok: true, note: "Streaming window opened. Translation workload is driven from the harness." };
  });
  ipcMain.handle("spike:stop-playback-translation", () => {
    if (playbackTimer) {
      clearTimeout(playbackTimer);
      playbackTimer = null;
    }
    return { ok: true };
  });
}

async function runMozillaBenchMode() {
  const benchWindow = new BrowserWindow({
    width: 1100,
    height: 800,
    autoHideMenuBar: true,
    webPreferences: {
      ...WINDOW_PREFS,
      preload: path.join(__dirname, "preload.cjs")
    }
  });
  const params = new URLSearchParams({
    autorun: "1",
    run: String(RUN),
    round: String(ROUND),
    sequentialOnly: String(SEQUENTIAL_ONLY)
  });
  if (SEED) params.set("seed", String(SEED));
  if (CORPUS) params.set("corpus", toUrlPath(CORPUS));
  if (OUTPUT) {
    const relative = OUTPUT.replaceAll("\\", "/").replace(/^\/+/, "").replace(/^results\//, "");
    params.set("output", relative);
  }
  if (CORPUS_SHA) params.set("corpusSha256", CORPUS_SHA);
  const url = `${origin}/src/translation/mozilla/index.html?${params.toString()}`;
  console.log(`Mozilla bench URL: ${url}`);
  await benchWindow.loadURL(url);

  const deadline = Date.now() + 30 * 60 * 1000;
  while (Date.now() < deadline) {
    const title = benchWindow.title;
    if (title === "MOZILLA_BENCH_DONE") {
      app.exit(0);
      return;
    }
    if (title === "MOZILLA_BENCH_FAILED") {
      app.exit(1);
      return;
    }
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }
  app.exit(2);
}

app.commandLine.appendSwitch("enable-features", "SharedArrayBuffer");

app.whenReady().then(async () => {
  try {
    const sessionInfo = sessionKind();
    if (sessionInfo.rdp) {
      console.warn("RDP session detected. PLAN.md requires a physical local Windows session.");
    }

    machine = await collectMachine();
    writeJson(resultsPath("machine.json"), machine);

    const staticServer = await createStaticServer({ port: 8765 });
    origin = staticServer.origin;

    machine.versions = process.versions;
    if (MODE !== "mozilla-bench") {
      widevine = await waitForWidevine();
      machine.widevine = widevine;
    } else {
      widevine = { skipped: true, reason: "mozilla-bench does not need Widevine" };
    }
    writeJson(resultsPath("machine.json"), machine);

    registerIpc();

    if (MODE === "mozilla-bench") {
      await runMozillaBenchMode();
      return;
    }

    createHarnessWindow();

    if (MODE === "streaming" && SERVICE_ID) {
      createStreamingWindow(getService(SERVICE_ID));
    }

    if (MODE === "playback-translation" && SERVICE_ID) {
      createStreamingWindow(getService(SERVICE_ID));
    }

    if (MODE === "youtube-control") {
      const service = getService("youtube");
      createStreamingWindow(service);
      await new Promise((resolve) => setTimeout(resolve, 20000));
      const quality = await readPlaybackQuality();
      const payload = {
        id: "youtube",
        name: service.name,
        url: service.url,
        control: true,
        loginRequired: false,
        video: Boolean(quality?.videoWidth),
        audio: quality?.readyState >= 2,
        fullscreen: false,
        subtitles: false,
        playbackQuality: quality,
        checklist: {
          login: "not-required",
          video: quality?.videoWidth ? "pass" : "fail",
          audio: quality?.readyState >= 2 ? "pass" : "pending"
        },
        savedAt: new Date().toISOString()
      };
      const file = resultsPath("streaming.json");
      writeJson(file, {
        updatedAt: payload.savedAt,
        environment: machine,
        widevine,
        services: { youtube: payload }
      });
      console.log(JSON.stringify(payload, null, 2));
      app.exit(quality?.videoWidth ? 0 : 3);
    }
  } catch (error) {
    console.error(error);
    app.exit(1);
  }
});

app.on("window-all-closed", () => {
  app.quit();
});
