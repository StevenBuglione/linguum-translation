"use strict";

const SERVICES = {
  netflix: {
    id: "netflix",
    name: "Netflix",
    url: "https://www.netflix.com/",
    order: 1
  },
  prime: {
    id: "prime",
    name: "Prime Video",
    url: "https://www.primevideo.com/",
    order: 2
  },
  max: {
    id: "max",
    name: "Max",
    url: "https://www.max.com/",
    order: 3
  },
  youtube: {
    id: "youtube",
    name: "YouTube (control)",
    url: "https://www.youtube.com/watch?v=aqz-KE-bpKQ",
    order: 4,
    control: true
  }
};

const CHECKLIST = [
  "login",
  "catalog",
  "title page",
  "player initialization",
  "video",
  "audio",
  "2 minutes continuous playback",
  "pause/resume",
  "seek forward",
  "seek backward",
  "subtitles",
  "audio-track switching where available",
  "fullscreen",
  "exit fullscreen",
  "close ECS",
  "restart ECS",
  "session still authenticated"
];

const ACCEPTANCE_KEYS = ["video", "audio", "fullscreen", "subtitles"];

function listServices() {
  return Object.values(SERVICES).sort((a, b) => a.order - b.order);
}

function getService(id) {
  const service = SERVICES[id];
  if (!service) {
    throw new Error(`Unknown service: ${id}`);
  }
  return service;
}

function emptyChecklist() {
  return Object.fromEntries(CHECKLIST.map((item) => [item, "pending"]));
}

function isServiceGreen(result) {
  return ACCEPTANCE_KEYS.every((key) => result?.[key] === true || result?.[key] === "pass");
}

module.exports = {
  SERVICES,
  CHECKLIST,
  ACCEPTANCE_KEYS,
  listServices,
  getService,
  emptyChecklist,
  isServiceGreen
};
