"use strict";

const os = require("node:os");
const { execFile } = require("node:child_process");
const { promisify } = require("node:util");
const fs = require("node:fs");
const path = require("node:path");

const execFileAsync = promisify(execFile);

function parseArg(name, fallback = null) {
  const prefix = `--${name}=`;
  const match = process.argv.find((arg) => arg.startsWith(prefix));
  if (match) {
    return match.slice(prefix.length);
  }
  const index = process.argv.indexOf(`--${name}`);
  if (index !== -1 && process.argv[index + 1] && !process.argv[index + 1].startsWith("-")) {
    return process.argv[index + 1];
  }
  return fallback;
}

function hasFlag(name) {
  return process.argv.includes(`--${name}`) || process.argv.includes(`--${name}=true`);
}

async function runPowerShell(command) {
  try {
    const { stdout } = await execFileAsync(
      "powershell.exe",
      ["-NoProfile", "-Command", command],
      { windowsHide: true, timeout: 20000 }
    );
    return stdout.trim();
  } catch (error) {
    return `error: ${error.message}`;
  }
}

async function collectGpu() {
  const raw = await runPowerShell(
    "Get-CimInstance Win32_VideoController | Select-Object Name, DriverVersion, AdapterRAM, CurrentHorizontalResolution, CurrentVerticalResolution, CurrentRefreshRate | ConvertTo-Json -Compress"
  );
  try {
    const parsed = JSON.parse(raw);
    const devices = Array.isArray(parsed) ? parsed : [parsed];
    return devices
      .filter(Boolean)
      .map((device) => ({
        name: device.Name || "unknown",
        driver: device.DriverVersion || "unknown",
        adapterRamGb: device.AdapterRAM ? Number((device.AdapterRAM / 1024 ** 3).toFixed(2)) : null,
        resolution:
          device.CurrentHorizontalResolution && device.CurrentVerticalResolution
            ? `${device.CurrentHorizontalResolution}x${device.CurrentVerticalResolution}`
            : null,
        refreshRate: device.CurrentRefreshRate || null
      }));
  } catch {
    return [{ name: raw || "unknown", driver: "unknown" }];
  }
}

async function collectDisplay() {
  const raw = await runPowerShell(
    "Get-CimInstance Win32_DesktopMonitor | Select-Object Name, ScreenWidth, ScreenHeight | ConvertTo-Json -Compress"
  );
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [parsed];
  } catch {
    return [];
  }
}

function sessionKind() {
  const name = process.env.SESSIONNAME || "";
  if (/rdp/i.test(name)) {
    return { physicalLocalSession: false, rdp: true, sessionName: name };
  }
  return {
    physicalLocalSession: name === "Console" || name === "",
    rdp: false,
    sessionName: name || "unknown"
  };
}

async function collectMachine() {
  const cpus = os.cpus();
  const gpus = await collectGpu();
  const displays = await collectDisplay();
  const session = sessionKind();
  const virtualName = /virtual|parsec|anydesk|meta virtual|idd|indirect/i;
  const physicalGpus = gpus.filter((gpu) => gpu.name && !virtualName.test(gpu.name));
  const primaryGpu = physicalGpus[0] || gpus[0] || { name: "unknown", driver: "unknown" };
  const virtualDisplayAdapters = gpus.filter((gpu) => gpu.name && virtualName.test(gpu.name));

  return {
    collectedAt: new Date().toISOString(),
    windows: `${os.version()} (${os.release()})`,
    platform: os.platform(),
    arch: os.arch(),
    hostname: os.hostname(),
    cpu: cpus[0]?.model?.trim() || "unknown",
    cpuCount: cpus.length,
    ramGb: Number((os.totalmem() / 1024 ** 3).toFixed(2)),
    gpu: primaryGpu.name,
    gpuDriver: primaryGpu.driver,
    gpus,
    virtualDisplayAdapters,
    virtualDisplayWarning: virtualDisplayAdapters.length
      ? "Virtual display adapters are installed. PLAN.md forbids Parsec/virtual displays for the DRM acceptance run. Use the physical NVIDIA/AMD output."
      : null,
    displays,
    displayConnection: "assume direct HDMI/DisplayPort unless operator notes otherwise",
    displayResolution: primaryGpu.resolution,
    refreshRate: primaryGpu.refreshRate,
    session,
    node: process.versions.node,
    chrome: process.versions.chrome || null,
    electron: process.versions.electron || null,
    v8: process.versions.v8
  };
}

function componentsStatus(components) {
  if (!components) {
    return { available: false };
  }
  try {
    return {
      available: true,
      widevineId: components.WIDEVINE_CDM_ID || null,
      status: typeof components.status === "function" ? components.status() : null
    };
  } catch (error) {
    return { available: true, error: error.message };
  }
}

function writeJson(filePath, data) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, `${JSON.stringify(data, null, 2)}\n`, "utf8");
}

function repoRoot() {
  return path.resolve(__dirname, "..", "..");
}

function safeResultsFile(fileName) {
  const root = path.join(repoRoot(), "results");
  const relative = String(fileName || "posted.json").replaceAll("\\", "/").replace(/^\/+/, "");
  const resolved = path.resolve(root, relative);
  const fromRoot = path.relative(root, resolved);
  if (!fromRoot || fromRoot.startsWith("..") || path.isAbsolute(fromRoot)) {
    throw new Error(`refusing to write outside results/: ${fileName}`);
  }
  fs.mkdirSync(path.dirname(resolved), { recursive: true });
  return resolved;
}

module.exports = {
  parseArg,
  hasFlag,
  collectMachine,
  collectGpu,
  sessionKind,
  componentsStatus,
  writeJson,
  repoRoot,
  safeResultsFile
};
