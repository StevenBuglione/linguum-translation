// Sequential native Bergamot bench using AsyncService.
// Timing:
//   engineSetupMs      — parseOptions + AsyncService + createCompatibleModel
//   firstTranslationMs — canonical first-translation probe (not warmup, not measured)
//   warmup             — 20 canonical strings, discarded
//   wallClockMs        — 500 measured translations
#include <chrono>
#include <cstdio>
#include <fstream>
#include <future>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include "translator/parser.h"
#include "translator/response.h"
#include "translator/response_options.h"
#include "translator/service.h"
#include "translator/translation_model.h"

using marian::bergamot::AsyncService;
using marian::bergamot::Response;
using marian::bergamot::ResponseOptions;

static std::string jsonEscape(const std::string &input) {
  std::string out;
  out.reserve(input.size() + 8);
  for (unsigned char ch : input) {
    switch (ch) {
      case '\\':
        out += "\\\\";
        break;
      case '"':
        out += "\\\"";
        break;
      case '\n':
        out += "\\n";
        break;
      case '\r':
        out += "\\r";
        break;
      case '\t':
        out += "\\t";
        break;
      default:
        if (ch < 0x20) {
          char buf[8];
          std::snprintf(buf, sizeof(buf), "\\u%04x", ch);
          out += buf;
        } else {
          out += static_cast<char>(ch);
        }
    }
  }
  return out;
}

static std::vector<std::string> readLines(const std::string &path) {
  std::ifstream in(path, std::ios::binary);
  if (!in) {
    throw std::runtime_error("cannot open file: " + path);
  }
  std::vector<std::string> lines;
  std::string line;
  while (std::getline(in, line)) {
    if (!line.empty() && line.back() == '\r') {
      line.pop_back();
    }
    if (!line.empty()) {
      lines.push_back(line);
    }
  }
  return lines;
}

static std::string readSingleLine(const std::string &path) {
  auto lines = readLines(path);
  if (lines.empty()) {
    throw std::runtime_error("expected a non-empty probe file: " + path);
  }
  return lines.front();
}

static double millisSince(const std::chrono::steady_clock::time_point &started) {
  return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - started)
      .count();
}

int main(int argc, char **argv) {
  setvbuf(stderr, nullptr, _IONBF, 0);
  setvbuf(stdout, nullptr, _IONBF, 0);
  try {
  if (argc < 5) {
    std::cerr << "usage: native-bench <config.yml> <measured.txt> <warmup.txt> <probe.txt>\n";
    return 2;
  }

  const std::string configPath = argv[1];
  const std::string measuredPath = argv[2];
  const std::string warmupPath = argv[3];
  const std::string probePath = argv[4];

  const auto setupStart = std::chrono::steady_clock::now();
  auto options = marian::bergamot::parseOptionsFromFilePath(configPath);
  AsyncService::Config serviceConfig;
  serviceConfig.numWorkers = 1;
  serviceConfig.cacheSize = 0;
  AsyncService service(serviceConfig);
  auto model = service.createCompatibleModel(options);
  const double engineSetupMs = millisSince(setupStart);

  auto measured = readLines(measuredPath);
  auto warmup = readLines(warmupPath);
  const std::string probe = readSingleLine(probePath);
  if (measured.empty()) {
    throw std::runtime_error("measured corpus is empty");
  }
  if (warmup.empty()) {
    throw std::runtime_error("warmup corpus is empty");
  }

  ResponseOptions responseOptions;
  responseOptions.qualityScores = false;
  responseOptions.alignment = false;
  responseOptions.HTML = false;

  auto translateOne = [&](const std::string &text) {
    std::promise<Response> promise;
    auto future = promise.get_future();
    service.translate(
        model,
        std::string(text),
        [&promise](Response &&response) { promise.set_value(std::move(response)); },
        responseOptions);
    return future.get().target.text;
  };

  const auto firstStart = std::chrono::steady_clock::now();
  (void)translateOne(probe);
  const double firstTranslationMs = millisSince(firstStart);

  for (const auto &sentence : warmup) {
    (void)translateOne(sentence);
  }

  struct Sample {
    std::string source;
    std::string translation;
    double totalMs;
  };
  std::vector<Sample> samples;
  samples.reserve(measured.size());

  const auto wallStart = std::chrono::steady_clock::now();
  for (const auto &text : measured) {
    const auto started = std::chrono::steady_clock::now();
    std::string translation = translateOne(text);
    const double totalMs = millisSince(started);
    while (!translation.empty() && (translation.back() == '\n' || translation.back() == '\r')) {
      translation.pop_back();
    }
    samples.push_back({text, std::move(translation), totalMs});
  }
  const double wallClockMs = millisSince(wallStart);

  std::cout << "{\n";
  std::cout << "  \"service\": \"AsyncService\",\n";
  std::cout << "  \"workers\": 1,\n";
  std::cout << "  \"cacheSize\": 0,\n";
  std::cout << "  \"engineSetupMs\": " << engineSetupMs << ",\n";
  std::cout << "  \"firstTranslationMs\": " << firstTranslationMs << ",\n";
  std::cout << "  \"wallClockMs\": " << wallClockMs << ",\n";
  std::cout << "  \"warmup\": " << warmup.size() << ",\n";
  std::cout << "  \"samples\": [\n";
  for (size_t i = 0; i < samples.size(); ++i) {
    const auto &sample = samples[i];
    std::cout << "    {\"source\": \"" << jsonEscape(sample.source) << "\", \"translation\": \""
              << jsonEscape(sample.translation) << "\", \"totalMs\": " << sample.totalMs << "}";
    if (i + 1 != samples.size()) {
      std::cout << ",";
    }
    std::cout << "\n";
  }
  std::cout << "  ]\n}\n";
  return 0;
  } catch (const std::exception &error) {
    std::cerr << "exception: " << error.what() << "\n";
    return 1;
  } catch (...) {
    std::cerr << "unknown exception\n";
    return 1;
  }
}
