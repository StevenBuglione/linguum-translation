@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
set CMAKE_POLICY_VERSION_MINIMUM=3.5
cd /d "D:\Users\steve\performance-test\native\bergamot-translator\build-native"
cmake -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_POLICY_VERSION_MINIMUM=3.5 -DUSE_WASM_COMPATIBLE_SOURCE=ON -DSSPLIT_USE_INTERNAL_PCRE2=ON -DUSE_MKL=OFF -DUSE_ONNX_SGEMM=ON -DCOMPILE_CUDA=OFF -DCOMPILE_TESTS=OFF -DCOMPILE_UNIT_TESTS=OFF -DCOMPILE_PYTHON=OFF -DBUILD_ARCH=native -DGIT_SUBMODULE=OFF ..
ninja native-bench
